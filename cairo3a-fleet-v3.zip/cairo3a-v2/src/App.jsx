import { useState, useMemo, useRef } from "react";
import * as XLSX from "xlsx";

// ═══════════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════════
const EGP       = n => `${(+n||0).toLocaleString("ar-EG")} ج.م`;
const fmt       = d => d ? new Date(d).toLocaleDateString("ar-EG",{year:"numeric",month:"short",day:"numeric"}) : "—";
const todayStr  = () => new Date().toISOString().split("T")[0];
const daysNum   = (a,b) => Math.max(1,Math.ceil((new Date(b)-new Date(a))/86400000));
const nextId    = arr => Math.max(0,...arr.map(x=>x.id))+1;
const genRef    = id  => `C3A-${new Date().getFullYear()}-${String(id).padStart(4,"0")}`;
const shareWA   = txt => window.open(`https://wa.me/?text=${encodeURIComponent(txt)}`,"_blank");

const exportXLSX = (rows, cols, filename) => {
  const data = rows.map(r=>{ const o={}; cols.forEach(c=>{o[c.label]=r[c.key]??"—"}); return o; });
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,ws,"بيانات");
  XLSX.writeFile(wb,filename+".xlsx");
};

// ═══════════════════════════════════════════════════════════════════════
// INITIAL DATA
// ═══════════════════════════════════════════════════════════════════════
const initSectors = [
  { id:1, name:"قطاع التسمين",  color:"#dc2626", bg:"#fef2f2", ico:"🐔",
    depts:["إدارة المزارع","إدارة التغذية","إدارة الصحة الحيوانية","إدارة الإنتاج"] },
  { id:2, name:"قطاع الأمهات",  color:"#ea580c", bg:"#fff7ed", ico:"🐓",
    depts:["إدارة القطعان","إدارة التربية","إدارة المزرعة","إدارة التلقيح"] },
  { id:3, name:"قطاع التفريخ",  color:"#6b7280", bg:"#f9fafb", ico:"🥚",
    depts:["إدارة الحضانات","إدارة العمليات","إدارة الفرازة","إدارة الصيانة"] },
  { id:4, name:"قطاع الأعلاف",  color:"#92400e", bg:"#fef9c3", ico:"🌾",
    depts:["إدارة المخازن","إدارة التصنيع","إدارة التوزيع","إدارة المشتريات"] },
];

const initEmployees = [
  { code:"E001", name:"أحمد محمد علي",      job:"مهندس إنتاج",  sectorId:1, dept:"إدارة المزارع" },
  { code:"E002", name:"سارة خالد إبراهيم",  job:"فني تغذية",    sectorId:1, dept:"إدارة التغذية" },
  { code:"E003", name:"محمد عبدالله حسن",   job:"مشرف قطعان",   sectorId:2, dept:"إدارة القطعان" },
  { code:"E004", name:"فاطمة أحمد نور",     job:"مدير تفريخ",   sectorId:3, dept:"إدارة الحضانات" },
  { code:"E005", name:"عمر سعد الغامدي",    job:"مدير مخازن",   sectorId:4, dept:"إدارة المخازن" },
  { code:"E006", name:"نورة فهد السبيعي",   job:"فنية مختبر",   sectorId:3, dept:"إدارة العمليات" },
  { code:"E007", name:"خالد عبدالرحمن",     job:"مشرف تربية",   sectorId:2, dept:"إدارة التربية" },
  { code:"E008", name:"هند الزهراني",       job:"مهندسة أعلاف", sectorId:4, dept:"إدارة التصنيع" },
  { code:"E009", name:"يوسف المطيري",       job:"مشرف صحة",     sectorId:1, dept:"إدارة الصحة الحيوانية" },
  { code:"E010", name:"مريم العتيبي",       job:"فنية تفريخ",   sectorId:3, dept:"إدارة الفرازة" },
];

const initRoutes = [
  { id:1, name:"الرياض ← جدة",             from:"الرياض", to:"جدة" },
  { id:2, name:"الرياض ← الدمام",          from:"الرياض", to:"الدمام" },
  { id:3, name:"الرياض ← مكة المكرمة",    from:"الرياض", to:"مكة المكرمة" },
  { id:4, name:"جدة ← أبها",              from:"جدة",    to:"أبها" },
  { id:5, name:"الدمام ← المدينة المنورة", from:"الدمام", to:"المدينة المنورة" },
];

const initVehicles = [
  { id:1, name:"سيارة صالون", capacity:7,  dailyCost:400,  icon:"🚗",
    priceHistory:[{ date:"2025-01-01", cost:400, note:"سعر التأسيس" }] },
  { id:2, name:"ميني باص",    capacity:14, dailyCost:700,  icon:"🚌",
    priceHistory:[{ date:"2025-01-01", cost:700, note:"سعر التأسيس" }] },
  { id:3, name:"باص كبير",    capacity:30, dailyCost:1100, icon:"🚍",
    priceHistory:[{ date:"2025-01-01", cost:1100, note:"سعر التأسيس" }] },
];

const initBookings = [
  { id:1,  ref:"C3A-2025-0001", empCode:"E001", routeId:1, departDate:"2025-04-05", returnDate:"2025-04-07", status:"approved",  createdAt:"2025-03-28" },
  { id:2,  ref:"C3A-2025-0002", empCode:"E002", routeId:1, departDate:"2025-04-05", returnDate:"2025-04-07", status:"approved",  createdAt:"2025-03-29" },
  { id:3,  ref:"C3A-2025-0003", empCode:"E003", routeId:2, departDate:"2025-04-05", returnDate:"2025-04-06", status:"approved",  createdAt:"2025-03-30" },
  { id:4,  ref:"C3A-2025-0004", empCode:"E004", routeId:3, departDate:"2025-04-10", returnDate:"2025-04-12", status:"pending",   createdAt:"2025-03-30" },
  { id:5,  ref:"C3A-2025-0005", empCode:"E005", routeId:4, departDate:"2025-04-15", returnDate:"2025-04-17", status:"pending",   createdAt:"2025-03-31" },
  { id:6,  ref:"C3A-2025-0006", empCode:"E006", routeId:1, departDate:"2025-04-05", returnDate:"2025-04-07", status:"approved",  createdAt:"2025-03-28" },
  { id:7,  ref:"C3A-2025-0007", empCode:"E007", routeId:2, departDate:"2025-04-05", returnDate:"2025-04-07", status:"approved",  createdAt:"2025-03-29" },
  { id:8,  ref:"C3A-2025-0008", empCode:"E008", routeId:1, departDate:"2025-04-05", returnDate:"2025-04-09", status:"approved",  createdAt:"2025-03-31" },
  { id:9,  ref:"C3A-2025-0009", empCode:"E009", routeId:3, departDate:"2025-04-10", returnDate:"2025-04-13", status:"approved",  createdAt:"2025-03-30" },
  { id:10, ref:"C3A-2025-0010", empCode:"E010", routeId:1, departDate:"2025-04-05", returnDate:"2025-04-07", status:"rejected",  createdAt:"2025-03-28" },
];

const initTrips = [
  { id:1, routeId:1, vehicleTypeId:2, departDate:"2025-04-05", returnDate:"2025-04-07",
    empCodes:["E001","E002","E006"], numVehicles:1, days:2, totalCost:1400, costPerEmp:467, notes:"" },
  { id:2, routeId:2, vehicleTypeId:1, departDate:"2025-04-05", returnDate:"2025-04-06",
    empCodes:["E003","E007"], numVehicles:1, days:1, totalCost:400, costPerEmp:200, notes:"" },
];

const initUsers = [
  { username:"admin",    password:"admin123", role:"admin",    empCode:null },
  { username:"E001",     password:"pass001",  role:"employee", empCode:"E001" },
  { username:"E002",     password:"pass002",  role:"employee", empCode:"E002" },
  { username:"E003",     password:"pass003",  role:"employee", empCode:"E003" },
  { username:"E004",     password:"pass004",  role:"employee", empCode:"E004" },
  { username:"E005",     password:"pass005",  role:"employee", empCode:"E005" },
  { username:"E006",     password:"pass006",  role:"employee", empCode:"E006" },
  { username:"E007",     password:"pass007",  role:"employee", empCode:"E007" },
  { username:"E008",     password:"pass008",  role:"employee", empCode:"E008" },
  { username:"E009",     password:"pass009",  role:"employee", empCode:"E009" },
  { username:"E010",     password:"pass010",  role:"employee", empCode:"E010" },
];

// ═══════════════════════════════════════════════════════════════════════
// CSS — WHITE THEME
// ═══════════════════════════════════════════════════════════════════════
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&family=Tajawal:wght@700;800;900&display=swap');
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
:root{
  --R:#c8102e; --R2:#e8203e; --R3:#8b0d1f; --Rlight:#fff1f2;
  --bg:#f5f6f8; --card:#ffffff; --sidebar:#ffffff;
  --bdr:#e2e8f0; --bdr2:#f1f5f9;
  --txt:#1e293b; --txt2:#64748b; --txt3:#94a3b8;
  --green:#16a34a; --amber:#d97706; --blue:#2563eb;
  --shadow:0 1px 3px rgba(0,0,0,.08),0 1px 2px rgba(0,0,0,.06);
  --shadow-md:0 4px 6px rgba(0,0,0,.07),0 2px 4px rgba(0,0,0,.05);
  --shadow-lg:0 10px 25px rgba(0,0,0,.1),0 4px 10px rgba(0,0,0,.06);
}
body{font-family:'Cairo',sans-serif;background:var(--bg);color:var(--txt);direction:rtl;min-height:100vh;}

/* ── LOGIN ── */
.lp{min-height:100vh;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(135deg,#fef2f2 0%,#f8fafc 50%,#fff1f2 100%);
  position:relative;overflow:hidden;}
.lp::before{content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse 600px 400px at 30% 20%,rgba(200,16,46,.08),transparent),
             radial-gradient(ellipse 500px 350px at 70% 80%,rgba(200,16,46,.06),transparent);}
.lp-box{background:var(--card);border:1px solid var(--bdr);border-radius:20px;
  padding:40px 36px;width:420px;max-width:95vw;box-shadow:var(--shadow-lg);
  position:relative;z-index:1;animation:fadeUp .35s ease;}
.lp-brand{text-align:center;margin-bottom:28px;padding-bottom:24px;border-bottom:1px solid var(--bdr);}
.brand-name{font-family:'Tajawal',sans-serif;font-size:28px;font-weight:900;color:var(--R);letter-spacing:2px;}
.brand-sub{font-size:12px;color:var(--txt3);letter-spacing:3px;margin-top:2px;}
.brand-sys{font-size:14px;color:var(--txt2);margin-top:8px;font-weight:600;}
.field{display:flex;flex-direction:column;gap:5px;margin-bottom:14px;}
.field label{font-size:11px;font-weight:700;color:var(--txt2);}
.field input{background:var(--bg);border:1.5px solid var(--bdr);border-radius:10px;
  padding:11px 14px;font-family:'Cairo';font-size:14px;color:var(--txt);outline:none;
  transition:all .2s;direction:ltr;text-align:right;width:100%;}
.field input:focus{border-color:var(--R);box-shadow:0 0 0 3px rgba(200,16,46,.1);}
.field input.e{border-color:#ef4444;}
.err{font-size:12px;color:#ef4444;text-align:center;margin:6px 0;font-weight:600;}

/* ── BUTTONS ── */
.btn{padding:9px 18px;border-radius:9px;font-family:'Cairo';font-size:13px;font-weight:700;
  cursor:pointer;border:none;transition:all .15s;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;}
.btn-r{background:var(--R);color:#fff;box-shadow:0 2px 6px rgba(200,16,46,.3);}
.btn-r:hover{background:var(--R2);box-shadow:0 4px 12px rgba(200,16,46,.4);transform:translateY(-1px);}
.btn-r:disabled{opacity:.45;cursor:not-allowed;transform:none;}
.btn-g{background:var(--bg);border:1.5px solid var(--bdr);color:var(--txt2);}
.btn-g:hover{background:#f1f5f9;color:var(--txt);border-color:#cbd5e1;}
.btn-ok{background:#dcfce7;border:1px solid #bbf7d0;color:var(--green);}
.btn-ok:hover{background:#bbf7d0;}
.btn-no{background:#fee2e2;border:1px solid #fecaca;color:#dc2626;}
.btn-no:hover{background:#fecaca;}
.btn-am{background:#fef3c7;border:1px solid #fde68a;color:var(--amber);}
.btn-am:hover{background:#fde68a;}
.btn-wa{background:#25d366;color:#fff;box-shadow:0 2px 6px rgba(37,211,102,.35);}
.btn-wa:hover{background:#1ebe5d;transform:translateY(-1px);}
.btn-xl{background:#f0fdf4;border:1px solid #bbf7d0;color:var(--green);}
.btn-xl:hover{background:#dcfce7;}
.btn-pr{background:#eff6ff;border:1px solid #bfdbfe;color:var(--blue);}
.btn-pr:hover{background:#dbeafe;}
.btn-sm{padding:5px 11px;font-size:11px;border-radius:7px;}
.btn-xs{padding:3px 8px;font-size:10px;border-radius:6px;}
.btn-ico{padding:5px;width:30px;height:30px;border-radius:8px;justify-content:center;}
.w100{width:100%;justify-content:center;}

/* ── APP LAYOUT ── */
.app{display:flex;min-height:100vh;}
.sidebar{width:256px;background:var(--sidebar);border-left:1px solid var(--bdr);
  display:flex;flex-direction:column;position:fixed;right:0;top:0;bottom:0;z-index:100;overflow-y:auto;}
.sb-brand{padding:20px 16px 16px;border-bottom:1px solid var(--bdr);}
.sb-title{font-family:'Tajawal',sans-serif;font-size:18px;font-weight:900;color:var(--R);}
.sb-subtitle{font-size:10px;color:var(--txt3);letter-spacing:2px;margin-top:2px;}
.sb-sysname{font-size:11px;color:var(--txt2);margin-top:6px;font-weight:600;}
.nav{padding:12px 10px;flex:1;}
.nsec{font-size:10px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;padding:12px 8px 5px;}
.ni{display:flex;align-items:center;gap:9px;padding:9px 12px;border-radius:10px;cursor:pointer;
  transition:all .15s;color:var(--txt2);font-size:12.5px;font-weight:600;margin-bottom:2px;
  border:none;background:none;font-family:'Cairo';width:100%;text-align:right;}
.ni:hover{background:#f1f5f9;color:var(--txt);}
.ni.act{background:var(--Rlight);color:var(--R);font-weight:800;}
.ni.act .n-ico{color:var(--R);}
.n-ico{font-size:15px;width:20px;text-align:center;}
.n-bdg{margin-right:auto;background:var(--R);color:#fff;font-size:9px;font-weight:800;padding:1px 7px;border-radius:20px;}
.sb-foot{padding:12px;border-top:1px solid var(--bdr);}
.u-chip{display:flex;align-items:center;gap:9px;padding:10px;border-radius:10px;background:var(--Rlight);border:1px solid #fecdd3;margin-bottom:8px;}
.u-av{width:34px;height:34px;border-radius:50%;background:var(--R);color:#fff;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:900;flex-shrink:0;}
.u-n{font-size:12px;font-weight:700;color:var(--txt);}
.u-r{font-size:10px;color:var(--txt3);}
.logout{width:100%;padding:8px;border-radius:9px;background:#fee2e2;border:1px solid #fecaca;
  color:#dc2626;font-family:'Cairo';font-size:12px;font-weight:700;cursor:pointer;transition:all .15s;}
.logout:hover{background:#fecaca;}

.main{margin-right:256px;flex:1;display:flex;flex-direction:column;min-width:0;}
.topbar{background:var(--card);border-bottom:1px solid var(--bdr);padding:14px 24px;
  display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:50;box-shadow:var(--shadow);}
.ph{font-family:'Tajawal',sans-serif;font-size:18px;font-weight:900;color:var(--txt);}
.ps{font-size:11px;color:var(--txt3);margin-top:2px;}
.content{padding:20px 24px;flex:1;}

/* ── STATS ── */
.g4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px;}
.g3{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px;}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;}
.stat{background:var(--card);border:1px solid var(--bdr);border-radius:14px;padding:16px 18px;
  box-shadow:var(--shadow);transition:all .2s;}
.stat:hover{box-shadow:var(--shadow-md);transform:translateY(-2px);}
.stat-ico-wrap{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;margin-bottom:10px;}
.st-n{font-size:26px;font-weight:900;font-family:'Tajawal',sans-serif;line-height:1;margin-bottom:3px;}
.st-l{font-size:11px;color:var(--txt2);font-weight:600;}
.st-s{font-size:10px;color:var(--txt3);margin-top:3px;}

/* ── CARDS ── */
.card{background:var(--card);border:1px solid var(--bdr);border-radius:14px;overflow:hidden;margin-bottom:14px;box-shadow:var(--shadow);}
.ch{padding:13px 16px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;background:#fafafa;}
.ct{font-size:14px;font-weight:800;color:var(--txt);}
.cs{font-size:11px;color:var(--txt3);margin-top:2px;}
.cb{padding:16px;}
.mc-card{background:var(--bg);border:1px solid var(--bdr);border-radius:12px;padding:14px 16px;}

/* ── TABLE ── */
.tbl{overflow-x:auto;}
table{width:100%;border-collapse:collapse;}
th{padding:9px 13px;text-align:right;font-size:10px;font-weight:800;color:var(--txt3);
  text-transform:uppercase;letter-spacing:.5px;border-bottom:2px solid var(--bdr);white-space:nowrap;background:#fafafa;}
td{padding:10px 13px;font-size:12.5px;border-bottom:1px solid var(--bdr2);vertical-align:middle;color:var(--txt);}
tr:last-child td{border-bottom:none;}
tr:hover td{background:#fafafa;}

/* ── BADGES ── */
.badge{display:inline-flex;align-items:center;gap:4px;padding:3px 9px;border-radius:20px;font-size:10.5px;font-weight:700;}
.b-g{background:#dcfce7;color:#15803d;border:1px solid #bbf7d0;}
.b-y{background:#fef3c7;color:#b45309;border:1px solid #fde68a;}
.b-r{background:#fee2e2;color:#dc2626;border:1px solid #fecaca;}
.b-b{background:#fff1f2;color:var(--R);border:1px solid #fecdd3;}
.b-gr{background:#f1f5f9;color:var(--txt3);border:1px solid var(--bdr);}
.stag{display:inline-flex;align-items:center;gap:4px;padding:2px 9px;border-radius:6px;font-size:10.5px;font-weight:700;}
.chip{display:inline-flex;align-items:center;background:var(--Rlight);border:1px solid #fecdd3;color:var(--R);border-radius:6px;padding:2px 9px;font-size:11px;font-weight:700;}

/* ── MISC ── */
.divider{height:1px;background:var(--bdr);margin:14px 0;}
.sectitle{font-size:10px;font-weight:800;color:var(--txt3);text-transform:uppercase;letter-spacing:.6px;margin-bottom:10px;}
.empty{text-align:center;padding:32px;color:var(--txt3);font-size:13px;}
.prog-bar{background:var(--bdr);border-radius:99px;height:5px;overflow:hidden;margin-top:4px;}
.prog{height:100%;border-radius:99px;transition:width .5s;}
.search-box{display:flex;align-items:center;gap:8px;background:var(--bg);border:1.5px solid var(--bdr);border-radius:9px;padding:6px 12px;}
.search-box input{background:none;border:none;font-family:'Cairo';font-size:12px;color:var(--txt);outline:none;direction:rtl;}
.tabs{display:flex;gap:3px;background:var(--bg);border-radius:9px;padding:3px;border:1px solid var(--bdr);}
.tab{padding:5px 13px;border-radius:7px;font-size:11.5px;font-weight:700;cursor:pointer;font-family:'Cairo';border:none;background:none;color:var(--txt2);transition:all .15s;}
.tab.act{background:var(--R);color:#fff;box-shadow:0 2px 6px rgba(200,16,46,.3);}
.fbar{background:var(--card);border:1px solid var(--bdr);border-radius:13px;padding:12px 16px;
  display:flex;align-items:flex-end;gap:12px;margin-bottom:14px;flex-wrap:wrap;box-shadow:var(--shadow);}
.fbar label{font-size:10px;font-weight:700;color:var(--txt3);display:block;margin-bottom:4px;text-transform:uppercase;}
.fbar input,.fbar select{background:var(--bg);border:1.5px solid var(--bdr);border-radius:8px;padding:7px 11px;
  font-family:'Cairo';font-size:12px;color:var(--txt);outline:none;direction:rtl;}
.fbar input[type=date],.fbar input[type=month]{direction:ltr;}
.fbar select option{background:var(--card);}
.fbar input:focus,.fbar select:focus{border-color:var(--R);}
.fg{display:flex;flex-direction:column;gap:5px;}
.fg.full{grid-column:1/-1;}
.fg label{font-size:11px;font-weight:700;color:var(--txt2);}
.fg input,.fg select,.fg textarea{background:var(--bg);border:1.5px solid var(--bdr);border-radius:10px;
  padding:9px 13px;font-family:'Cairo';font-size:13px;color:var(--txt);outline:none;transition:all .15s;direction:rtl;width:100%;}
.fg select option{background:var(--card);}
.fg input:focus,.fg select:focus,.fg textarea:focus{border-color:var(--R);box-shadow:0 0 0 3px rgba(200,16,46,.1);}
.fg input:disabled{opacity:.5;cursor:not-allowed;}
.fgrid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;}

/* ── MODAL ── */
.overlay{position:fixed;inset:0;background:rgba(15,23,42,.4);backdrop-filter:blur(4px);z-index:999;
  display:flex;align-items:center;justify-content:center;animation:fadeIn .18s;}
.modal{background:var(--card);border:1px solid var(--bdr);border-radius:20px;
  width:580px;max-width:95vw;max-height:90vh;overflow-y:auto;animation:slideUp .2s;box-shadow:var(--shadow-lg);}
.mh{padding:16px 22px;border-bottom:1px solid var(--bdr);display:flex;align-items:center;justify-content:space-between;background:#fafafa;border-radius:20px 20px 0 0;}
.mt{font-size:15px;font-weight:900;color:var(--txt);}
.mc{background:var(--bg);border:1px solid var(--bdr);color:var(--txt3);width:30px;height:30px;border-radius:8px;
  cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;transition:all .15s;}
.mc:hover{background:#fee2e2;color:#dc2626;border-color:#fecaca;}
.mb{padding:20px 22px;}
.mf{padding:14px 22px;border-top:1px solid var(--bdr);display:flex;gap:9px;justify-content:flex-end;background:#fafafa;border-radius:0 0 20px 20px;}

/* ── EMPLOYEE PAGE ── */
.emp-page{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;
  background:linear-gradient(135deg,#fef2f2,#f8fafc,#fff1f2);padding:20px;}
.emp-tbar{position:fixed;top:0;left:0;right:0;padding:13px 24px;display:flex;align-items:center;justify-content:space-between;
  background:var(--card);border-bottom:1px solid var(--bdr);box-shadow:var(--shadow);z-index:10;}
.emp-card{background:var(--card);border:1px solid var(--bdr);border-radius:20px;padding:28px;
  width:100%;max-width:560px;box-shadow:var(--shadow-lg);margin-top:72px;}
.info-grid{background:var(--bg);border:1px solid var(--bdr);border-radius:12px;padding:14px;
  margin-bottom:14px;display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.ir{display:flex;flex-direction:column;gap:3px;}
.il{font-size:10px;color:var(--txt3);font-weight:700;text-transform:uppercase;}
.iv{font-size:13.5px;font-weight:700;color:var(--txt);}

/* ── BOOKING CARD ── */
.bcard{border:2px solid var(--R);border-radius:16px;padding:20px;background:#fff;}
.bcard-ref{font-family:monospace;font-size:18px;font-weight:900;color:var(--R);letter-spacing:2px;margin-bottom:4px;}
.bcard-row{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--bdr2);font-size:12.5px;}
.bcard-row:last-child{border:none;}

/* ── ROUTE GROUP ── */
.rg{background:var(--card);border:1px solid var(--bdr);border-radius:12px;margin-bottom:10px;overflow:hidden;box-shadow:var(--shadow);}
.rg-h{padding:11px 15px;display:flex;align-items:center;justify-content:space-between;background:#fafafa;border-bottom:1px solid var(--bdr);flex-wrap:wrap;gap:8px;}
.rg-b{padding:11px 15px;}
.e-row{display:flex;align-items:center;gap:9px;padding:7px 0;border-bottom:1px solid var(--bdr2);font-size:12.5px;}
.e-row:last-child{border-bottom:none;}

/* ── VEHICLE CARD ── */
.vc{background:var(--bg);border:2px solid var(--bdr);border-radius:12px;padding:14px;cursor:pointer;transition:all .15s;text-align:center;}
.vc:hover{border-color:#fca5a5;background:var(--Rlight);}
.vc.sel{border-color:var(--R);background:var(--Rlight);box-shadow:0 0 0 3px rgba(200,16,46,.15);}

/* ── CALC BOX ── */
.calc-box{background:var(--Rlight);border:1.5px solid #fecdd3;border-radius:12px;padding:14px 16px;margin-top:12px;}
.cr{display:flex;justify-content:space-between;align-items:center;font-size:12px;margin-bottom:6px;color:var(--txt);}
.cr:last-child{margin-bottom:0;font-size:14px;font-weight:800;color:var(--R);}

/* ── DONUT / BARS ── */
.dw{display:flex;align-items:center;gap:16px;}
.dleg{display:flex;flex-direction:column;gap:7px;}
.dli{display:flex;align-items:center;gap:7px;font-size:12px;}
.dd{width:10px;height:10px;border-radius:3px;}
.bars{display:flex;align-items:flex-end;gap:6px;height:90px;}
.bw{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;}
.bar{width:100%;border-radius:4px 4px 0 0;min-height:3px;background:var(--R);transition:height .5s;}
.bl{font-size:9px;color:var(--txt3);text-align:center;}
.bv{font-size:10px;font-weight:700;color:var(--txt2);}

/* ── ALERTS ── */
.alert{border-radius:10px;padding:11px 14px;font-size:12px;margin-bottom:12px;display:flex;align-items:flex-start;gap:8px;}
.alert-r{background:var(--Rlight);border:1px solid #fecdd3;color:var(--R);}
.alert-g{background:#f0fdf4;border:1px solid #bbf7d0;color:var(--green);}

@media print{
  .no-print{display:none!important;}
  body{background:white;}
  .bcard{border:2px solid var(--R);}
}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
@keyframes slideUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
`;

// ═══════════════════════════════════════════════════════════════════════
// SMALL COMPONENTS
// ═══════════════════════════════════════════════════════════════════════
function SBadge({s}){
  const m={approved:["b-g","✓ مقبول"],pending:["b-y","⏳ معلق"],rejected:["b-r","✕ مرفوض"]};
  const [c,t]=m[s]||["b-gr",s];
  return <span className={"badge "+c}>{t}</span>;
}
function SecTag({sid, sectors}){
  const s=(sectors||initSectors).find(x=>x.id===sid);
  if(!s) return null;
  return <span className="stag" style={{background:s.bg,color:s.color,border:"1px solid "+s.color+"40"}}>{s.ico} {s.name}</span>;
}
function Donut({data}){
  const total=data.reduce((s,d)=>s+d.v,0)||1;
  const r=34,cx=42,cy=42,C=2*Math.PI*r;
  let off=0;
  const segs=data.map(d=>{const seg={...d,da:(d.v/total)*C,doff:-off*C};off+=d.v/total;return seg;});
  return(
    <div className="dw">
      <svg width="84" height="84" viewBox="0 0 84 84">
        <circle cx={cx} cy={cy} r={r} fill="none" stroke="#f1f5f9" strokeWidth="11"/>
        {segs.map((s,i)=><circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke={s.c} strokeWidth="11"
          strokeDasharray={s.da+" "+C} strokeDashoffset={s.doff}
          style={{transformOrigin:cx+"px "+cy+"px",transform:"rotate(-90deg)"}}/>)}
        <text x={cx} y={cy} textAnchor="middle" dy="4" fill="#1e293b" fontSize="11" fontWeight="900">{total}</text>
      </svg>
      <div className="dleg">{data.map((d,i)=>(
        <div key={i} className="dli"><div className="dd" style={{background:d.c}}/><span style={{color:"var(--txt2)"}}>{d.l}</span><b style={{marginRight:"auto",marginLeft:6}}>{d.v}</b></div>
      ))}</div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// BOOKING CARD MODAL
// ═══════════════════════════════════════════════════════════════════════
function BookingCardModal({booking, employees, routes, sectors, onClose}){
  const em=employees.find(e=>e.code===booking.empCode);
  const rt=routes.find(r=>r.id===booking.routeId);
  const sec=(sectors||initSectors).find(s=>s.id===em?.sectorId);
  const text=`📋 بطاقة إجازة - Cairo 3A Poultry\nرقم الحجز: ${booking.ref}\nالموظف: ${em?.name}\nالقطاع: ${sec?.name}\nخط السير: ${rt?.name}\nتاريخ النزول: ${fmt(booking.departDate)}\nتاريخ العودة: ${fmt(booking.returnDate)}\nالمدة: ${daysNum(booking.departDate,booking.returnDate)} يوم\nالحالة: ${booking.status==="approved"?"مقبول":booking.status==="pending"?"معلق":"مرفوض"}`;
  return(
    <div className="overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal" style={{maxWidth:480}}>
        <div className="mh"><div className="mt">🎫 بطاقة الحجز</div><button className="mc" onClick={onClose}>✕</button></div>
        <div className="mb">
          <div className="bcard">
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
              <div><div style={{fontFamily:"Tajawal,sans-serif",fontSize:20,fontWeight:900,color:"var(--R)"}}>Cairo 3A Poultry</div><div style={{fontSize:10,color:"var(--txt3)"}}>نظام إدارة إجازات الأسطول</div></div>
              <SBadge s={booking.status}/>
            </div>
            <div className="bcard-ref">{booking.ref}</div>
            {[["الموظف",em?.name],["الوظيفة",em?.job],["القطاع",sec?.name],["القسم",em?.dept],["خط السير",rt?.name],["تاريخ النزول",fmt(booking.departDate)],["تاريخ العودة",fmt(booking.returnDate)],["مدة الإجازة",daysNum(booking.departDate,booking.returnDate)+" يوم"],["تاريخ التقديم",fmt(booking.createdAt)]].map(([l,v])=>(
              <div key={l} className="bcard-row"><span style={{color:"var(--txt3)",fontWeight:600}}>{l}</span><b>{v||"—"}</b></div>
            ))}
          </div>
          <div style={{display:"flex",gap:9,marginTop:16,flexWrap:"wrap"}}>
            <button className="btn btn-wa" style={{flex:1}} onClick={()=>shareWA(text)}>📲 مشاركة واتساب</button>
            <button className="btn btn-pr" style={{flex:1}} onClick={()=>window.print()}>🖨️ طباعة / PDF</button>
          </div>
          <button className="btn btn-g w100" style={{marginTop:8}} onClick={onClose}>إغلاق</button>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// LOGIN
// ═══════════════════════════════════════════════════════════════════════
function Login({onLogin, appUsers}){
  const [u,setU]=useState(""); const [p,setP]=useState(""); const [err,setErr]=useState(""); const [ld,setLd]=useState(false);
  const go=()=>{
    setLd(true);setErr("");
    setTimeout(()=>{
      const usr=appUsers.find(x=>x.username===u.trim()&&x.password===p.trim());
      if(usr) onLogin(usr);
      else{ setErr("اسم المستخدم أو كلمة المرور غير صحيحة"); setLd(false); }
    },500);
  };
  return(
    <div className="lp">
      <div className="lp-box">
        <div className="lp-brand">
          <div className="brand-name">CAIRO 3A</div>
          <div className="brand-sub">POULTRY · EGYPT</div>
          <div className="brand-sys">نظام إدارة إجازات الأسطول</div>
        </div>
        <div className="field"><label>اسم المستخدم</label>
          <input value={u} onChange={e=>setU(e.target.value)} placeholder="ادخل اسم المستخدم" className={err?"e":""} onKeyDown={e=>e.key==="Enter"&&go()}/>
        </div>
        <div className="field"><label>كلمة المرور</label>
          <input type="password" value={p} onChange={e=>setP(e.target.value)} placeholder="ادخل كلمة المرور" className={err?"e":""} onKeyDown={e=>e.key==="Enter"&&go()}/>
        </div>
        {err&&<div className="err">⚠ {err}</div>}
        <button className="btn btn-r w100" style={{marginTop:12,padding:"12px"}} onClick={go} disabled={!u||!p||ld}>
          {ld?"⏳ جاري الدخول...":"تسجيل الدخول"}
        </button>
        <div style={{textAlign:"center",marginTop:16,fontSize:11,color:"var(--txt3)"}}>Cairo 3A Poultry © {new Date().getFullYear()}</div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// EMPLOYEE BOOKING
// ═══════════════════════════════════════════════════════════════════════
function EmpBooking({user, employees, routes, sectors, bookings, setBookings, onLogout}){
  const [code,setCode]=useState(user.empCode||"");
  const [emp,setEmp]=useState(null);
  const [cErr,setCErr]=useState("");
  const [form,setForm]=useState({routeId:"",departDate:"",returnDate:""});
  const [done,setDone]=useState(false);
  const [lastBk,setLastBk]=useState(null);
  const [showCard,setShowCard]=useState(false);

  const lookup=()=>{
    const e=employees.find(x=>x.code===code.trim().toUpperCase());
    if(e){setEmp(e);setCErr("");}else{setEmp(null);setCErr("الكود غير موجود");}
  };
  const route=routes.find(r=>r.id==form.routeId);
  const valid=emp&&form.routeId&&form.departDate&&form.returnDate&&new Date(form.returnDate)>=new Date(form.departDate);
  const submit=()=>{
    const id=nextId(bookings);
    const bk={id,ref:genRef(id),empCode:emp.code,routeId:+form.routeId,departDate:form.departDate,returnDate:form.returnDate,status:"pending",createdAt:todayStr()};
    setBookings(p=>[...p,bk]); setLastBk(bk); setDone(true);
  };
  const reset=()=>{setDone(false);setLastBk(null);setForm({routeId:"",departDate:"",returnDate:""});};

  return(
    <div className="emp-page">
      <div className="emp-tbar no-print">
        <div style={{fontFamily:"Tajawal,sans-serif",fontSize:18,fontWeight:900,color:"var(--R)"}}>Cairo 3A Poultry</div>
        <button className="btn btn-g btn-sm" onClick={onLogout}>خروج 🚪</button>
      </div>
      <div style={{textAlign:"center",marginBottom:16}}>
        <div style={{fontFamily:"Tajawal,sans-serif",fontSize:20,fontWeight:900,color:"var(--txt)"}}>نموذج طلب إجازة</div>
        <div style={{fontSize:12,color:"var(--txt3)",marginTop:4}}>أدخل كودك لتسجيل طلب الإجازة</div>
      </div>
      <div className="emp-card">
        {done&&lastBk?(
          <div>
            <div style={{textAlign:"center",padding:"20px 0 16px",borderBottom:"1px solid var(--bdr)",marginBottom:16}}>
              <div style={{fontSize:48,marginBottom:8}}>✅</div>
              <div style={{fontSize:17,fontWeight:900,color:"var(--green)"}}>تم تقديم الطلب بنجاح!</div>
              <div style={{fontFamily:"monospace",fontSize:18,fontWeight:900,color:"var(--R)",marginTop:8}}>{lastBk.ref}</div>
            </div>
            {[["الموظف",emp?.name],["خط السير",route?.name],["تاريخ النزول",fmt(lastBk.departDate)],["تاريخ العودة",fmt(lastBk.returnDate)],["المدة",daysNum(lastBk.departDate,lastBk.returnDate)+" يوم"]].map(([l,v])=>(
              <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid var(--bdr2)",fontSize:13}}>
                <span style={{color:"var(--txt3)",fontWeight:600}}>{l}</span><b>{v}</b>
              </div>
            ))}
            <div style={{display:"flex",gap:9,marginTop:16}}>
              <button className="btn btn-r" style={{flex:1}} onClick={()=>setShowCard(true)}>🎫 بطاقة الحجز</button>
              <button className="btn btn-g" style={{flex:1}} onClick={reset}>↩ طلب جديد</button>
            </div>
          </div>
        ):(
          <>
            <div className="sectitle">بيانات الموظف</div>
            <div style={{display:"flex",gap:8,marginBottom:12}}>
              <div className="fg" style={{flex:1}}>
                <label>كود الموظف</label>
                <input value={code} onChange={e=>{setCode(e.target.value);setCErr("");}} placeholder="مثال: E001"
                  onKeyDown={e=>e.key==="Enter"&&lookup()} style={{fontFamily:"monospace",fontWeight:800,fontSize:15,letterSpacing:2}}/>
              </div>
              <div style={{display:"flex",alignItems:"flex-end"}}>
                <button className="btn btn-r" style={{padding:"10px 16px"}} onClick={lookup}>🔍 بحث</button>
              </div>
            </div>
            {cErr&&<div className="alert alert-r">⚠ {cErr}</div>}
            {emp&&(<>
              <div className="info-grid">
                <div className="ir"><div className="il">الاسم</div><div className="iv">{emp.name}</div></div>
                <div className="ir"><div className="il">الوظيفة</div><div className="iv">{emp.job}</div></div>
                <div className="ir"><div className="il">القطاع</div><div className="iv"><SecTag sid={emp.sectorId} sectors={sectors}/></div></div>
                <div className="ir"><div className="il">القسم</div><div className="iv">{emp.dept}</div></div>
              </div>
              <div className="divider"/>
              <div className="sectitle">تفاصيل طلب الإجازة</div>
              <div className="fgrid">
                <div className="fg"><label>تاريخ النزول</label><input type="date" value={form.departDate} min={todayStr()} onChange={e=>setForm(f=>({...f,departDate:e.target.value,returnDate:""}))}/></div>
                <div className="fg"><label>تاريخ العودة</label><input type="date" value={form.returnDate} min={form.departDate||todayStr()} onChange={e=>setForm(f=>({...f,returnDate:e.target.value}))}/></div>
                <div className="fg full"><label>خط السير</label>
                  <select value={form.routeId} onChange={e=>setForm(f=>({...f,routeId:e.target.value}))}>
                    <option value="">— اختر خط السير —</option>
                    {routes.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}
                  </select>
                </div>
              </div>
              {valid&&<div className="alert alert-g"><div style={{flex:1}}><div style={{fontWeight:700}}>{route?.name}</div><div style={{fontSize:11}}>المدة: <b>{daysNum(form.departDate,form.returnDate)} يوم</b></div></div></div>}
              <button className="btn btn-r w100" style={{padding:"12px"}} disabled={!valid} onClick={submit}>
                {valid?"✅ تقديم طلب الإجازة":"أكمل البيانات المطلوبة"}
              </button>
            </>)}
          </>
        )}
      </div>
      {showCard&&lastBk&&<BookingCardModal booking={lastBk} employees={employees} routes={routes} sectors={sectors} onClose={()=>setShowCard(false)}/>}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════════════════════════════
function Dashboard({bookings, employees, routes, trips, vehicleTypes, sectors}){
  const appr=bookings.filter(b=>b.status==="approved").length;
  const pend=bookings.filter(b=>b.status==="pending").length;
  const totalCost=trips.reduce((s,t)=>s+(t.totalCost||0),0);
  const totalVeh=trips.reduce((s,t)=>s+(t.numVehicles||0),0);
  const monthly=[2,3,5,4,6,bookings.length]; const mx=Math.max(...monthly,1);
  const secStats=sectors.map(sec=>{
    const emps=employees.filter(e=>e.sectorId===sec.id);
    const bks=bookings.filter(b=>emps.some(e=>e.code===b.empCode)&&b.status!=="rejected");
    const cost=trips.filter(t=>t.empCodes.some(c=>emps.some(e=>e.code===c))).reduce((s,t)=>s+(t.costPerEmp||0)*t.empCodes.filter(c=>emps.some(e=>e.code===c)).length,0);
    return {...sec,empCount:emps.length,bkCount:bks.length,cost};
  });
  const stats=[
    {ico:"📋",n:bookings.length,l:"إجمالي الطلبات",c:"#c8102e",bg:"#fff1f2",s:"منذ البداية"},
    {ico:"✅",n:appr,l:"طلبات مقبولة",c:"#16a34a",bg:"#f0fdf4",s:Math.round(appr/(bookings.length||1)*100)+"%"},
    {ico:"⏳",n:pend,l:"قيد المراجعة",c:"#d97706",bg:"#fef3c7",s:"تحتاج إجراء"},
    {ico:"🚌",n:totalVeh,l:"سيارات محجوزة",c:"#2563eb",bg:"#eff6ff",s:EGP(totalCost)},
  ];
  return(<>
    <div className="g4">{stats.map((s,i)=>(
      <div key={i} className="stat">
        <div className="stat-ico-wrap" style={{background:s.bg}}><span style={{fontSize:22}}>{s.ico}</span></div>
        <div className="st-n" style={{color:s.c}}>{s.n}</div>
        <div className="st-l">{s.l}</div>
        <div className="st-s">{s.s}</div>
      </div>
    ))}</div>
    <div className="g2">{secStats.map(sec=>(
      <div key={sec.id} className="mc-card" style={{borderColor:sec.color+"60",borderWidth:1.5}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
          <div style={{width:42,height:42,borderRadius:12,background:sec.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22}}>{sec.ico}</div>
          <div style={{flex:1}}><div style={{fontWeight:800,fontSize:13.5,color:sec.color}}>{sec.name}</div><div style={{fontSize:11,color:"var(--txt3)"}}>{sec.empCount} موظف</div></div>
          <div style={{textAlign:"center"}}><div style={{fontSize:22,fontWeight:900,color:sec.color}}>{sec.bkCount}</div><div style={{fontSize:10,color:"var(--txt3)"}}>طلب</div></div>
        </div>
        <div style={{display:"flex",justifyContent:"space-between",fontSize:12,alignItems:"center"}}>
          <span style={{color:"var(--txt3)"}}>إجمالي التكلفة</span>
          <span className="chip">{EGP(sec.cost)}</span>
        </div>
      </div>
    ))}</div>
    <div className="g2">
      <div className="card"><div className="ch"><div className="ct">📊 الطلبات الشهرية</div></div>
        <div className="cb"><div className="bars">{monthly.map((v,i)=><div key={i} className="bw"><div className="bv">{v}</div><div className="bar" style={{height:(v/mx)*75+"px",background:["#c8102e","#ea580c","#6b7280","#92400e","#2563eb","#16a34a"][i]||"#c8102e"}}/><div className="bl">{["يناير","فبراير","مارس","أبريل","مايو","الشهر"][i].slice(0,3)}</div></div>)}</div></div>
      </div>
      <div className="card"><div className="ch"><div className="ct">🍩 توزيع الحالات</div></div>
        <div className="cb"><Donut data={[{l:"مقبولة",v:appr,c:"#16a34a"},{l:"معلقة",v:pend,c:"#d97706"},{l:"مرفوضة",v:bookings.filter(b=>b.status==="rejected").length,c:"#dc2626"}]}/></div>
      </div>
    </div>
    <div className="card"><div className="ch"><div className="ct">🕒 آخر الطلبات</div></div>
      <div className="tbl"><table><thead><tr><th>رقم الحجز</th><th>الموظف</th><th>القطاع</th><th>خط السير</th><th>النزول</th><th>العودة</th><th>الحالة</th></tr></thead>
        <tbody>{[...bookings].slice(0,6).map(b=>{const em=employees.find(e=>e.code===b.empCode);const rt=routes.find(r=>r.id===b.routeId);return(
          <tr key={b.id}><td><span style={{fontFamily:"monospace",fontSize:11,color:"var(--R)",fontWeight:700}}>{b.ref}</span></td>
          <td><div style={{fontWeight:700}}>{em?.name||b.empCode}</div><div style={{fontSize:10,color:"var(--txt3)"}}>{em?.dept}</div></td>
          <td><SecTag sid={em?.sectorId} sectors={sectors}/></td><td>{rt?.name}</td>
          <td style={{whiteSpace:"nowrap"}}>{fmt(b.departDate)}</td><td style={{whiteSpace:"nowrap"}}>{fmt(b.returnDate)}</td>
          <td><SBadge s={b.status}/></td></tr>);})}</tbody>
      </table></div>
    </div>
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// BOOKING REQUESTS
// ═══════════════════════════════════════════════════════════════════════
function BookingRequests({bookings, setBookings, employees, routes, sectors}){
  const [filt,setFilt]=useState("all");
  const [srch,setSrch]=useState("");
  const [secF,setSecF]=useState("");
  const [cardBk,setCardBk]=useState(null);
  const filtered=bookings.filter(b=>{
    if(filt!=="all"&&b.status!==filt)return false;
    const em=employees.find(e=>e.code===b.empCode);
    if(secF&&em?.sectorId!=secF)return false;
    if(srch){const rt=routes.find(r=>r.id===b.routeId);return em?.name.includes(srch)||b.empCode.includes(srch)||b.ref?.includes(srch)||rt?.name.includes(srch);}
    return true;
  });
  const upd=(id,s)=>setBookings(p=>p.map(b=>b.id===id?{...b,status:s}:b));
  const getExp=()=>filtered.map(b=>{const em=employees.find(e=>e.code===b.empCode);const rt=routes.find(r=>r.id===b.routeId);const sec=sectors.find(s=>s.id===em?.sectorId);return{ref:b.ref,empCode:b.empCode,empName:em?.name,sector:sec?.name,dept:em?.dept,route:rt?.name,departDate:b.departDate,returnDate:b.returnDate,days:daysNum(b.departDate,b.returnDate),status:{approved:"مقبول",pending:"معلق",rejected:"مرفوض"}[b.status]};});
  const cols=[{key:"ref",label:"رقم الحجز"},{key:"empCode",label:"الكود"},{key:"empName",label:"الموظف"},{key:"sector",label:"القطاع"},{key:"dept",label:"القسم"},{key:"route",label:"خط السير"},{key:"departDate",label:"تاريخ النزول"},{key:"returnDate",label:"تاريخ العودة"},{key:"days",label:"الأيام"},{key:"status",label:"الحالة"}];
  return(<>
    <div className="card">
      <div className="ch">
        <div><div className="ct">📋 طلبات الحجز</div><div className="cs">{filtered.length} طلب</div></div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          <div className="search-box"><span>🔍</span><input placeholder="بحث باسم أو رقم حجز..." value={srch} onChange={e=>setSrch(e.target.value)}/></div>
          <select style={{background:"var(--bg)",border:"1.5px solid var(--bdr)",borderRadius:8,padding:"6px 11px",fontFamily:"Cairo",fontSize:12,color:"var(--txt)",outline:"none"}} value={secF} onChange={e=>setSecF(e.target.value)}>
            <option value="">كل القطاعات</option>{sectors.map(s=><option key={s.id} value={s.id}>{s.ico} {s.name}</option>)}
          </select>
          <button className="btn btn-xl btn-sm" onClick={()=>exportXLSX(getExp(),cols,"طلبات_الحجز")}>📊 Excel</button>
        </div>
      </div>
      <div style={{padding:"8px 12px",borderBottom:"1px solid var(--bdr)",background:"#fafafa"}}>
        <div className="tabs">{[["all","الكل"],["pending","معلقة"],["approved","مقبولة"],["rejected","مرفوضة"]].map(([v,l])=><button key={v} className={"tab"+(filt===v?" act":"")} onClick={()=>setFilt(v)}>{l}</button>)}</div>
      </div>
      <div className="tbl"><table><thead><tr><th>رقم الحجز</th><th>الموظف</th><th>القطاع</th><th>القسم</th><th>خط السير</th><th>النزول</th><th>العودة</th><th>الأيام</th><th>الحالة</th><th>إجراءات</th></tr></thead>
        <tbody>{filtered.length===0?<tr><td colSpan={10}><div className="empty">لا توجد طلبات</div></td></tr>:filtered.map(b=>{
          const em=employees.find(e=>e.code===b.empCode); const rt=routes.find(r=>r.id===b.routeId);
          return(<tr key={b.id}>
            <td><span style={{fontFamily:"monospace",color:"var(--R)",fontSize:11,fontWeight:700,cursor:"pointer",textDecoration:"underline"}} onClick={()=>setCardBk(b)}>{b.ref}</span></td>
            <td><div style={{fontWeight:700}}>{em?.name}</div><div style={{fontSize:10,color:"var(--txt3)"}}>{em?.dept}</div></td>
            <td><SecTag sid={em?.sectorId} sectors={sectors}/></td>
            <td style={{fontSize:11,color:"var(--txt3)"}}>{em?.dept}</td>
            <td>{rt?.name}</td>
            <td style={{whiteSpace:"nowrap"}}>{fmt(b.departDate)}</td>
            <td style={{whiteSpace:"nowrap"}}>{fmt(b.returnDate)}</td>
            <td style={{textAlign:"center"}}><b style={{color:"var(--R)"}}>{daysNum(b.departDate,b.returnDate)}</b></td>
            <td><SBadge s={b.status}/></td>
            <td><div style={{display:"flex",gap:4}}>
              {b.status==="pending"&&<><button className="btn btn-ok btn-sm btn-ico" onClick={()=>upd(b.id,"approved")}>✓</button><button className="btn btn-no btn-sm btn-ico" onClick={()=>upd(b.id,"rejected")}>✕</button></>}
              {b.status==="approved"&&<button className="btn btn-g btn-sm" onClick={()=>upd(b.id,"rejected")}>إلغاء</button>}
              <button className="btn btn-am btn-sm btn-ico" onClick={()=>setCardBk(b)}>🎫</button>
            </div></td>
          </tr>);})}
        </tbody>
      </table></div>
    </div>
    {cardBk&&<BookingCardModal booking={cardBk} employees={employees} routes={routes} sectors={sectors} onClose={()=>setCardBk(null)}/>}
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// TRIP MANAGER
// ═══════════════════════════════════════════════════════════════════════
function TripManager({bookings, trips, setTrips, employees, routes, vehicleTypes, sectors}){
  const [date,setDate]=useState(todayStr()); const [vtype,setVtype]=useState("depart"); const [modal,setModal]=useState(null); const [selV,setSelV]=useState(""); const [notes,setNotes]=useState("");
  const dateBks=useMemo(()=>bookings.filter(b=>{const d=vtype==="depart"?b.departDate:b.returnDate;return d===date&&b.status==="approved";}),[bookings,date,vtype]);
  const groups=useMemo(()=>{const g={};dateBks.forEach(b=>{const key=b.routeId+"-"+b.returnDate;if(!g[key])g[key]={routeId:b.routeId,departDate:b.departDate,returnDate:b.returnDate,bks:[]};g[key].bks.push(b);});return Object.values(g);},[dateBks]);
  const getTrip=(rId,dep,ret)=>trips.find(t=>t.routeId===rId&&t.departDate===dep&&t.returnDate===ret);
  const vt=vehicleTypes.find(v=>v.id==selV);
  const calc=modal&&selV&&vt?(()=>{const days=daysNum(modal.departDate,modal.returnDate);const numV=Math.ceil(modal.empCodes.length/vt.capacity);const total=vt.dailyCost*days*numV;return{days,numV,total,perEmp:Math.round(total/modal.empCodes.length),vt};})():null;
  const saveTrip=()=>{if(!calc||!modal)return;const ex=getTrip(modal.routeId,modal.departDate,modal.returnDate);const data={routeId:modal.routeId,vehicleTypeId:+selV,departDate:modal.departDate,returnDate:modal.returnDate,empCodes:modal.empCodes,numVehicles:calc.numV,days:calc.days,totalCost:calc.total,costPerEmp:calc.perEmp,notes};if(ex)setTrips(p=>p.map(t=>t.id===ex.id?{...t,...data}:t));else setTrips(p=>[...p,{id:nextId(p),...data}]);setModal(null);setSelV("");setNotes("");};
  const dayTrips=trips.filter(t=>t.departDate===date||t.returnDate===date);
  return(<>
    <div className="fbar">
      <div><label>التاريخ</label><input type="date" value={date} onChange={e=>setDate(e.target.value)}/></div>
      <div><label>عرض</label><div className="tabs" style={{marginTop:4}}><button className={"tab"+(vtype==="depart"?" act":"")} onClick={()=>setVtype("depart")}>📤 النازلون</button><button className={"tab"+(vtype==="return"?" act":"")} onClick={()=>setVtype("return")}>📥 العائدون</button></div></div>
      <div style={{marginRight:"auto",background:"var(--Rlight)",border:"1px solid #fecdd3",borderRadius:10,padding:"8px 16px",textAlign:"center"}}>
        <div style={{fontSize:24,fontWeight:900,color:"var(--R)"}}>{dateBks.length}</div><div style={{fontSize:10,color:"var(--txt3)"}}>{vtype==="depart"?"موظف ينزل":"موظف يعود"}</div>
      </div>
    </div>
    {groups.length===0?<div className="card"><div className="empty">لا يوجد موظفون في هذا التاريخ</div></div>:groups.map((g,gi)=>{
      const rt=routes.find(r=>r.id===g.routeId);const ex=getTrip(g.routeId,g.departDate,g.returnDate);const exVt=ex?vehicleTypes.find(v=>v.id===ex.vehicleTypeId):null;
      return(<div key={gi} className="rg">
        <div className="rg-h">
          <div><div style={{fontWeight:800,fontSize:14}}>🗺 {rt?.name}</div><div style={{fontSize:11,color:"var(--txt3)",marginTop:2}}>{fmt(g.departDate)} → {fmt(g.returnDate)} · {daysNum(g.departDate,g.returnDate)} يوم</div></div>
          <div style={{display:"flex",gap:8,alignItems:"center"}}><span style={{fontSize:12,color:"var(--txt3)"}}>{g.bks.length} موظف</span>
            {ex?<><span className="badge b-g">✓ تم التعيين</span><button className="btn btn-g btn-xs" onClick={()=>{setModal({...g,empCodes:g.bks.map(b=>b.empCode)});setSelV(String(ex.vehicleTypeId));}}>✏ تعديل</button></>
              :<button className="btn btn-r btn-sm" onClick={()=>setModal({...g,empCodes:g.bks.map(b=>b.empCode)})}>🚌 تعيين سيارة</button>}
          </div>
        </div>
        <div className="rg-b">
          {g.bks.map(b=>{const em=employees.find(e=>e.code===b.empCode);return(
            <div key={b.id} className="e-row"><span style={{fontFamily:"monospace",fontSize:12,color:"var(--R)",fontWeight:800}}>{b.empCode}</span><span style={{fontWeight:700,flex:1}}>{em?.name}</span><SecTag sid={em?.sectorId} sectors={sectors}/>{ex&&<span className="chip">{EGP(ex.costPerEmp)}</span>}</div>
          );})}
          {ex&&<div style={{marginTop:10,padding:"9px 12px",background:"var(--Rlight)",borderRadius:9,display:"flex",gap:14,flexWrap:"wrap",fontSize:12,border:"1px solid #fecdd3"}}><span>{exVt?.icon} {exVt?.name}</span><span>× {ex.numVehicles} سيارة</span><span>{ex.days} يوم</span><span style={{marginRight:"auto"}} className="chip">إجمالي: {EGP(ex.totalCost)}</span></div>}
        </div>
      </div>);})}
    {dayTrips.length>0&&<div className="card"><div className="ch"><div className="ct">📊 ملخص رحلات {fmt(date)}</div></div><div className="cb"><div style={{display:"flex",gap:10,flexWrap:"wrap"}}>{[{l:"مجموعات",v:dayTrips.length,c:"var(--R)"},{l:"موظفون",v:dayTrips.reduce((s,t)=>s+t.empCodes.length,0),c:"var(--green)"},{l:"سيارات",v:dayTrips.reduce((s,t)=>s+t.numVehicles,0),c:"var(--amber)"},{l:"التكلفة",v:EGP(dayTrips.reduce((s,t)=>s+t.totalCost,0)),c:"var(--blue)"}].map((s,i)=><div key={i} className="mc-card" style={{flex:"1 1 120px",textAlign:"center"}}><div style={{fontSize:17,fontWeight:900,color:s.c}}>{s.v}</div><div style={{fontSize:11,color:"var(--txt3)",marginTop:2}}>{s.l}</div></div>)}</div></div></div>}
    {modal&&<div className="overlay"><div className="modal">
      <div className="mh"><div className="mt">🚌 تعيين سيارة للمجموعة</div><button className="mc" onClick={()=>{setModal(null);setSelV("");setNotes("");}}>✕</button></div>
      <div className="mb">
        <div style={{background:"var(--bg)",borderRadius:10,padding:"11px 13px",marginBottom:14,border:"1px solid var(--bdr)"}}>
          <div style={{fontWeight:800,marginBottom:3}}>🗺 {routes.find(r=>r.id===modal.routeId)?.name}</div>
          <div style={{fontSize:12,color:"var(--txt3)"}}>{fmt(modal.departDate)} → {fmt(modal.returnDate)} · {daysNum(modal.departDate,modal.returnDate)} يوم · {modal.empCodes.length} موظف</div>
        </div>
        <div className="sectitle">اختر نوع السيارة</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat("+vehicleTypes.length+",1fr)",gap:10,marginBottom:14}}>
          {vehicleTypes.map(v=><div key={v.id} className={"vc"+(selV==v.id?" sel":"")} onClick={()=>setSelV(String(v.id))}>
            <div style={{fontSize:26,marginBottom:6}}>{v.icon}</div>
            <div style={{fontSize:12,fontWeight:800,color:"var(--txt)"}}>{v.name}</div>
            <div style={{fontSize:10,color:"var(--txt3)"}}>سعة {v.capacity} راكب</div>
            <div style={{fontSize:13,fontWeight:900,color:"var(--R)",marginTop:4}}>{EGP(v.dailyCost)}/يوم</div>
          </div>)}
        </div>
        {calc&&<div className="calc-box">{[["سعة السيارة",calc.vt.capacity+" راكب"],["عدد الموظفين",modal.empCodes.length+" موظف"],["عدد السيارات",calc.numV+" سيارة"],["عدد الأيام",calc.days+" يوم"],["سعر/يوم",EGP(calc.vt.dailyCost)],["الإجمالي",EGP(calc.total)],["تكلفة/موظف",EGP(calc.perEmp)]].map(([l,v],i)=>(
          <div key={i} className="cr" style={i===6?{marginTop:9,paddingTop:9,borderTop:"1px solid #fecdd3"}:{}}><span style={{color:"var(--txt3)"}}>{l}</span><span style={{fontWeight:i===6?900:600}}>{v}</span></div>
        ))}</div>}
        <div className="fg" style={{marginTop:12}}><label>ملاحظات</label><input value={notes} onChange={e=>setNotes(e.target.value)} placeholder="ملاحظات على هذه الرحلة..."/></div>
      </div>
      <div className="mf"><button className="btn btn-g" onClick={()=>{setModal(null);setSelV("");setNotes("");}}>إلغاء</button><button className="btn btn-r" onClick={saveTrip} disabled={!calc}>✅ تأكيد التعيين</button></div>
    </div></div>}
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// SECTORS MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════
function SectorsMgmt({sectors, setSectors}){
  const [modal,setModal]=useState(false);
  const [eid,setEid]=useState(null);
  const [form,setForm]=useState({name:"",color:"#c8102e",bg:"#fff1f2",ico:"🏢",depts:[""]});
  const colors=[{c:"#c8102e",bg:"#fff1f2"},{c:"#ea580c",bg:"#fff7ed"},{c:"#16a34a",bg:"#f0fdf4"},{c:"#2563eb",bg:"#eff6ff"},{c:"#7c3aed",bg:"#f5f3ff"},{c:"#6b7280",bg:"#f9fafb"},{c:"#92400e",bg:"#fef9c3"}];
  const openAdd=()=>{setForm({name:"",color:"#c8102e",bg:"#fff1f2",ico:"🏢",depts:[""]});setEid(null);setModal(true);};
  const openEdit=s=>{setForm({name:s.name,color:s.color,bg:s.bg,ico:s.ico,depts:[...s.depts]});setEid(s.id);setModal(true);};
  const save=()=>{
    const d={...form,id:eid||nextId(sectors),depts:form.depts.filter(d=>d.trim())};
    if(!eid)setSectors(p=>[...p,d]);else setSectors(p=>p.map(s=>s.id===eid?d:s));
    setModal(false);
  };
  const addDept=()=>setForm(f=>({...f,depts:[...f.depts,""]}));
  const updDept=(i,v)=>setForm(f=>({...f,depts:f.depts.map((d,idx)=>idx===i?v:d)}));
  const delDept=i=>setForm(f=>({...f,depts:f.depts.filter((_,idx)=>idx!==i)}));
  return(<>
    <div className="card"><div className="ch">
      <div><div className="ct">🏢 القطاعات والأقسام</div><div className="cs">{sectors.length} قطاع</div></div>
      <button className="btn btn-r btn-sm" onClick={openAdd}>+ إضافة قطاع</button>
    </div>
    <div className="cb"><div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:14}}>
      {sectors.map(sec=>(
        <div key={sec.id} className="mc-card" style={{borderColor:sec.color+"50",borderWidth:1.5}}>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
            <div style={{width:46,height:46,borderRadius:12,background:sec.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24}}>{sec.ico}</div>
            <div style={{flex:1}}><div style={{fontWeight:800,fontSize:14,color:sec.color}}>{sec.name}</div><div style={{fontSize:11,color:"var(--txt3)"}}>{sec.depts.length} قسم</div></div>
            <div style={{display:"flex",gap:5}}>
              <button className="btn btn-g btn-sm btn-ico" onClick={()=>openEdit(sec)}>✏</button>
              <button className="btn btn-no btn-sm btn-ico" onClick={()=>{if(window.confirm("حذف القطاع؟"))setSectors(p=>p.filter(s=>s.id!==sec.id));}}>🗑</button>
            </div>
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
            {sec.depts.map(d=><span key={d} style={{background:sec.bg,color:sec.color,border:"1px solid "+sec.color+"40",borderRadius:6,padding:"2px 9px",fontSize:10,fontWeight:600}}>{d}</span>)}
          </div>
        </div>
      ))}
    </div></div></div>
    {modal&&<div className="overlay"><div className="modal">
      <div className="mh"><div className="mt">{eid?"✏ تعديل قطاع":"➕ إضافة قطاع"}</div><button className="mc" onClick={()=>setModal(false)}>✕</button></div>
      <div className="mb">
        <div className="fgrid">
          <div className="fg"><label>اسم القطاع</label><input value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="قطاع التسمين"/></div>
          <div className="fg"><label>الأيقونة</label><input value={form.ico} onChange={e=>setForm(f=>({...f,ico:e.target.value}))} placeholder="🐔" style={{fontSize:18,textAlign:"center"}}/></div>
          <div className="fg full"><label>اللون والخلفية</label>
            <div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:4}}>
              {colors.map((cl,i)=><button key={i} onClick={()=>setForm(f=>({...f,color:cl.c,bg:cl.bg}))} style={{width:30,height:30,borderRadius:8,background:cl.c,border:form.color===cl.c?"3px solid #1e293b":"2px solid transparent",cursor:"pointer"}}/>)}
            </div>
          </div>
        </div>
        <div className="divider"/>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
          <div className="sectitle" style={{marginBottom:0}}>الأقسام</div>
          <button className="btn btn-g btn-xs" onClick={addDept}>+ إضافة قسم</button>
        </div>
        {form.depts.map((d,i)=>(
          <div key={i} style={{display:"flex",gap:7,marginBottom:7}}>
            <div className="fg" style={{flex:1}}><input value={d} onChange={e=>updDept(i,e.target.value)} placeholder={"اسم القسم "+(i+1)}/></div>
            {form.depts.length>1&&<button className="btn btn-no btn-sm btn-ico" onClick={()=>delDept(i)}>✕</button>}
          </div>
        ))}
      </div>
      <div className="mf"><button className="btn btn-g" onClick={()=>setModal(false)}>إلغاء</button><button className="btn btn-r" onClick={save} disabled={!form.name}>💾 حفظ</button></div>
    </div></div>}
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// USERS MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════
function UsersMgmt({appUsers, setAppUsers, employees}){
  const [modal,setModal]=useState(false);
  const [eid,setEid]=useState(null);
  const [form,setForm]=useState({username:"",password:"",role:"employee",empCode:""});
  const [srch,setSrch]=useState("");
  const [showPwd,setShowPwd]=useState({});
  const fileRef=useRef(null);
  const [bulkModal,setBulkModal]=useState(false);
  const [bulkData,setBulkData]=useState([]);

  const fil=appUsers.filter(u=>!srch||u.username.includes(srch)||(u.empCode&&u.empCode.includes(srch)));
  const openAdd=()=>{setForm({username:"",password:"",role:"employee",empCode:""});setEid(null);setModal(true);};
  const openEdit=u=>{setForm({username:u.username,password:u.password,role:u.role,empCode:u.empCode||""});setEid(u.username);setModal(true);};
  const save=()=>{
    const d={...form,empCode:form.empCode||null};
    if(!eid)setAppUsers(p=>[...p,d]);else setAppUsers(p=>p.map(u=>u.username===eid?d:u));
    setModal(false);
  };
  const del=uname=>{if(uname==="admin"){alert("لا يمكن حذف المدير الرئيسي");return;}if(window.confirm("حذف هذا المستخدم؟"))setAppUsers(p=>p.filter(u=>u.username!==uname));};

  const importFile=e=>{
    const file=e.target.files[0]; if(!file)return;
    const reader=new FileReader();
    reader.onload=ev=>{
      const data=new Uint8Array(ev.target.result);
      const wb=XLSX.read(data,{type:"array"});
      const ws=wb.Sheets[wb.SheetNames[0]];
      const rows=XLSX.utils.sheet_to_json(ws);
      const parsed=rows.filter(r=>r["اسم المستخدم"]&&r["كلمة المرور"]).map(r=>({
        username:String(r["اسم المستخدم"]).trim(),
        password:String(r["كلمة المرور"]).trim(),
        role:r["الدور"]==="admin"?"admin":"employee",
        empCode:r["كود الموظف"]?String(r["كود الموظف"]).trim():null,
      }));
      setBulkData(parsed); setBulkModal(true);
    };
    reader.readAsArrayBuffer(file); e.target.value="";
  };
  const confirmBulk=()=>{
    setAppUsers(p=>{const existing=new Set(p.map(u=>u.username));return[...p,...bulkData.filter(u=>!existing.has(u.username))];});
    setBulkModal(false); setBulkData([]);
    alert("تم الاستيراد بنجاح!");
  };
  const expCols=[{key:"username",label:"اسم المستخدم"},{key:"password",label:"كلمة المرور"},{key:"role",label:"الدور"},{key:"empCode",label:"كود الموظف"}];
  const expData=fil.map(u=>({...u,role:u.role==="admin"?"مدير":"موظف",empCode:u.empCode||"—"}));
  const downloadTemplate=()=>exportXLSX([{username:"E011",password:"pass011",role:"employee",empCode:"E011"}],[{key:"username",label:"اسم المستخدم"},{key:"password",label:"كلمة المرور"},{key:"role",label:"الدور"},{key:"empCode",label:"كود الموظف"}],"نموذج_المستخدمين");
  const autoGenAll=()=>{
    const newUsers=employees.filter(e=>!appUsers.find(u=>u.empCode===e.code)).map(e=>({username:e.code,password:`pass${e.code.slice(1)}`,role:"employee",empCode:e.code}));
    if(newUsers.length===0){alert("كل الموظفين لديهم حسابات بالفعل");return;}
    setAppUsers(p=>[...p,...newUsers]); alert(`تم إنشاء ${newUsers.length} حساب تلقائياً`);
  };

  return(<>
    <div className="card"><div className="ch">
      <div><div className="ct">🔐 إدارة المستخدمين</div><div className="cs">{appUsers.length} مستخدم مسجل</div></div>
      <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
        <div className="search-box"><span>🔍</span><input placeholder="بحث..." value={srch} onChange={e=>setSrch(e.target.value)}/></div>
        <button className="btn btn-xl btn-sm" onClick={()=>exportXLSX(expData,expCols,"المستخدمون")}>📊 تصدير</button>
        <button className="btn btn-am btn-sm" onClick={downloadTemplate}>📥 نموذج Excel</button>
        <button className="btn btn-am btn-sm" onClick={()=>fileRef.current?.click()}>📂 استيراد Excel</button>
        <button className="btn btn-pr btn-sm" onClick={autoGenAll}>⚡ توليد تلقائي</button>
        <button className="btn btn-r btn-sm" onClick={openAdd}>+ إضافة</button>
        <input ref={fileRef} type="file" accept=".xlsx,.xls" style={{display:"none"}} onChange={importFile}/>
      </div>
    </div>
    <div style={{padding:"10px 16px",background:"#fffbeb",borderBottom:"1px solid #fde68a",fontSize:11,color:"#92400e"}}>
      💡 لاستيراد من Excel: الأعمدة المطلوبة: <b>اسم المستخدم، كلمة المرور، الدور (admin/employee)، كود الموظف</b> — حمّل النموذج أولاً
    </div>
    <div className="tbl"><table><thead><tr><th>اسم المستخدم</th><th>كلمة المرور</th><th>الدور</th><th>كود الموظف</th><th>اسم الموظف</th><th>إجراءات</th></tr></thead>
      <tbody>{fil.map(u=>{const em=employees.find(e=>e.code===u.empCode);return(
        <tr key={u.username}>
          <td><span style={{fontFamily:"monospace",fontWeight:700}}>{u.username}</span></td>
          <td><div style={{display:"flex",alignItems:"center",gap:6}}>
            <span style={{fontFamily:"monospace",color:showPwd[u.username]?"var(--txt)":"var(--txt3)"}}>{showPwd[u.username]?u.password:"••••••••"}</span>
            <button className="btn btn-g btn-xs" onClick={()=>setShowPwd(s=>({...s,[u.username]:!s[u.username]}))}>👁</button>
          </div></td>
          <td><span className={u.role==="admin"?"badge b-r":"badge b-b"}>{u.role==="admin"?"👑 مدير":"👤 موظف"}</span></td>
          <td style={{fontFamily:"monospace",color:"var(--R)",fontWeight:700}}>{u.empCode||"—"}</td>
          <td>{em?.name||"—"}</td>
          <td><div style={{display:"flex",gap:5}}>
            <button className="btn btn-g btn-sm" onClick={()=>openEdit(u)}>✏ تعديل</button>
            <button className="btn btn-no btn-sm btn-ico" onClick={()=>del(u.username)}>🗑</button>
          </div></td>
        </tr>
      );})}
      </tbody>
    </table></div></div>

    {modal&&<div className="overlay"><div className="modal">
      <div className="mh"><div className="mt">{eid?"✏ تعديل مستخدم":"➕ إضافة مستخدم"}</div><button className="mc" onClick={()=>setModal(false)}>✕</button></div>
      <div className="mb"><div className="fgrid">
        <div className="fg"><label>اسم المستخدم</label><input value={form.username} onChange={e=>setForm(f=>({...f,username:e.target.value}))} disabled={!!eid} style={{fontFamily:"monospace",fontWeight:700}}/></div>
        <div className="fg"><label>كلمة المرور</label><input value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))}/></div>
        <div className="fg"><label>الدور</label><select value={form.role} onChange={e=>setForm(f=>({...f,role:e.target.value}))}><option value="employee">موظف</option><option value="admin">مدير</option></select></div>
        <div className="fg"><label>كود الموظف (اختياري)</label>
          <select value={form.empCode} onChange={e=>setForm(f=>({...f,empCode:e.target.value}))}>
            <option value="">— اختر —</option>
            {employees.map(e=><option key={e.code} value={e.code}>{e.code} - {e.name}</option>)}
          </select>
        </div>
      </div></div>
      <div className="mf"><button className="btn btn-g" onClick={()=>setModal(false)}>إلغاء</button><button className="btn btn-r" onClick={save} disabled={!form.username||!form.password}>💾 حفظ</button></div>
    </div></div>}

    {bulkModal&&<div className="overlay"><div className="modal">
      <div className="mh"><div className="mt">📥 مراجعة الاستيراد</div><button className="mc" onClick={()=>setBulkModal(false)}>✕</button></div>
      <div className="mb">
        <div className="alert alert-g">تم تحليل {bulkData.length} مستخدم للاستيراد</div>
        <div className="tbl" style={{maxHeight:250,overflowY:"auto"}}><table><thead><tr><th>اسم المستخدم</th><th>الدور</th><th>كود الموظف</th></tr></thead>
          <tbody>{bulkData.map((u,i)=><tr key={i}><td style={{fontFamily:"monospace"}}>{u.username}</td><td>{u.role==="admin"?"مدير":"موظف"}</td><td>{u.empCode||"—"}</td></tr>)}</tbody>
        </table></div>
      </div>
      <div className="mf"><button className="btn btn-g" onClick={()=>setBulkModal(false)}>إلغاء</button><button className="btn btn-r" onClick={confirmBulk}>✅ تأكيد الاستيراد</button></div>
    </div></div>}
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// VEHICLE MANAGEMENT (with price history button)
// ═══════════════════════════════════════════════════════════════════════
function VehicleMgmt({vehicleTypes, setVehicleTypes}){
  const [modal,setModal]=useState(false);
  const [eid,setEid]=useState(null);
  const [form,setForm]=useState({name:"",capacity:"",dailyCost:"",icon:"🚗"});
  const [priceModal,setPriceModal]=useState(null);
  const [histModal,setHistModal]=useState(null);
  const [newPrice,setNewPrice]=useState({cost:"",note:"",date:todayStr()});

  const openAdd=()=>{setForm({name:"",capacity:"",dailyCost:"",icon:"🚗"});setEid(null);setModal(true);};
  const openEdit=v=>{setForm({name:v.name,capacity:v.capacity,dailyCost:v.dailyCost,icon:v.icon});setEid(v.id);setModal(true);};
  const save=()=>{const d={...form,id:eid||nextId(vehicleTypes),capacity:+form.capacity,dailyCost:+form.dailyCost,priceHistory:eid?vehicleTypes.find(v=>v.id===eid)?.priceHistory||[]:[{date:todayStr(),cost:+form.dailyCost,note:"سعر التأسيس"}]};if(!eid)setVehicleTypes(p=>[...p,d]);else setVehicleTypes(p=>p.map(v=>v.id===eid?d:v));setModal(false);};
  const updatePrice=()=>{if(!priceModal||!newPrice.cost)return;setVehicleTypes(p=>p.map(v=>v.id===priceModal.id?{...v,dailyCost:+newPrice.cost,priceHistory:[...(v.priceHistory||[]),{date:newPrice.date,cost:+newPrice.cost,note:newPrice.note}]}:v));setPriceModal(null);setNewPrice({cost:"",note:"",date:todayStr()});};

  return(<>
    <div className="card"><div className="ch">
      <div><div className="ct">🚗 أنواع السيارات وتكاليف الإيجار</div><div className="cs">تغيير السعر لا يؤثر على الحجوزات السابقة ✓</div></div>
      <button className="btn btn-r btn-sm" onClick={openAdd}>+ إضافة نوع</button>
    </div>
    <div className="cb"><div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:14}}>
      {vehicleTypes.map(vt=>(
        <div key={vt.id} className="mc-card">
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
            <div style={{width:48,height:48,borderRadius:13,background:"var(--Rlight)",border:"1px solid #fecdd3",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24}}>{vt.icon}</div>
            <div><div style={{fontWeight:800,fontSize:14}}>{vt.name}</div><div style={{fontSize:11,color:"var(--txt3)"}}>سعة {vt.capacity} راكب</div></div>
          </div>
          <div style={{textAlign:"center",padding:"12px 0",borderTop:"1px solid var(--bdr)",borderBottom:"1px solid var(--bdr)",marginBottom:12}}>
            <div style={{fontSize:22,fontWeight:900,color:"var(--R)"}}>{EGP(vt.dailyCost)}</div>
            <div style={{fontSize:10,color:"var(--txt3)"}}>الإيجار اليومي الحالي</div>
          </div>
          <div style={{display:"flex",gap:5",flexWrap:"wrap"}}>
            <button className="btn btn-am btn-sm" style={{flex:1}} onClick={()=>{setPriceModal(vt);setNewPrice({cost:"",note:"",date:todayStr()});}}>💰 تعديل السعر</button>
            <button className="btn btn-pr btn-sm" style={{flex:1}} onClick={()=>setHistModal(vt)}>📋 سجل الأسعار</button>
          </div>
          <div style={{display:"flex",gap:5,marginTop:6}}>
            <button className="btn btn-g btn-sm" style={{flex:1}} onClick={()=>openEdit(vt)}>✏ تعديل</button>
            <button className="btn btn-no btn-sm btn-ico" onClick={()=>{if(window.confirm("حذف؟"))setVehicleTypes(p=>p.filter(v=>v.id!==vt.id));}}>🗑</button>
          </div>
        </div>
      ))}
      <div className="mc-card" style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",cursor:"pointer",border:"2px dashed #fecdd3",minHeight:180}} onClick={openAdd}>
        <div style={{fontSize:32,color:"var(--txt3)",marginBottom:6}}>+</div><div style={{fontSize:12,color:"var(--txt3)"}}>إضافة نوع سيارة</div>
      </div>
    </div></div></div>

    {modal&&<div className="overlay"><div className="modal">
      <div className="mh"><div className="mt">{eid?"✏ تعديل":"➕ إضافة نوع سيارة"}</div><button className="mc" onClick={()=>setModal(false)}>✕</button></div>
      <div className="mb"><div className="fgrid">
        <div className="fg"><label>اسم النوع</label><input value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="ميني باص"/></div>
        <div className="fg"><label>الأيقونة</label><input value={form.icon} onChange={e=>setForm(f=>({...f,icon:e.target.value}))} placeholder="🚌" style={{fontSize:18,textAlign:"center"}}/></div>
        <div className="fg"><label>سعة الركاب</label><input type="number" value={form.capacity} onChange={e=>setForm(f=>({...f,capacity:e.target.value}))} placeholder="14"/></div>
        <div className="fg"><label>الإيجار اليومي (ج.م)</label><input type="number" value={form.dailyCost} onChange={e=>setForm(f=>({...f,dailyCost:e.target.value}))} placeholder="700"/></div>
      </div></div>
      <div className="mf"><button className="btn btn-g" onClick={()=>setModal(false)}>إلغاء</button><button className="btn btn-r" onClick={save} disabled={!form.name||!form.capacity||!form.dailyCost}>💾 حفظ</button></div>
    </div></div>}

    {priceModal&&<div className="overlay"><div className="modal">
      <div className="mh"><div className="mt">💰 تعديل سعر: {priceModal.name}</div><button className="mc" onClick={()=>setPriceModal(null)}>✕</button></div>
      <div className="mb">
        <div className="alert alert-r">السعر الحالي: <b>{EGP(priceModal.dailyCost)}/يوم</b> — تغيير السعر لن يؤثر على الرحلات المحجوزة مسبقاً</div>
        <div className="fgrid">
          <div className="fg"><label>السعر الجديد (ج.م/يوم)</label><input type="number" value={newPrice.cost} onChange={e=>setNewPrice(f=>({...f,cost:e.target.value}))} placeholder="800"/></div>
          <div className="fg"><label>تاريخ التغيير</label><input type="date" value={newPrice.date} onChange={e=>setNewPrice(f=>({...f,date:e.target.value}))}/></div>
          <div className="fg full"><label>سبب التغيير</label><input value={newPrice.note} onChange={e=>setNewPrice(f=>({...f,note:e.target.value}))} placeholder="تعديل سعر الموسم / تجديد العقد..."/></div>
        </div>
      </div>
      <div className="mf"><button className="btn btn-g" onClick={()=>setPriceModal(null)}>إلغاء</button><button className="btn btn-am" onClick={updatePrice} disabled={!newPrice.cost}>💰 تحديث السعر</button></div>
    </div></div>}

    {histModal&&<div className="overlay"><div className="modal">
      <div className="mh"><div className="mt">📋 سجل أسعار: {histModal.name}</div><button className="mc" onClick={()=>setHistModal(null)}>✕</button></div>
      <div className="mb">
        <div className="tbl"><table><thead><tr><th>التاريخ</th><th>السعر (ج.م/يوم)</th><th>السبب / الملاحظة</th></tr></thead>
          <tbody>{[...((histModal.priceHistory||[]))].reverse().map((ph,i)=>(
            <tr key={i}>
              <td>{fmt(ph.date)}</td>
              <td><b style={{color:"var(--R)"}}>{EGP(ph.cost)}</b></td>
              <td style={{color:"var(--txt3)"}}>{ph.note||"—"}</td>
            </tr>
          ))}</tbody>
        </table></div>
        <button className="btn btn-xl btn-sm" style={{marginTop:12}} onClick={()=>exportXLSX((histModal.priceHistory||[]).map(ph=>({date:fmt(ph.date),cost:ph.cost,note:ph.note||""})),[{key:"date",label:"التاريخ"},{key:"cost",label:"السعر (ج.م)"},{key:"note",label:"الملاحظة"}],"سجل_اسعار_"+histModal.name)}>📊 تصدير Excel</button>
      </div>
      <div className="mf"><button className="btn btn-g" onClick={()=>setHistModal(null)}>إغلاق</button></div>
    </div></div>}
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// EMPLOYEE MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════
function EmployeeMgmt({employees, setEmployees, sectors}){
  const [modal,setModal]=useState(false); const [form,setForm]=useState({code:"",name:"",job:"",sectorId:"",dept:""}); const [eid,setEid]=useState(null); const [srch,setSrch]=useState(""); const [secF,setSecF]=useState(""); const fileRef=useRef(null);
  const secObj=sectors.find(s=>s.id==form.sectorId);
  const fil=employees.filter(e=>{if(secF&&e.sectorId!=secF)return false;if(srch)return e.name.includes(srch)||e.code.includes(srch);return true;});
  const openAdd=()=>{setForm({code:"",name:"",job:"",sectorId:"",dept:""});setEid(null);setModal(true);};
  const openEdit=e=>{setForm({...e});setEid(e.code);setModal(true);};
  const save=()=>{const d={...form,code:form.code.toUpperCase(),sectorId:+form.sectorId};if(!eid)setEmployees(p=>[...p,d]);else setEmployees(p=>p.map(e=>e.code===eid?d:e));setModal(false);};
  const importXLSX=e=>{const file=e.target.files[0];if(!file)return;const reader=new FileReader();reader.onload=ev=>{const data=new Uint8Array(ev.target.result);const wb=XLSX.read(data,{type:"array"});const ws=wb.Sheets[wb.SheetNames[0]];const rows=XLSX.utils.sheet_to_json(ws);const newEmps=rows.filter(r=>r["كود الموظف"]&&r["الاسم"]).map(r=>({code:String(r["كود الموظف"]).toUpperCase(),name:r["الاسم"]||"",job:r["الوظيفة"]||"",sectorId:+r["القطاع"]||1,dept:r["القسم"]||""}));setEmployees(p=>{const codes=new Set(p.map(e=>e.code));return[...p,...newEmps.filter(e=>!codes.has(e.code))];});alert(`تم استيراد ${newEmps.length} موظف!`);};reader.readAsArrayBuffer(file);e.target.value="";};
  const expCols=[{key:"code",label:"كود الموظف"},{key:"name",label:"الاسم"},{key:"job",label:"الوظيفة"},{key:"sectorName",label:"القطاع"},{key:"dept",label:"القسم"}];
  const expData=fil.map(e=>({...e,sectorName:sectors.find(s=>s.id===e.sectorId)?.name||""}));
  return(<>
    <div className="card"><div className="ch">
      <div><div className="ct">👥 الموظفون</div><div className="cs">{employees.length} موظف</div></div>
      <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
        <div className="search-box"><span>🔍</span><input placeholder="بحث..." value={srch} onChange={e=>setSrch(e.target.value)}/></div>
        <select style={{background:"var(--bg)",border:"1.5px solid var(--bdr)",borderRadius:8,padding:"6px 11px",fontFamily:"Cairo",fontSize:12,color:"var(--txt)",outline:"none"}} value={secF} onChange={e=>setSecF(e.target.value)}><option value="">كل القطاعات</option>{sectors.map(s=><option key={s.id} value={s.id}>{s.ico} {s.name}</option>)}</select>
        <button className="btn btn-xl btn-sm" onClick={()=>exportXLSX(expData,expCols,"الموظفون")}>📊 تصدير</button>
        <button className="btn btn-am btn-sm" onClick={()=>fileRef.current?.click()}>📥 استيراد Excel</button>
        <button className="btn btn-r btn-sm" onClick={openAdd}>+ إضافة</button>
        <input ref={fileRef} type="file" accept=".xlsx,.xls" style={{display:"none"}} onChange={importXLSX}/>
      </div>
    </div>
    <div className="tbl"><table><thead><tr><th>الكود</th><th>الاسم</th><th>الوظيفة</th><th>القطاع</th><th>القسم</th><th>إجراءات</th></tr></thead>
      <tbody>{fil.map(e=><tr key={e.code}>
        <td><span style={{fontFamily:"monospace",fontWeight:800,color:"var(--R)"}}>{e.code}</span></td>
        <td style={{fontWeight:700}}>{e.name}</td><td>{e.job}</td>
        <td><SecTag sid={e.sectorId} sectors={sectors}/></td>
        <td style={{color:"var(--txt3)"}}>{e.dept}</td>
        <td><div style={{display:"flex",gap:5}}><button className="btn btn-g btn-sm" onClick={()=>openEdit(e)}>✏ تعديل</button><button className="btn btn-no btn-sm btn-ico" onClick={()=>{if(window.confirm("حذف؟"))setEmployees(p=>p.filter(x=>x.code!==e.code));}}>🗑</button></div></td>
      </tr>)}</tbody>
    </table></div></div>
    {modal&&<div className="overlay"><div className="modal">
      <div className="mh"><div className="mt">{eid?"✏ تعديل موظف":"➕ إضافة موظف"}</div><button className="mc" onClick={()=>setModal(false)}>✕</button></div>
      <div className="mb"><div className="fgrid">
        <div className="fg"><label>الكود</label><input value={form.code} onChange={e=>setForm(f=>({...f,code:e.target.value}))} disabled={!!eid} style={{fontFamily:"monospace",fontWeight:700}}/></div>
        <div className="fg"><label>الاسم</label><input value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="محمد أحمد"/></div>
        <div className="fg"><label>الوظيفة</label><input value={form.job} onChange={e=>setForm(f=>({...f,job:e.target.value}))} placeholder="مهندس"/></div>
        <div className="fg"><label>القطاع</label><select value={form.sectorId} onChange={e=>setForm(f=>({...f,sectorId:e.target.value,dept:""}))}>  <option value="">— اختر —</option>{sectors.map(s=><option key={s.id} value={s.id}>{s.ico} {s.name}</option>)}</select></div>
        <div className="fg full"><label>القسم</label><select value={form.dept} onChange={e=>setForm(f=>({...f,dept:e.target.value}))} disabled={!form.sectorId}><option value="">— اختر القسم —</option>{secObj?.depts.map(d=><option key={d} value={d}>{d}</option>)}</select></div>
      </div></div>
      <div className="mf"><button className="btn btn-g" onClick={()=>setModal(false)}>إلغاء</button><button className="btn btn-r" onClick={save} disabled={!form.code||!form.name||!form.sectorId}>💾 حفظ</button></div>
    </div></div>}
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// ROUTES MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════
function RoutesMgmt({routes, setRoutes}){
  const [modal,setModal]=useState(false); const [form,setForm]=useState({name:"",from:"",to:""}); const [eid,setEid]=useState(null);
  const openAdd=()=>{setForm({name:"",from:"",to:""});setEid(null);setModal(true);};
  const openEdit=r=>{setForm({name:r.name,from:r.from,to:r.to});setEid(r.id);setModal(true);};
  const save=()=>{const d={...form,id:eid||nextId(routes)};if(!eid)setRoutes(p=>[...p,d]);else setRoutes(p=>p.map(r=>r.id===eid?d:r));setModal(false);};
  const expCols=[{key:"id",label:"#"},{key:"name",label:"اسم الخط"},{key:"from",label:"من"},{key:"to",label:"إلى"}];
  return(<>
    <div className="card"><div className="ch">
      <div><div className="ct">🗺 خطوط السير</div><div className="cs">{routes.length} خط</div></div>
      <div style={{display:"flex",gap:7}}>
        <button className="btn btn-xl btn-sm" onClick={()=>exportXLSX(routes,expCols,"خطوط_السير")}>📊 تصدير</button>
        <button className="btn btn-r btn-sm" onClick={openAdd}>+ إضافة خط</button>
      </div>
    </div>
    <div className="tbl"><table><thead><tr><th>#</th><th>اسم الخط</th><th>من</th><th>إلى</th><th>إجراءات</th></tr></thead>
      <tbody>{routes.map(r=><tr key={r.id}><td style={{color:"var(--txt3)"}}>{r.id}</td><td style={{fontWeight:700}}>{r.name}</td><td>{r.from}</td><td>{r.to}</td><td><div style={{display:"flex",gap:5}}><button className="btn btn-g btn-sm" onClick={()=>openEdit(r)}>✏ تعديل</button><button className="btn btn-no btn-sm btn-ico" onClick={()=>{if(window.confirm("حذف؟"))setRoutes(p=>p.filter(x=>x.id!==r.id));}}>🗑</button></div></td></tr>)}
      </tbody>
    </table></div></div>
    {modal&&<div className="overlay"><div className="modal">
      <div className="mh"><div className="mt">{eid?"✏ تعديل":"➕ إضافة خط سير"}</div><button className="mc" onClick={()=>setModal(false)}>✕</button></div>
      <div className="mb"><div className="fgrid">
        <div className="fg full"><label>اسم الخط</label><input value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="الرياض ← جدة"/></div>
        <div className="fg"><label>من</label><input value={form.from} onChange={e=>setForm(f=>({...f,from:e.target.value}))} placeholder="الرياض"/></div>
        <div className="fg"><label>إلى</label><input value={form.to} onChange={e=>setForm(f=>({...f,to:e.target.value}))} placeholder="جدة"/></div>
      </div></div>
      <div className="mf"><button className="btn btn-g" onClick={()=>setModal(false)}>إلغاء</button><button className="btn btn-r" onClick={save} disabled={!form.name||!form.from||!form.to}>💾 حفظ</button></div>
    </div></div>}
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// COMPREHENSIVE VEHICLES REPORT
// ═══════════════════════════════════════════════════════════════════════
function VehiclesReport({trips, bookings, employees, routes, vehicleTypes, sectors}){
  const [month,setMonth]=useState(new Date().toISOString().slice(0,7));
  const [rtF,setRtF]=useState("");
  const [vtF,setVtF]=useState("");

  const filtTrips=trips.filter(t=>{
    if(month&&!t.departDate.startsWith(month))return false;
    if(rtF&&t.routeId!=rtF)return false;
    if(vtF&&t.vehicleTypeId!=vtF)return false;
    return true;
  });

  const totalVehicles=filtTrips.reduce((s,t)=>s+t.numVehicles,0);
  const totalCost=filtTrips.reduce((s,t)=>s+t.totalCost,0);
  const totalEmp=new Set(filtTrips.flatMap(t=>t.empCodes)).size;
  const totalDays=filtTrips.reduce((s,t)=>s+t.days,0);

  const byVehicle=vehicleTypes.map(vt=>{const vtTrips=filtTrips.filter(t=>t.vehicleTypeId===vt.id);return{...vt,count:vtTrips.reduce((s,t)=>s+t.numVehicles,0),cost:vtTrips.reduce((s,t)=>s+t.totalCost,0),trips:vtTrips.length,emp:new Set(vtTrips.flatMap(t=>t.empCodes)).size};}).filter(v=>v.trips>0);

  const byRoute=routes.map(r=>{const rTrips=filtTrips.filter(t=>t.routeId===r.id);return{...r,count:rTrips.reduce((s,t)=>s+t.numVehicles,0),cost:rTrips.reduce((s,t)=>s+t.totalCost,0),trips:rTrips.length,emp:new Set(rTrips.flatMap(t=>t.empCodes)).size};}).filter(r=>r.trips>0);

  const detailCols=[{key:"route",label:"خط السير"},{key:"vehicle",label:"نوع السيارة"},{key:"departDate",label:"تاريخ النزول"},{key:"returnDate",label:"تاريخ العودة"},{key:"days",label:"الأيام"},{key:"numVehicles",label:"عدد السيارات"},{key:"numEmp",label:"الموظفون"},{key:"totalCost",label:"التكلفة الكلية (ج.م)"},{key:"costPerEmp",label:"تكلفة/موظف (ج.م)"}];
  const detailData=filtTrips.map(t=>{const rt=routes.find(r=>r.id===t.routeId);const vt=vehicleTypes.find(v=>v.id===t.vehicleTypeId);return{route:rt?.name,vehicle:vt?vt.icon+" "+vt.name:"—",departDate:t.departDate,returnDate:t.returnDate,days:t.days,numVehicles:t.numVehicles,numEmp:t.empCodes.length,totalCost:t.totalCost,costPerEmp:t.costPerEmp};});

  return(<>
    <div className="fbar">
      <div><label>الشهر</label><input type="month" value={month} onChange={e=>setMonth(e.target.value)}/></div>
      <div><label>خط السير</label><select value={rtF} onChange={e=>setRtF(e.target.value)}><option value="">الكل</option>{routes.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
      <div><label>نوع السيارة</label><select value={vtF} onChange={e=>setVtF(e.target.value)}><option value="">الكل</option>{vehicleTypes.map(v=><option key={v.id} value={v.id}>{v.icon} {v.name}</option>)}</select></div>
      <button className="btn btn-xl btn-sm" onClick={()=>exportXLSX(detailData,detailCols,"تقرير_السيارات")}>📊 تصدير Excel</button>
    </div>

    <div className="g4">
      {[{ico:"🚌",n:totalVehicles,l:"إجمالي السيارات المحجوزة",c:"#c8102e",bg:"#fff1f2"},{ico:"💰",n:EGP(totalCost),l:"إجمالي التكلفة",c:"#16a34a",bg:"#f0fdf4"},{ico:"👥",n:totalEmp,l:"إجمالي الموظفين",c:"#2563eb",bg:"#eff6ff"},{ico:"📅",n:totalDays,l:"إجمالي أيام الإيجار",c:"#d97706",bg:"#fef3c7"}].map((s,i)=>(
        <div key={i} className="stat"><div className="stat-ico-wrap" style={{background:s.bg}}><span style={{fontSize:22}}>{s.ico}</span></div><div className="st-n" style={{color:s.c,fontSize:20}}>{s.n}</div><div className="st-l">{s.l}</div></div>
      ))}
    </div>

    <div className="g2">
      <div className="card"><div className="ch"><div className="ct">🚗 تفصيل حسب نوع السيارة</div></div>
        {byVehicle.length===0?<div className="empty">لا توجد بيانات</div>:<div className="tbl"><table><thead><tr><th>النوع</th><th>الرحلات</th><th>السيارات</th><th>الموظفون</th><th>التكلفة</th></tr></thead>
          <tbody>{byVehicle.map(v=><tr key={v.id}><td><span style={{fontWeight:700}}>{v.icon} {v.name}</span></td><td style={{textAlign:"center"}}>{v.trips}</td><td style={{textAlign:"center",fontWeight:700,color:"var(--R)"}}>{v.count}</td><td style={{textAlign:"center"}}>{v.emp}</td><td><span className="chip">{EGP(v.cost)}</span></td></tr>)}
            <tr style={{background:"#fafafa",fontWeight:800}}><td>الإجمالي</td><td style={{textAlign:"center"}}>{byVehicle.reduce((s,v)=>s+v.trips,0)}</td><td style={{textAlign:"center",color:"var(--R)"}}>{totalVehicles}</td><td style={{textAlign:"center"}}>{totalEmp}</td><td><span className="chip">{EGP(totalCost)}</span></td></tr>
          </tbody>
        </table></div>}
      </div>
      <div className="card"><div className="ch"><div className="ct">🗺 تفصيل حسب خط السير</div></div>
        {byRoute.length===0?<div className="empty">لا توجد بيانات</div>:<div className="tbl"><table><thead><tr><th>الخط</th><th>الرحلات</th><th>السيارات</th><th>التكلفة</th></tr></thead>
          <tbody>{byRoute.map(r=><tr key={r.id}><td style={{fontWeight:700}}>{r.name}</td><td style={{textAlign:"center"}}>{r.trips}</td><td style={{textAlign:"center",fontWeight:700,color:"var(--R)"}}>{r.count}</td><td><span className="chip">{EGP(r.cost)}</span></td></tr>)}
          </tbody>
        </table></div>}
      </div>
    </div>

    <div className="card"><div className="ch"><div className="ct">📋 تفاصيل جميع الرحلات</div><div className="cs">{filtTrips.length} رحلة</div></div>
      {filtTrips.length===0?<div className="empty">لا توجد رحلات</div>:<div className="tbl"><table><thead><tr><th>خط السير</th><th>السيارة</th><th>النزول</th><th>العودة</th><th>الأيام</th><th>السيارات</th><th>الموظفون</th><th>التكلفة</th><th>تكلفة/موظف</th></tr></thead>
        <tbody>{filtTrips.map(t=>{const rt=routes.find(r=>r.id===t.routeId);const vt=vehicleTypes.find(v=>v.id===t.vehicleTypeId);return(
          <tr key={t.id}><td style={{fontWeight:700}}>{rt?.name}</td><td>{vt&&<span>{vt.icon} {vt.name}</span>}</td>
          <td style={{whiteSpace:"nowrap"}}>{fmt(t.departDate)}</td><td style={{whiteSpace:"nowrap"}}>{fmt(t.returnDate)}</td>
          <td style={{textAlign:"center",fontWeight:700,color:"var(--R)"}}>{t.days}</td>
          <td style={{textAlign:"center",fontWeight:800}}>{t.numVehicles}</td>
          <td style={{textAlign:"center"}}>{t.empCodes.length}</td>
          <td><span className="chip">{EGP(t.totalCost)}</span></td>
          <td style={{color:"var(--txt3)"}}>{EGP(t.costPerEmp)}</td>
          </tr>);})}
        </tbody>
      </table></div>}
    </div>
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// DAILY REPORT
// ═══════════════════════════════════════════════════════════════════════
function DailyReport({bookings, trips, employees, routes, vehicleTypes, sectors}){
  const [date,setDate]=useState(todayStr()); const [type,setType]=useState("depart"); const [secF,setSecF]=useState("");
  const bks=bookings.filter(b=>{const d=type==="depart"?b.departDate:b.returnDate;if(d!==date||b.status==="rejected")return false;if(secF){const em=employees.find(e=>e.code===b.empCode);return em?.sectorId==secF;}return true;});
  const getTrip=b=>trips.find(t=>t.empCodes.includes(b.empCode)&&t.routeId===b.routeId&&t.departDate===b.departDate);
  const totalVeh=[...new Set(bks.map(b=>getTrip(b)).filter(Boolean).map(t=>t.id))].map(id=>trips.find(t=>t.id===id)).reduce((s,t)=>s+(t?.numVehicles||0),0);
  const expCols=[{key:"ref",label:"رقم الحجز"},{key:"code",label:"الكود"},{key:"name",label:"الاسم"},{key:"job",label:"الوظيفة"},{key:"sector",label:"القطاع"},{key:"dept",label:"القسم"},{key:"route",label:"خط السير"},{key:"departDate",label:"تاريخ النزول"},{key:"returnDate",label:"تاريخ العودة"},{key:"days",label:"الأيام"},{key:"vehicle",label:"السيارة"},{key:"cost",label:"التكلفة (ج.م)"}];
  const expData=bks.map(b=>{const em=employees.find(e=>e.code===b.empCode);const rt=routes.find(r=>r.id===b.routeId);const trip=getTrip(b);const vt=trip?vehicleTypes.find(v=>v.id===trip.vehicleTypeId):null;const sec=sectors.find(s=>s.id===em?.sectorId);return{ref:b.ref,code:b.empCode,name:em?.name,job:em?.job,sector:sec?.name,dept:em?.dept,route:rt?.name,departDate:b.departDate,returnDate:b.returnDate,days:daysNum(b.departDate,b.returnDate),vehicle:vt?vt.name:"—",cost:trip?.costPerEmp||0};});
  return(<>
    <div className="fbar">
      <div><label>نوع</label><div className="tabs" style={{marginTop:4}}><button className={"tab"+(type==="depart"?" act":"")} onClick={()=>setType("depart")}>📤 النزول</button><button className={"tab"+(type==="return"?" act":"")} onClick={()=>setType("return")}>📥 العودة</button></div></div>
      <div><label>التاريخ</label><input type="date" value={date} onChange={e=>setDate(e.target.value)}/></div>
      <div><label>القطاع</label><select value={secF} onChange={e=>setSecF(e.target.value)}><option value="">الكل</option>{sectors.map(s=><option key={s.id} value={s.id}>{s.ico} {s.name}</option>)}</select></div>
      <div style={{marginRight:"auto",display:"flex",gap:10}}>
        <div className="mc-card" style={{textAlign:"center",minWidth:72}}><div style={{fontSize:22,fontWeight:900,color:"var(--R)"}}>{bks.length}</div><div style={{fontSize:10,color:"var(--txt3)"}}>موظف</div></div>
        <div className="mc-card" style={{textAlign:"center",minWidth:72}}><div style={{fontSize:22,fontWeight:900,color:"var(--amber)"}}>{totalVeh}</div><div style={{fontSize:10,color:"var(--txt3)"}}>سيارة</div></div>
      </div>
      <div style={{display:"flex",gap:7"}}>
        <button className="btn btn-xl btn-sm" onClick={()=>exportXLSX(expData,expCols,`تقرير_${date}`)}>📊 Excel</button>
        <button className="btn btn-pr btn-sm" onClick={()=>window.print()}>🖨 طباعة</button>
      </div>
    </div>
    <div className="card"><div className="ch"><div><div className="ct">{type==="depart"?"📤 قائمة النزول":"📥 قائمة العودة"} — {fmt(date)}</div><div className="cs">{bks.length} موظف</div></div></div>
      {bks.length===0?<div className="empty">لا يوجد موظفون</div>:<div className="tbl"><table><thead><tr><th>رقم الحجز</th><th>الكود</th><th>الاسم</th><th>القطاع</th><th>القسم</th><th>خط السير</th><th>النزول</th><th>العودة</th><th>الأيام</th><th>السيارة</th><th>التكلفة</th></tr></thead>
        <tbody>{bks.map((b,i)=>{const em=employees.find(e=>e.code===b.empCode);const rt=routes.find(r=>r.id===b.routeId);const trip=getTrip(b);const vt=trip?vehicleTypes.find(v=>v.id===trip.vehicleTypeId):null;return(
          <tr key={b.id}><td><span style={{fontFamily:"monospace",color:"var(--R)",fontSize:11,fontWeight:700}}>{b.ref}</span></td><td style={{fontFamily:"monospace",fontWeight:700}}>{b.empCode}</td><td style={{fontWeight:700}}>{em?.name}</td><td><SecTag sid={em?.sectorId} sectors={sectors}/></td><td style={{color:"var(--txt3)"}}>{em?.dept}</td><td>{rt?.name}</td><td style={{whiteSpace:"nowrap"}}>{fmt(b.departDate)}</td><td style={{whiteSpace:"nowrap"}}>{fmt(b.returnDate)}</td><td style={{textAlign:"center",fontWeight:800,color:"var(--R)"}}>{daysNum(b.departDate,b.returnDate)}</td><td>{vt?<span>{vt.icon} {vt.name}</span>:"—"}</td><td>{trip?<span className="chip">{EGP(trip.costPerEmp)}</span>:"—"}</td>
          </tr>);})}
        </tbody>
      </table></div>}
    </div>
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// SECTOR REPORT
// ═══════════════════════════════════════════════════════════════════════
function SectorReport({bookings, trips, employees, routes, sectors}){
  const [secF,setSecF]=useState(""); const [deptF,setDeptF]=useState(""); const [month,setMonth]=useState(""); const [rtF,setRtF]=useState("");
  const secObj=sectors.find(s=>s.id==secF);
  const filtBks=bookings.filter(b=>{if(b.status==="rejected")return false;const em=employees.find(e=>e.code===b.empCode);if(!em)return false;if(secF&&em.sectorId!=secF)return false;if(deptF&&em.dept!==deptF)return false;if(rtF&&b.routeId!=rtF)return false;if(month&&!b.departDate.startsWith(month))return false;return true;});
  const getEmpCost=code=>trips.filter(t=>t.empCodes.includes(code)).reduce((s,t)=>s+(t.costPerEmp||0),0);
  const sData=sectors.filter(s=>!secF||s.id==secF).map(s=>{const emps=employees.filter(e=>e.sectorId===s.id&&(!deptF||e.dept===deptF));const sbks=filtBks.filter(b=>emps.some(e=>e.code===b.empCode));const cost=emps.reduce((sum,e)=>sum+getEmpCost(e.code),0);const deptData=s.depts.filter(d=>!deptF||d===deptF).map(d=>{const demps=emps.filter(e=>e.dept===d);const dbks=sbks.filter(b=>demps.some(e=>e.code===b.empCode));return{dept:d,empCount:demps.length,bkCount:dbks.length,cost:demps.reduce((sum,e)=>sum+getEmpCost(e.code),0)};}).filter(d=>d.empCount>0);return{...s,emps,bkCount:sbks.length,cost,deptData};});
  const expData=sData.flatMap(s=>s.deptData.map(d=>({sector:s.name,dept:d.dept,empCount:d.empCount,bkCount:d.bkCount,cost:d.cost})));
  const cols=[{key:"sector",label:"القطاع"},{key:"dept",label:"القسم"},{key:"empCount",label:"الموظفون"},{key:"bkCount",label:"الطلبات"},{key:"cost",label:"التكلفة (ج.م)"}];
  return(<>
    <div className="fbar">
      <div><label>القطاع</label><select value={secF} onChange={e=>{setSecF(e.target.value);setDeptF("");}}><option value="">كل القطاعات</option>{sectors.map(s=><option key={s.id} value={s.id}>{s.ico} {s.name}</option>)}</select></div>
      {secObj&&<div><label>القسم</label><select value={deptF} onChange={e=>setDeptF(e.target.value)}><option value="">كل الأقسام</option>{secObj.depts.map(d=><option key={d} value={d}>{d}</option>)}</select></div>}
      <div><label>خط السير</label><select value={rtF} onChange={e=>setRtF(e.target.value)}><option value="">الكل</option>{routes.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
      <div><label>الشهر</label><input type="month" value={month} onChange={e=>setMonth(e.target.value)}/></div>
      <button className="btn btn-xl btn-sm" onClick={()=>exportXLSX(expData,cols,"تقرير_القطاعات")}>📊 Excel</button>
    </div>
    <div className="g3">{[{l:"إجمالي الطلبات",v:filtBks.length,c:"#c8102e",bg:"#fff1f2"},{l:"إجمالي الموظفين",v:[...new Set(filtBks.map(b=>b.empCode))].length,c:"#16a34a",bg:"#f0fdf4"},{l:"إجمالي التكلفة",v:EGP(sData.reduce((s,x)=>s+x.cost,0)),c:"#d97706",bg:"#fef3c7"}].map((s,i)=>(
      <div key={i} className="stat"><div className="stat-ico-wrap" style={{background:s.bg}}/><div className="st-n" style={{color:s.c,fontSize:20}}>{s.v}</div><div className="st-l">{s.l}</div></div>
    ))}</div>
    {sData.map(sec=><div key={sec.id} className="card"><div className="ch" style={{background:sec.bg}}>
      <div style={{display:"flex",alignItems:"center",gap:10}}><div style={{fontSize:22}}>{sec.ico}</div><div><div className="ct" style={{color:sec.color}}>{sec.name}</div><div className="cs">{sec.emps.length} موظف · {sec.bkCount} طلب</div></div></div>
      <span className="chip">{EGP(sec.cost)}</span>
    </div>
    {sec.deptData.length>0&&<div className="tbl"><table><thead><tr><th>القسم</th><th>الموظفون</th><th>الطلبات</th><th>التكلفة</th></tr></thead><tbody>{sec.deptData.map(d=><tr key={d.dept}><td style={{fontWeight:700}}>{d.dept}</td><td style={{textAlign:"center"}}>{d.empCount}</td><td style={{textAlign:"center"}}>{d.bkCount}</td><td><span className="chip">{EGP(d.cost)}</span></td></tr>)}</tbody></table></div>}
    </div>)}
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// EMP COST REPORT
// ═══════════════════════════════════════════════════════════════════════
function EmpCostReport({bookings, trips, employees, sectors}){
  const [secF,setSecF]=useState(""); const [month,setMonth]=useState("");
  const data=employees.filter(e=>!secF||e.sectorId==secF).map(e=>{const ebks=bookings.filter(b=>b.empCode===e.code&&b.status!=="rejected"&&(!month||b.departDate.startsWith(month)));const etrips=trips.filter(t=>t.empCodes.includes(e.code)&&(!month||t.departDate.startsWith(month)));const totalCost=etrips.reduce((s,t)=>s+(t.costPerEmp||0),0);const totalDays=ebks.reduce((s,b)=>s+daysNum(b.departDate,b.returnDate),0);return{...e,bkCount:ebks.length,totalCost,totalDays};}).filter(e=>e.bkCount>0).sort((a,b)=>b.totalCost-a.totalCost);
  const maxC=Math.max(...data.map(e=>e.totalCost),1);
  const cols=[{key:"code",label:"الكود"},{key:"name",label:"الموظف"},{key:"sectorName",label:"القطاع"},{key:"dept",label:"القسم"},{key:"bkCount",label:"الطلبات"},{key:"totalDays",label:"الأيام"},{key:"totalCost",label:"التكلفة (ج.م)"}];
  const expData=data.map(e=>({...e,sectorName:sectors.find(s=>s.id===e.sectorId)?.name||""}));
  return(<>
    <div className="fbar">
      <div><label>القطاع</label><select value={secF} onChange={e=>setSecF(e.target.value)}><option value="">كل القطاعات</option>{sectors.map(s=><option key={s.id} value={s.id}>{s.ico} {s.name}</option>)}</select></div>
      <div><label>الشهر</label><input type="month" value={month} onChange={e=>setMonth(e.target.value)}/></div>
      <button className="btn btn-xl btn-sm" onClick={()=>exportXLSX(expData,cols,"تكاليف_الموظفين")}>📊 Excel</button>
    </div>
    <div className="card"><div className="ch"><div><div className="ct">💰 تكاليف الموظفين</div><div className="cs">{data.length} موظف</div></div><span className="chip">{EGP(data.reduce((s,e)=>s+e.totalCost,0))} إجمالي</span></div>
      <div className="tbl"><table><thead><tr><th>م</th><th>الكود</th><th>الموظف</th><th>القطاع</th><th>القسم</th><th>الطلبات</th><th>الأيام</th><th>التكلفة</th><th>النسبة</th></tr></thead>
        <tbody>{data.map((e,i)=><tr key={e.code}>
          <td style={{color:"var(--txt3)"}}>{i+1}</td>
          <td><span style={{fontFamily:"monospace",fontWeight:800,color:"var(--R)"}}>{e.code}</span></td>
          <td style={{fontWeight:700}}>{e.name}</td>
          <td><SecTag sid={e.sectorId} sectors={sectors}/></td>
          <td style={{color:"var(--txt3)"}}>{e.dept}</td>
          <td style={{textAlign:"center",fontWeight:700}}>{e.bkCount}</td>
          <td style={{textAlign:"center",fontWeight:700,color:"var(--R)"}}>{e.totalDays}</td>
          <td><span className="chip">{EGP(e.totalCost)}</span></td>
          <td style={{minWidth:130}}><div style={{display:"flex",alignItems:"center",gap:7}}><div className="prog-bar" style={{flex:1}}><div className="prog" style={{width:(e.totalCost/maxC*100)+"%",background:"var(--R)"}}/></div><span style={{fontSize:10,color:"var(--txt3)",width:30,textAlign:"left"}}>{Math.round(e.totalCost/maxC*100)}%</span></div></td>
        </tr>)}
        </tbody>
      </table></div>
    </div>
  </>);
}

// ═══════════════════════════════════════════════════════════════════════
// EXPORT ALL DATA
// ═══════════════════════════════════════════════════════════════════════
function ExportAll({employees, bookings, trips, routes, vehicleTypes, sectors, appUsers}){
  const exports=[
    {label:"📥 تصدير الموظفين",fn:()=>exportXLSX(employees.map(e=>({...e,sectorName:sectors.find(s=>s.id===e.sectorId)?.name||""})),[{key:"code",label:"كود الموظف"},{key:"name",label:"الاسم"},{key:"job",label:"الوظيفة"},{key:"sectorName",label:"القطاع"},{key:"dept",label:"القسم"}],"الموظفون")},
    {label:"📥 تصدير الحجوزات",fn:()=>exportXLSX(bookings.map(b=>{const em=employees.find(e=>e.code===b.empCode);const rt=routes.find(r=>r.id===b.routeId);const sec=sectors.find(s=>s.id===em?.sectorId);return{ref:b.ref,empCode:b.empCode,empName:em?.name,sector:sec?.name,route:rt?.name,departDate:b.departDate,returnDate:b.returnDate,status:{approved:"مقبول",pending:"معلق",rejected:"مرفوض"}[b.status]};}),[{key:"ref",label:"رقم الحجز"},{key:"empCode",label:"الكود"},{key:"empName",label:"الموظف"},{key:"sector",label:"القطاع"},{key:"route",label:"خط السير"},{key:"departDate",label:"تاريخ النزول"},{key:"returnDate",label:"تاريخ العودة"},{key:"status",label:"الحالة"}],"الحجوزات")},
    {label:"📥 تصدير الرحلات",fn:()=>exportXLSX(trips.map(t=>{const rt=routes.find(r=>r.id===t.routeId);const vt=vehicleTypes.find(v=>v.id===t.vehicleTypeId);return{route:rt?.name,vehicle:vt?.name,departDate:t.departDate,returnDate:t.returnDate,days:t.days,numVehicles:t.numVehicles,numEmp:t.empCodes.length,totalCost:t.totalCost,costPerEmp:t.costPerEmp};}),[{key:"route",label:"خط السير"},{key:"vehicle",label:"السيارة"},{key:"departDate",label:"تاريخ النزول"},{key:"returnDate",label:"تاريخ العودة"},{key:"days",label:"الأيام"},{key:"numVehicles",label:"السيارات"},{key:"numEmp",label:"الموظفون"},{key:"totalCost",label:"التكلفة (ج.م)"},{key:"costPerEmp",label:"تكلفة/موظف (ج.م)"}],"الرحلات")},
    {label:"📥 تصدير خطوط السير",fn:()=>exportXLSX(routes,[{key:"id",label:"#"},{key:"name",label:"اسم الخط"},{key:"from",label:"من"},{key:"to",label:"إلى"}],"خطوط_السير")},
    {label:"📥 تصدير القطاعات",fn:()=>exportXLSX(sectors.flatMap(s=>s.depts.map(d=>({sector:s.name,dept:d,ico:s.ico}))),[{key:"sector",label:"القطاع"},{key:"ico",label:"الأيقونة"},{key:"dept",label:"القسم"}],"القطاعات_والاقسام")},
    {label:"📥 تصدير المستخدمين",fn:()=>exportXLSX(appUsers,[{key:"username",label:"اسم المستخدم"},{key:"password",label:"كلمة المرور"},{key:"role",label:"الدور"},{key:"empCode",label:"كود الموظف"}],"المستخدمون")},
  ];
  const exportAllInOne=()=>{
    const wb=XLSX.utils.book_new();
    [["الموظفون",employees.map(e=>({code:e.code,name:e.name,job:e.job,sector:sectors.find(s=>s.id===e.sectorId)?.name||"",dept:e.dept}))],["الحجوزات",bookings.map(b=>{const em=employees.find(e=>e.code===b.empCode);const rt=routes.find(r=>r.id===b.routeId);return{ref:b.ref,empCode:b.empCode,empName:em?.name,route:rt?.name,departDate:b.departDate,returnDate:b.returnDate,status:b.status};})],["خطوط السير",routes.map(r=>({id:r.id,name:r.name,from:r.from,to:r.to}))],["أنواع السيارات",vehicleTypes.map(v=>({name:v.name,capacity:v.capacity,dailyCost:v.dailyCost}))]].forEach(([name,data])=>{XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(data),name);});
    XLSX.writeFile(wb,"Cairo3A_Fleet_كامل.xlsx");
  };
  return(
    <div className="card"><div className="ch"><div className="ct">📦 تصدير البيانات</div><div className="cs">تصدير جميع بيانات النظام</div></div>
      <div className="cb">
        <div className="alert alert-g" style={{marginBottom:16}}>يمكنك تصدير كل قسم بشكل منفصل أو تصدير الكل في ملف واحد</div>
        <button className="btn btn-r w100" style={{marginBottom:16,padding:"13px"}} onClick={exportAllInOne}>📦 تصدير الكل في ملف واحد</button>
        <div className="divider"/>
        <div className="sectitle">تصدير منفصل</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
          {exports.map((ex,i)=><button key={i} className="btn btn-xl" style={{justifyContent:"flex-start",padding:"10px 14px"}} onClick={ex.fn}>{ex.label}</button>)}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// ADMIN APP
// ═══════════════════════════════════════════════════════════════════════
function AdminApp({user, onLogout, appUsers, setAppUsers}){
  const [page,setPage]=useState("dashboard");
  const [sectors,setSectors]=useState(initSectors);
  const [employees,setEmployees]=useState(initEmployees);
  const [routes,setRoutes]=useState(initRoutes);
  const [vehicleTypes,setVehicleTypes]=useState(initVehicles);
  const [bookings,setBookings]=useState(initBookings);
  const [trips,setTrips]=useState(initTrips);
  const pend=bookings.filter(b=>b.status==="pending").length;

  const NAV=[
    {id:"dashboard", ico:"📊", lbl:"لوحة التحكم"},
    {id:"requests",  ico:"📋", lbl:"طلبات الحجز",   badge:pend},
    {id:"trips",     ico:"🚌", lbl:"إدارة الرحلات"},
    {sec:"إدارة البيانات"},
    {id:"employees", ico:"👥", lbl:"الموظفون"},
    {id:"sectors",   ico:"🏢", lbl:"القطاعات والأقسام"},
    {id:"routes",    ico:"🗺", lbl:"خطوط السير"},
    {id:"vehicles",  ico:"🚗", lbl:"أنواع السيارات"},
    {id:"users",     ico:"🔐", lbl:"إدارة المستخدمين"},
    {sec:"التقارير"},
    {id:"daily",     ico:"📅", lbl:"التقرير اليومي"},
    {id:"sectors2",  ico:"🏭", lbl:"تقرير القطاعات"},
    {id:"vehrpt",    ico:"🚌", lbl:"تقرير السيارات"},
    {id:"empcost",   ico:"💰", lbl:"تكاليف الموظفين"},
    {sec:"البيانات"},
    {id:"exportall", ico:"📦", lbl:"تصدير الكل"},
  ];
  const TITLES={
    dashboard:{t:"لوحة التحكم",s:"نظرة شاملة على النظام"},
    requests: {t:"طلبات الحجز",s:"مراجعة وإدارة طلبات الموظفين"},
    trips:    {t:"إدارة الرحلات",s:"تعيين السيارات وحساب التكاليف"},
    employees:{t:"الموظفون",s:employees.length+" موظف مسجل"},
    sectors:  {t:"القطاعات والأقسام",s:"إضافة وتعديل القطاعات والأقسام"},
    routes:   {t:"خطوط السير",s:"إدارة مسارات الرحلات"},
    vehicles: {t:"أنواع السيارات",s:"إدارة الأسطول وسجل الأسعار"},
    users:    {t:"إدارة المستخدمين",s:"بيانات الدخول لكل موظف"},
    daily:    {t:"التقرير اليومي",s:"النازلون والعائدون"},
    sectors2: {t:"تقرير القطاعات",s:"تحليل حسب القطاع والقسم"},
    vehrpt:   {t:"تقرير السيارات",s:"السيارات المحجوزة والتكاليف"},
    empcost:  {t:"تكاليف الموظفين",s:"تحليل تكلفة إجازات كل موظف"},
    exportall:{t:"تصدير البيانات",s:"تصدير جميع بيانات النظام"},
  };

  return(
    <div className="app">
      <div className="sidebar">
        <div className="sb-brand">
          <div className="sb-title">CAIRO 3A</div>
          <div className="sb-subtitle">POULTRY · EGYPT</div>
          <div className="sb-sysname">نظام إدارة إجازات الأسطول</div>
        </div>
        <div className="nav">{NAV.map((item,i)=>item.sec?<div key={i} className="nsec">{item.sec}</div>:<button key={item.id} className={"ni"+(page===item.id?" act":"")} onClick={()=>setPage(item.id)}><span className="n-ico">{item.ico}</span>{item.lbl}{item.badge>0&&<span className="n-bdg">{item.badge}</span>}</button>)}</div>
        <div className="sb-foot">
          <div className="u-chip"><div className="u-av">A</div><div><div className="u-n">المدير العام</div><div className="u-r">صلاحيات كاملة</div></div></div>
          <button className="logout" onClick={onLogout}>🚪 تسجيل الخروج</button>
        </div>
      </div>
      <div className="main">
        <div className="topbar">
          <div><div className="ph">{TITLES[page]?.t}</div><div className="ps">{TITLES[page]?.s}</div></div>
          <div style={{display:"flex",gap:8,alignItems:"center"}}>
            {pend>0&&<button className="btn btn-am btn-sm" onClick={()=>setPage("requests")}>⏳ {pend} طلب معلق</button>}
            <div style={{fontFamily:"Tajawal,sans-serif",fontSize:14,fontWeight:900,color:"var(--R)"}}>3A</div>
          </div>
        </div>
        <div className="content">
          {page==="dashboard" && <Dashboard bookings={bookings} employees={employees} routes={routes} trips={trips} vehicleTypes={vehicleTypes} sectors={sectors}/>}
          {page==="requests"  && <BookingRequests bookings={bookings} setBookings={setBookings} employees={employees} routes={routes} sectors={sectors}/>}
          {page==="trips"     && <TripManager bookings={bookings} trips={trips} setTrips={setTrips} employees={employees} routes={routes} vehicleTypes={vehicleTypes} sectors={sectors}/>}
          {page==="employees" && <EmployeeMgmt employees={employees} setEmployees={setEmployees} sectors={sectors}/>}
          {page==="sectors"   && <SectorsMgmt sectors={sectors} setSectors={setSectors}/>}
          {page==="routes"    && <RoutesMgmt routes={routes} setRoutes={setRoutes}/>}
          {page==="vehicles"  && <VehicleMgmt vehicleTypes={vehicleTypes} setVehicleTypes={setVehicleTypes}/>}
          {page==="users"     && <UsersMgmt appUsers={appUsers} setAppUsers={setAppUsers} employees={employees}/>}
          {page==="daily"     && <DailyReport bookings={bookings} trips={trips} employees={employees} routes={routes} vehicleTypes={vehicleTypes} sectors={sectors}/>}
          {page==="sectors2"  && <SectorReport bookings={bookings} trips={trips} employees={employees} routes={routes} sectors={sectors}/>}
          {page==="vehrpt"    && <VehiclesReport trips={trips} bookings={bookings} employees={employees} routes={routes} vehicleTypes={vehicleTypes} sectors={sectors}/>}
          {page==="empcost"   && <EmpCostReport bookings={bookings} trips={trips} employees={employees} sectors={sectors}/>}
          {page==="exportall" && <ExportAll employees={employees} bookings={bookings} trips={trips} routes={routes} vehicleTypes={vehicleTypes} sectors={sectors} appUsers={appUsers}/>}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// ROOT
// ═══════════════════════════════════════════════════════════════════════
export default function App(){
  const [user,setUser]=useState(null);
  const [appUsers,setAppUsers]=useState(initUsers);
  const [employees]=useState(initEmployees);
  const [routes]=useState(initRoutes);
  const [sectors]=useState(initSectors);
  const [bookings,setBookings]=useState(initBookings);
  return(<>
    <style>{CSS}</style>
    {!user && <Login onLogin={setUser} appUsers={appUsers}/>}
    {user?.role==="admin"    && <AdminApp user={user} onLogout={()=>setUser(null)} appUsers={appUsers} setAppUsers={setAppUsers}/>}
    {user?.role==="employee" && <EmpBooking user={user} employees={employees} routes={routes} sectors={sectors} bookings={bookings} setBookings={setBookings} onLogout={()=>setUser(null)}/>}
  </>);
}
