extends SceneTree
# Renders the hero in several poses to PNGs (visual check of the generated model).
func _init():
	var out := "/tmp/hero_shots"
	DirAccess.make_dir_recursive_absolute(out)
	var world := Node3D.new()
	root.add_child(world)
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.55, 0.8, 1.0)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(1, 1, 1)
	e.ambient_light_energy = 0.75
	env.environment = e
	world.add_child(env)
	var l := DirectionalLight3D.new()
	l.rotation_degrees = Vector3(-35, -30, 0)
	world.add_child(l)
	await process_frame
	var hero: Node3D = load("res://assets/khaled/khaled.glb").instantiate()
	world.add_child(hero)
	var ap: AnimationPlayer = hero.find_child("AnimationPlayer", true, false)
	print("anims: ", ap.get_animation_list())
	var cam := Camera3D.new()
	cam.fov = 30
	world.add_child(cam)
	var shots := [["idle", 0.0, 0.0], ["idle", 0.0, 40.0], ["idle", 0.0, 90.0], ["idle", 0.0, 180.0],
		["walk", 0.2, 50.0], ["fly", 0.3, 70.0], ["hover", 0.5, 25.0], ["point", 0.4, 0.0],
		["cheer", 0.25, 15.0], ["encourage", 0.9, 0.0], ["wave", 0.4, 0.0], ["takeoff", 0.3, 40.0], ["land", 0.28, 40.0]]
	var idx := 0
	for s in shots:
		ap.play(s[0])
		ap.seek(s[1], true)
		ap.pause()
		var a := deg_to_rad(s[2])
		cam.look_at_from_position(Vector3(sin(a) * 3.4, 0.75, cos(a) * 3.4), Vector3(0, 0.55, 0))

		for i in 3: await process_frame
		root.get_viewport().get_texture().get_image().save_png("%s/%02d_%s.png" % [out, idx, s[0]])
		idx += 1
	# face close-up
	ap.play("idle"); ap.seek(0.0, true); ap.pause()
	cam.look_at_from_position(Vector3(0.25, 0.85, 1.25), Vector3(0, 0.78, 0))
	for i in 3: await process_frame
	root.get_viewport().get_texture().get_image().save_png(out + "/99_face.png")
	quit()
