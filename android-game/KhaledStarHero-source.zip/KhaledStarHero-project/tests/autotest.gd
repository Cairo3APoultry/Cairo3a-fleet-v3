extends Node
## Automated play-through used to verify the game (not part of the exported APK).
##   godot --path . --rendering-driver opengl3 --resolution 1280x720 -- --autotest [--speed=3] [--out=/tmp/shots]
## Drives the real input path (mouse/touch events), plays every mode, makes one deliberate
## mistake, opens the parent section, and saves screenshots along the way.

var main: Node3D
var out_dir := "/tmp/khaled_shots"
var shot_n := 0
var failures: Array[String] = []
var quick := false


func _ready() -> void:
	main = get_parent()
	var speed := 3.0
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--speed="):
			speed = float(a.split("=")[1])
		elif a == "--quick":
			quick = true
		elif a.begins_with("--out="):
			out_dir = a.split("=")[1]
	Engine.time_scale = speed
	AudioServer.playback_speed_scale = speed
	DirAccess.make_dir_recursive_absolute(out_dir)
	_run.call_deferred()


func shot(label: String) -> void:
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("%s/%02d_%s.png" % [out_dir, shot_n, label])
	shot_n += 1


func mouse(pos: Vector2, pressed: bool) -> void:
	var e := InputEventMouseButton.new()
	e.button_index = MOUSE_BUTTON_LEFT
	e.pressed = pressed
	e.position = pos
	e.global_position = pos
	Input.parse_input_event(e)
	await get_tree().process_frame
	await get_tree().process_frame


func click(pos: Vector2) -> void:
	await mouse(pos, true)
	await mouse(pos, false)


func center(c: Control) -> Vector2:
	return c.get_global_rect().get_center()


func wait(sec: float) -> void:
	await get_tree().create_timer(sec).timeout


func until(cond: Callable, timeout: float, what: String) -> bool:
	var t := 0.0
	while not cond.call():
		await get_tree().process_frame
		t += get_process_delta_time()
		if t > timeout:
			failures.append("timeout waiting for " + what)
			print("FAIL timeout: ", what)
			return false
	return true


func check(ok: bool, what: String) -> void:
	print(("ok   " if ok else "FAIL ") + what)
	if not ok:
		failures.append(what)


func play_mission(make_mistake: bool, shots: bool, tag: String) -> void:
	if shots:
		await until(func() -> bool: return main.replay_ids.size() > 0 and String(main.replay_ids[0]).ends_with("_intro") and not String(main.replay_ids[0]).ends_with("count_intro"), 90.0, "lesson")
		await wait(1.6)
		await shot(tag + "_learn")
		await until(func() -> bool: return main.cam_mode == main.Cam.FOLLOW, 60.0, "take-off")
		for k in (3 if quick else 1):
			await wait(1.2)
			await shot(tag + "_fly%d" % k)
		print("fps while flying: ", Engine.get_frames_per_second(), "  camera-hero distance: ", snappedf(main.cam.position.distance_to(main.hero.position), 0.1), "  delta: ", snappedf(main._delta, 0.001))
	await until(func() -> bool: return main.accepting, 90.0, "rings ready")
	await wait(1.0)
	if shots:
		await shot(tag + "_choice")
	var stars_before: int = GameData.stars()
	if make_mistake and main.rings.size() > 1:
		var wrong: int = (int(main.correct_ring) + 1) % int(main.rings.size())
		await click(main.ring_screen_pos(wrong))
		check(not main.accepting, "tap on a wrong ring is accepted as a choice")
		await wait(1.6)
		await shot(tag + "_wrong")
		await until(func() -> bool: return main.accepting, 40.0, "second try after a wrong ring")
		check(GameData.stars() == stars_before, "wrong choice does not change the stars")
		check(main.rings[wrong] == null, "wrong ring was removed")
	await click(main.ring_screen_pos(main.correct_ring))
	await wait(1.6)
	check(GameData.stars() == stars_before + 1, "correct ring gives one star")
	if shots:
		await shot(tag + "_correct")


func _run() -> void:
	await wait(1.5)
	check(main.state == "home", "starts on the home screen")
	check(main.hero.anim.is_playing() and main.hero.anim.current_animation == "wave", "hero is animated on the home screen")
	await shot("home")
	GameData.set_setting("session_len", 3)

	for mi in GameData.MODES.size():
		var m: String = GameData.MODES[mi]
		var sessions_before := int(GameData.data["modes"][m]["sessions"])
		await click(center(main.mode_cards[mi]))
		await until(func() -> bool: return main.state == "session", 5.0, "session start " + m)
		var missions := 0
		while main.state == "session" and missions < 12:
			await play_mission(mi == 0 and missions == 0, missions == 0 or (mi >= 2 and missions == 2), "%s%d" % [m, missions + 1])
			missions += 1
			if quick:
				await wait(1.5)
				await shot("celebrate")
				get_tree().quit(0)
				return
			if main.done_count >= main.plan.size():
				break
			# wait until Khaled has landed on the next island and the next lesson starts
			await until(func() -> bool: return main.state != "session" or (main.cam_mode == main.Cam.STAND and main.mission_root.get_child_count() > 0), 60.0, "next island")
		await until(func() -> bool: return main.state == "end", 30.0, "end screen " + m)
		await wait(2.5)
		await shot(m + "_end")
		check(int(GameData.data["modes"][m]["sessions"]) == sessions_before + 1, "session counted for " + m)
		check(main.session_stars >= 3, "stars earned in " + m)
		# home button on the end panel
		var home_btn: Button = main.end_ui.get_child(0).get_child(0).get_child(1).get_child(1)
		await click(center(home_btn))
		await until(func() -> bool: return main.state == "home", 5.0, "back home")
		await wait(1.0)

	await shot("home_after")
	# leaving a mission half-way with the home button
	await click(center(main.mode_cards[0]))
	await until(func() -> bool: return main.cam_mode == main.Cam.FOLLOW, 60.0, "flying")
	await click(center(main.home_btn))
	await until(func() -> bool: return main.state == "home", 5.0, "home from mid-flight")
	await wait(1.0)
	check(main.mission_root.get_child_count() == 0, "mission objects cleaned up after leaving")

	# mute button
	await click(center(main.mute_btn))
	check(bool(GameData.setting("muted")) and AudioServer.is_bus_mute(0), "mute button mutes the audio")
	await click(center(main.mute_btn))
	check(not AudioServer.is_bus_mute(0), "mute button un-mutes")
	# replay button
	var before := Narrator.played_log.size()
	await click(center(main.replay_btn))
	await wait(0.3)
	check(Narrator.played_log.size() > before, "replay button repeats the narration")

	# parent section: a short tap must not open it, a long press does
	await click(center(main.parent_btn))
	await wait(0.3)
	check(main.state == "home", "short tap does not open the parent section")
	await mouse(center(main.parent_btn), true)
	await wait(2.4)
	await mouse(center(main.parent_btn), false)
	check(main.state == "parent", "long press opens the parent section")
	await wait(0.5)
	await shot("parent")
	check(GameData.stars() > 0, "progress exists before reset")
	GameData.reset_progress()
	check(GameData.stars() == 0 and GameData.introduced("ar_letters") == 0, "reset clears progress")
	main._close_parent()
	await wait(0.3)
	check(main.state == "home", "parent section closes")

	# saved file round trip
	GameData.add_star()
	GameData.load_progress()
	check(GameData.stars() == 1, "progress is saved to disk and loaded back")
	GameData.reset_progress()
	GameData.set_setting("session_len", 5)

	var missing := 0
	for id in Narrator.played_log:
		if not ResourceLoader.exists("res://assets/audio/%s.ogg" % id):
			missing += 1
	check(missing == 0, "all narration clips that were requested exist")
	print("narration clips played: ", Narrator.played_log.size())
	print("AUTOTEST ", "PASSED" if failures.is_empty() else "FAILED: " + str(failures))
	get_tree().quit(0 if failures.is_empty() else 1)
