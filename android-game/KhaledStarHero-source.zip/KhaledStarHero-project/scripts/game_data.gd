extends Node
## Learning content, saved progress and the adaptive session planner (autoload "GameData").

signal settings_changed
signal progress_changed

const SAVE_PATH := "user://khaled_progress.json"
const MODES: Array[String] = ["ar_letters", "en_letters", "ar_numbers", "en_numbers"]
const DEFAULT_SETTINGS := {"voice": 1.0, "music": 0.45, "sfx": 0.8, "muted": false, "session_len": 5}
const SESSION_LENGTHS: Array[int] = [3, 5, 8]

var content: Dictionary = {}
var data: Dictionary = {}


func _ready() -> void:
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/content.json"))
	assert(parsed is Dictionary, "content.json is missing or invalid")
	content = parsed
	load_progress()


# ------------------------------------------------------------------ persistence
func _blank() -> Dictionary:
	var d := {"version": 1, "stars": 0, "sessions": 0, "settings": DEFAULT_SETTINGS.duplicate(), "modes": {}}
	for m in MODES:
		d["modes"][m] = {"introduced": 0, "sessions": 0, "items": {}}
	return d


func load_progress() -> void:
	data = _blank()
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if not (parsed is Dictionary):
		return
	data["stars"] = int(parsed.get("stars", 0))
	data["sessions"] = int(parsed.get("sessions", 0))
	var st: Variant = parsed.get("settings", {})
	if st is Dictionary:
		for k in DEFAULT_SETTINGS:
			if st.has(k) and typeof(st[k]) in [TYPE_FLOAT, TYPE_INT, TYPE_BOOL]:
				data["settings"][k] = st[k]
	var modes: Variant = parsed.get("modes", {})
	if modes is Dictionary:
		for m in MODES:
			var src: Variant = modes.get(m, null)
			if not (src is Dictionary):
				continue
			var dst: Dictionary = data["modes"][m]
			dst["introduced"] = clampi(int(src.get("introduced", 0)), 0, items(m).size())
			dst["sessions"] = int(src.get("sessions", 0))
			var its: Variant = src.get("items", {})
			if its is Dictionary:
				for id in its:
					var s: Variant = its[id]
					if s is Dictionary:
						dst["items"][id] = {"seen": int(s.get("seen", 0)), "ok": int(s.get("ok", 0)), "miss": int(s.get("miss", 0)),
							"box": clampi(int(s.get("box", 0)), 0, 3), "last": int(s.get("last", 0))}


func save_progress() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(data))
		f.close()


func reset_progress() -> void:
	var keep: Dictionary = data["settings"]
	data = _blank()
	data["settings"] = keep
	save_progress()
	progress_changed.emit()


# ------------------------------------------------------------------ settings
func setting(key: String) -> Variant:
	return data["settings"][key]


func set_setting(key: String, value: Variant) -> void:
	data["settings"][key] = value
	save_progress()
	settings_changed.emit()


# ------------------------------------------------------------------ content access
func mode_info(mode: String) -> Dictionary:
	return content["modes"][mode]


func items(mode: String) -> Array:
	return content["modes"][mode]["items"]


func lang(mode: String) -> String:
	return content["modes"][mode]["lang"]


func is_number_mode(mode: String) -> bool:
	return content["modes"][mode]["kind"] == "number"


func item_stat(mode: String, idx: int) -> Dictionary:
	var id: String = items(mode)[idx]["id"]
	var its: Dictionary = data["modes"][mode]["items"]
	if not its.has(id):
		its[id] = {"seen": 0, "ok": 0, "miss": 0, "box": 0, "last": 0}
	return its[id]


func introduced(mode: String) -> int:
	return int(data["modes"][mode]["introduced"])


func mastered_count(mode: String) -> int:
	var n := 0
	for s: Dictionary in data["modes"][mode]["items"].values():
		if int(s["box"]) >= 2:
			n += 1
	return n


## Items the child got wrong the last time they came up (most-missed first).
func needs_review(mode: String) -> Array[int]:
	var out: Array[int] = []
	for i in introduced(mode):
		var s := item_stat(mode, i)
		if int(s["seen"]) > 0 and int(s["box"]) == 0 and int(s["miss"]) > 0:
			out.append(i)
	out.sort_custom(func(a: int, b: int) -> bool: return int(item_stat(mode, a)["miss"]) > int(item_stat(mode, b)["miss"]))
	return out


func stars() -> int:
	return int(data["stars"])


func add_star() -> void:
	data["stars"] = stars() + 1
	save_progress()
	progress_changed.emit()


func record_result(mode: String, idx: int, first_try: bool) -> void:
	var s := item_stat(mode, idx)
	s["seen"] = int(s["seen"]) + 1
	s["last"] = int(data["sessions"])
	if first_try:
		s["ok"] = int(s["ok"]) + 1
		s["box"] = mini(int(s["box"]) + 1, 3)
	else:
		s["miss"] = int(s["miss"]) + 1
		s["box"] = 0
	data["modes"][mode]["introduced"] = maxi(introduced(mode), idx + 1)
	save_progress()
	progress_changed.emit()


func finish_session(mode: String) -> void:
	data["sessions"] = int(data["sessions"]) + 1
	data["modes"][mode]["sessions"] = int(data["modes"][mode]["sessions"]) + 1
	save_progress()
	progress_changed.emit()


# ------------------------------------------------------------------ adaptive planning
## Number of rings to choose from: grows slowly as the child masters more items.
func choice_count(mode: String) -> int:
	var m := mastered_count(mode)
	if m < 3:
		return 2
	if m < 8:
		return 3
	return 4


## A short session: a few new items, the ones missed before, then the least-known ones.
func plan_session(mode: String) -> Array[int]:
	var total := items(mode).size()
	var length := int(setting("session_len"))
	var intro := introduced(mode)
	var struggling := needs_review(mode)
	var plan: Array[int] = []
	if intro < total:
		var n_new := 3 if intro == 0 else (1 if struggling.size() >= 3 else 2)
		n_new = mini(n_new, mini(total - intro, length))
		for k in n_new:
			plan.append(intro + k)
	for idx in struggling:
		if plan.size() < length and not plan.has(idx):
			plan.append(idx)
	var pool: Array[int] = []
	for i in intro:
		if not plan.has(i):
			pool.append(i)
	pool.shuffle()
	pool.sort_custom(func(a: int, b: int) -> bool:
		var sa := item_stat(mode, a)
		var sb := item_stat(mode, b)
		if int(sa["box"]) != int(sb["box"]):
			return int(sa["box"]) < int(sb["box"])
		return int(sa["last"]) < int(sb["last"]))
	for idx in pool:
		if plan.size() < length:
			plan.append(idx)
	# very first sessions: not enough known items yet, so repeat (repetition is the point)
	var base := plan.duplicate()
	var k := 0
	while plan.size() < length and not base.is_empty():
		plan.append(base[k % base.size()])
		k += 1
	return plan


func _similar(mode: String, idx: int) -> Array[int]:
	var all := items(mode)
	var g: String = all[idx]["glyph"]
	var out: Array[int] = []
	for group: Array in mode_info(mode)["similar"]:
		if group.has(g):
			for i in all.size():
				if i != idx and group.has(all[i]["glyph"]):
					out.append(i)
	return out


## Indices shown in the rings (target included, shuffled).  Early on the distractors look
## clearly different; once many items are mastered, look-alike letters are preferred.
func choices_for(mode: String, target: int) -> Array[int]:
	var n := choice_count(mode)
	var all := items(mode)
	var known := maxi(introduced(mode), target + 1)
	var sim := _similar(mode, target)
	var hard := mastered_count(mode) >= 8
	var cand: Array[int] = []
	for i in known:
		if i != target:
			cand.append(i)
	cand.shuffle()
	cand.sort_custom(func(a: int, b: int) -> bool:
		var wa := 1 if sim.has(a) else 0
		var wb := 1 if sim.has(b) else 0
		return wa > wb if hard else wa < wb)
	var picks: Array[int] = []
	for i in cand:
		if picks.size() < n - 1:
			picks.append(i)
	var j := known
	while picks.size() < n - 1 and j < all.size():
		picks.append(j)
		j += 1
	picks.append(target)
	picks.shuffle()
	return picks
