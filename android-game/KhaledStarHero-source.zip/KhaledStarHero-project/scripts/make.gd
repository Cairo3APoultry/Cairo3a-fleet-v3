extends RefCounted
class_name Make
## Small factories for the 3D pieces of a mission (glyphs, rings, pictures, effects) and UI assets.

static var _fonts := {}
static var _tex := {}


static func font_glyph() -> Font:
	if not _fonts.has("glyph"):
		_fonts["glyph"] = load("res://assets/fonts/Lalezar-Regular.ttf")
	return _fonts["glyph"]


static func font_ui() -> Font:
	if not _fonts.has("ui"):
		var fv := FontVariation.new()
		fv.base_font = load("res://assets/fonts/BalooBhaijaan2.ttf")
		fv.variation_opentype = {TextServerManager.get_primary_interface().name_to_tag("wght"): 700}
		_fonts["ui"] = fv
	return _fonts["ui"]


static func emoji(code: String) -> Texture2D:
	if not _tex.has(code):
		_tex[code] = load("res://assets/emoji/%s.png" % code)
	return _tex[code]


static func mat(color: Color, rough := 0.5, glow := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	if glow > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = glow
	return m


## Extruded 3D text, centred on its own bounding box.  `height` is the em height in world units.
static func glyph(text: String, height: float, color: Color, depth := 0.22, max_width := 0.0) -> Node3D:
	var holder := Node3D.new()
	var tm := TextMesh.new()
	tm.font = font_glyph()
	tm.font_size = 96
	tm.pixel_size = 0.01
	tm.curve_step = 1.0
	tm.text = text
	var box := tm.get_aabb()
	var s := height / 0.96
	if max_width > 0.0 and box.size.x * s > max_width:
		s = max_width / box.size.x
	tm.depth = depth / s
	box = tm.get_aabb()
	var mi := MeshInstance3D.new()
	mi.mesh = tm
	mi.material_override = mat(color, 0.35, 0.28)
	mi.scale = Vector3.ONE * s
	mi.position = -box.get_center() * s
	holder.add_child(mi)
	holder.set_meta("width", box.size.x * s)
	return holder


## A glyph with a darker extruded copy behind it so it stays readable against any sky.
static func glyph_outlined(text: String, height: float, color: Color, back: Color, max_width := 0.0) -> Node3D:
	var holder := Node3D.new()
	var b := glyph(text, height, back, 0.3, max_width)
	b.position = Vector3(0.05, -0.05, -0.16)
	b.scale = Vector3(1.04, 1.04, 1.0)
	holder.add_child(b)
	holder.add_child(glyph(text, height, color, 0.2, max_width))
	return holder


static func sprite(tex: Texture2D, size: float) -> Sprite3D:
	var sp := Sprite3D.new()
	sp.texture = tex
	sp.pixel_size = size / float(tex.get_width())
	sp.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sp.alpha_cut = SpriteBase3D.ALPHA_CUT_OPAQUE_PREPASS
	sp.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	return sp


static func word_label(text: String, size := 0.5) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font = font_ui()
	l.font_size = 96
	l.pixel_size = size / 96.0
	l.outline_size = 22
	l.modulate = Color.WHITE
	l.outline_modulate = Color("1d3a6e")
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	return l


## A flying ring with a glyph floating in its centre.
static func ring(text: String, color: Color, radius: float) -> Node3D:
	var root := Node3D.new()
	var torus := MeshInstance3D.new()
	var tmesh := TorusMesh.new()
	tmesh.inner_radius = radius - 0.17
	tmesh.outer_radius = radius + 0.17
	tmesh.rings = 40
	tmesh.ring_segments = 14
	torus.mesh = tmesh
	torus.rotation.x = PI / 2.0
	torus.material_override = mat(color, 0.3, 0.35)
	torus.name = "Torus"
	root.add_child(torus)
	var disc := MeshInstance3D.new()
	var dmesh := CylinderMesh.new()
	dmesh.top_radius = radius - 0.15
	dmesh.bottom_radius = radius - 0.15
	dmesh.height = 0.02
	dmesh.radial_segments = 40
	disc.mesh = dmesh
	disc.rotation.x = PI / 2.0
	var dm := StandardMaterial3D.new()
	dm.albedo_color = Color(color.lightened(0.75), 0.4)
	dm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	dm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	disc.material_override = dm
	disc.name = "Disc"
	root.add_child(disc)
	var g := glyph_outlined(text, radius * 1.42, Color.WHITE, color.darkened(0.45), radius * 1.45)
	g.position.z = 0.22
	g.name = "Glyph"
	root.add_child(g)
	return root


## One-shot burst of little stars.
static func star_burst(amount := 28) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(0.45, 0.45)
	var m := StandardMaterial3D.new()
	m.albedo_texture = emoji("2b50")
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.billboard_keep_scale = true
	q.material = m
	p.mesh = q
	p.amount = amount
	p.lifetime = 1.3
	p.one_shot = true
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = 3.5
	p.initial_velocity_max = 8.0
	p.gravity = Vector3(0, -7.0, 0)
	p.scale_amount_min = 0.5
	p.scale_amount_max = 1.3
	p.angle_min = -40.0
	p.angle_max = 40.0
	var c := Curve.new()
	c.add_point(Vector2(0.0, 1.0))
	c.add_point(Vector2(0.7, 0.9))
	c.add_point(Vector2(1.0, 0.0))
	p.scale_amount_curve = c
	p.emitting = true
	return p


static func pop_in(node: Node3D, delay := 0.0) -> void:
	var target := node.scale
	node.scale = Vector3.ONE * 0.001
	var tw := node.create_tween()
	if delay > 0.0:
		tw.tween_interval(delay)
	tw.tween_property(node, "scale", target, 0.45).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


static func shrink_away(node: Node3D, time := 0.35, delay := 0.0) -> void:
	var tw := node.create_tween()
	if delay > 0.0:
		tw.tween_interval(delay)
	tw.tween_property(node, "scale", Vector3.ONE * 0.001, time).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
	tw.tween_callback(node.queue_free)
