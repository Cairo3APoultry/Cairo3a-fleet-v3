extends Node3D
class_name SkyWorld
## The colourful sky worlds Khaled flies through.  Scenery is built from simple shapes and
## recycled ahead of the hero, so the flight can go on forever with a small, fixed cost.

const THEMES: Array[Dictionary] = [
	{"name": "islands", "kind": 0, "sky_top": Color("2f86e6"), "sky_hor": Color("c4eaff"), "sea": Color("2fa9e0"), "fog": Color("cdeeff"),
		"sun": Color("fff3d6"), "ambient": Color("e3f1ff"), "land": [Color("62cf4c"), Color("83dc5a"), Color("45b35c")], "rock": Color("c0915f"),
		"trunk": Color("8a5a2b"), "leaf": [Color("3fae49"), Color("59c95f"), Color("ff8fb1"), Color("ffc93c")], "cloud": Color("ffffff")},
	{"name": "candy", "kind": 1, "sky_top": Color("7f63f2"), "sky_hor": Color("ffc6df"), "sea": Color("ffa3ca"), "fog": Color("ffd6e8"),
		"sun": Color("fff0e0"), "ambient": Color("ffe8f2"), "land": [Color("ffd86b"), Color("9be7c4"), Color("ffa7c4")], "rock": Color("c98bd9"),
		"trunk": Color("ffffff"), "leaf": [Color("ff5c8a"), Color("31c6ff"), Color("ffb629"), Color("8f6bff")], "cloud": Color("fff3fa")},
	{"name": "space", "kind": 2, "sky_top": Color("070b2e"), "sky_hor": Color("40309a"), "sea": Color("1b1552"), "fog": Color("2a2068"),
		"sun": Color("ece8ff"), "ambient": Color("a9a6e6"), "land": [Color("8a7bff"), Color("5fd0e8"), Color("ff8ad0")], "rock": Color("5a4aa8"),
		"trunk": Color("c9c2ff"), "leaf": [Color("5ff0ff"), Color("ff7bd5"), Color("ffe36b"), Color("9dff8a")], "cloud": Color("9c8cff")},
]
const SPAN := 300.0
const SEA_Y := -11.0

var theme_idx := -1
var focus_z := 0.0
var th: Dictionary = {}
var _env: Environment
var _sky: ProceduralSkyMaterial
var _sun: DirectionalLight3D
var _sea: MeshInstance3D
var _stars: MultiMeshInstance3D
var _props: Array[Node3D] = []
var _prop_root: Node3D
var _mats := {}
var _sphere: SphereMesh
var _cyl: CylinderMesh
var _cone: CylinderMesh
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	_rng.randomize()
	_sphere = SphereMesh.new()
	_sphere.radius = 1.0
	_sphere.height = 2.0
	_sphere.radial_segments = 20
	_sphere.rings = 10
	_cyl = CylinderMesh.new()
	_cyl.top_radius = 1.0
	_cyl.bottom_radius = 1.0
	_cyl.height = 1.0
	_cyl.radial_segments = 24
	_cone = CylinderMesh.new()
	_cone.top_radius = 0.0
	_cone.bottom_radius = 1.0
	_cone.height = 1.0
	_cone.radial_segments = 16

	_sky = ProceduralSkyMaterial.new()
	_sky.sun_angle_max = 0.0
	var sky := Sky.new()
	sky.sky_material = _sky
	_env = Environment.new()
	_env.background_mode = Environment.BG_SKY
	_env.sky = sky
	_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	_env.ambient_light_energy = 0.62
	_env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	_env.fog_enabled = true
	_env.fog_density = 0.0045
	_env.fog_sky_affect = 0.0
	var we := WorldEnvironment.new()
	we.environment = _env
	add_child(we)
	_sun = DirectionalLight3D.new()
	_sun.rotation_degrees = Vector3(-48.0, -28.0, 0.0)
	_sun.light_energy = 0.98
	add_child(_sun)
	_sea = MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(900.0, 900.0)
	_sea.mesh = pm
	add_child(_sea)
	_prop_root = Node3D.new()
	add_child(_prop_root)


func _mat(c: Color, rough := 0.9, glow := 0.0) -> StandardMaterial3D:
	var key := "%s|%.2f|%.2f" % [c.to_html(), rough, glow]
	if not _mats.has(key):
		_mats[key] = Make.mat(c, rough, glow)
	return _mats[key]


func _part(mesh: Mesh, color: Color, pos: Vector3, scl: Vector3, parent: Node3D, glow := 0.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = _mat(color, 0.9, glow)
	mi.position = pos
	mi.scale = scl
	parent.add_child(mi)
	return mi


func _pick(arr: Array) -> Color:
	return arr[_rng.randi() % arr.size()]


func build(idx: int) -> void:
	theme_idx = idx
	th = THEMES[idx]
	_mats.clear()
	_sky.sky_top_color = th["sky_top"]
	_sky.sky_horizon_color = th["sky_hor"]
	_sky.ground_horizon_color = th["sky_hor"]
	_sky.ground_bottom_color = th["sea"]
	_env.ambient_light_color = th["ambient"]
	_env.fog_light_color = th["fog"]
	_sun.light_color = th["sun"]
	_sea.material_override = _mat(th["sea"], 0.6)
	_sea.visible = th["kind"] != 2
	for p in _props:
		p.queue_free()
	_props.clear()
	if _stars != null:
		_stars.queue_free()
		_stars = null
	var kind: int = th["kind"]
	for i in 9:
		_add_prop(_make_planet() if kind == 2 else _make_hill(), "low", i, 9)
	for i in 9:
		_add_prop(_make_floater(), "mid", i, 9)
	for i in 18:
		_add_prop(_make_cloud(), "high", i, 18)
	if kind == 2:
		_make_stars()


func _add_prop(node: Node3D, lane: String, i: int, n: int) -> void:
	node.set_meta("lane", lane)
	_prop_root.add_child(node)
	_props.append(node)
	_place(node)
	node.position.z = focus_z + 40.0 - SPAN * (float(i) + _rng.randf()) / float(n)


## Scenery always stays clear of the flight corridor in the middle.
func _place(node: Node3D) -> void:
	var side := -1.0 if _rng.randf() < 0.5 else 1.0
	match node.get_meta("lane"):
		"low":
			var clear := float(node.get_meta("clear", 10.0))
			node.position.x = side * (clear + _rng.randf_range(13.0, 60.0))
			node.position.y = SEA_Y + (_rng.randf_range(4.0, 22.0) if th["kind"] == 2 else _rng.randf_range(-2.0, 1.0))
		"mid":
			node.position.x = side * _rng.randf_range(11.0, 38.0)
			node.position.y = _rng.randf_range(-5.0, 6.0)
		"high":
			if _rng.randf() < 0.3:
				node.position.x = _rng.randf_range(-12.0, 12.0)
				node.position.y = _rng.randf_range(11.0, 18.0)
			else:
				node.position.x = side * _rng.randf_range(9.0, 55.0)
				node.position.y = _rng.randf_range(1.0, 17.0)


func _process(delta: float) -> void:
	_sea.position = Vector3(0.0, SEA_Y, focus_z - 150.0)
	if _stars != null:
		_stars.position.z = focus_z
	for p in _props:
		if p.position.z > focus_z + 45.0:
			p.position.z -= SPAN
			_place(p)
		elif p.position.z < focus_z + 45.0 - SPAN:
			p.position.z += SPAN
		if p.get_meta("lane") == "high":
			p.position.x += delta * 0.35


# ------------------------------------------------------------------ scenery pieces
func make_tree(scale_by := 1.0) -> Node3D:
	var t := Node3D.new()
	var kind: int = th["kind"]
	var leaf := _pick(th["leaf"])
	if kind == 0:
		_part(_cyl, th["trunk"], Vector3(0, 0.6, 0), Vector3(0.16, 1.2, 0.16), t)
		if _rng.randf() < 0.5:
			_part(_sphere, leaf, Vector3(0, 1.7, 0), Vector3(0.85, 0.85, 0.85), t)
			_part(_sphere, leaf.lightened(0.12), Vector3(0.35, 2.15, 0.1), Vector3(0.55, 0.55, 0.55), t)
		else:
			_part(_cone, leaf, Vector3(0, 1.6, 0), Vector3(0.9, 1.4, 0.9), t)
			_part(_cone, leaf.lightened(0.1), Vector3(0, 2.3, 0), Vector3(0.65, 1.1, 0.65), t)
	elif kind == 1:
		_part(_cyl, th["trunk"], Vector3(0, 0.8, 0), Vector3(0.07, 1.6, 0.07), t)
		_part(_sphere, leaf, Vector3(0, 1.9, 0), Vector3(0.75, 0.75, 0.3), t)
		_part(_sphere, Color.WHITE, Vector3(0, 1.9, 0), Vector3(0.4, 0.4, 0.34), t)
	else:
		_part(_cone, leaf, Vector3(0, 0.9, 0), Vector3(0.38, 1.8, 0.38), t, 0.5)
		_part(_cone, leaf.lightened(0.2), Vector3(0.4, 0.5, 0.1), Vector3(0.24, 1.0, 0.24), t, 0.5).rotation.z = -0.4
	t.scale = Vector3.ONE * scale_by
	t.rotation.y = _rng.randf() * TAU
	return t


func _make_hill() -> Node3D:
	var h := Node3D.new()
	var r := _rng.randf_range(9.0, 18.0)
	h.set_meta("clear", r)
	_part(_sphere, _pick(th["land"]), Vector3.ZERO, Vector3(r, r * 0.65, r), h)
	for i in _rng.randi_range(1, 3):
		var a := _rng.randf() * TAU
		var d := _rng.randf() * r * 0.45
		var tr := make_tree(_rng.randf_range(1.6, 2.6))
		tr.position = Vector3(cos(a) * d, r * 0.65 * sqrt(1.0 - pow(d / r, 2.0)) - 0.3, sin(a) * d)
		h.add_child(tr)
	return h


func _make_planet() -> Node3D:
	var p := Node3D.new()
	var r := _rng.randf_range(4.0, 9.0)
	var c := _pick(th["land"])
	p.set_meta("clear", r * 1.8)
	_part(_sphere, c, Vector3.ZERO, Vector3.ONE * r, p, 0.15)
	if _rng.randf() < 0.6:
		var ring := MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.inner_radius = r * 1.35
		tm.outer_radius = r * 1.8
		tm.rings = 32
		tm.ring_segments = 6
		ring.mesh = tm
		ring.scale = Vector3(1.0, 0.06, 1.0)
		ring.material_override = _mat(_pick(th["leaf"]), 0.8, 0.3)
		p.add_child(ring)
		p.rotation = Vector3(_rng.randf_range(-0.5, 0.5), 0.0, _rng.randf_range(-0.5, 0.5))
	else:
		for i in 4:
			var dir := Vector3(_rng.randf_range(-1, 1), _rng.randf_range(-0.3, 1), _rng.randf_range(0.2, 1)).normalized()
			_part(_sphere, c.darkened(0.2), dir * r * 0.93, Vector3.ONE * r * _rng.randf_range(0.12, 0.22), p)
	return p


func _make_floater() -> Node3D:
	var f := Node3D.new()
	var r := _rng.randf_range(2.2, 4.2)
	var land := _pick(th["land"])
	_part(_cyl, land, Vector3(0, -0.25, 0), Vector3(r, 0.5, r), f)
	_part(_cone, th["rock"], Vector3(0, -0.5 - r * 0.55, 0), Vector3(r * 0.96, r * 1.1, r * 0.96), f).rotation.x = PI
	for i in _rng.randi_range(1, 2):
		var tr := make_tree(_rng.randf_range(0.9, 1.4))
		tr.position = Vector3(_rng.randf_range(-r, r) * 0.5, 0.0, _rng.randf_range(-r, r) * 0.5)
		f.add_child(tr)
	return f


func _make_cloud() -> Node3D:
	var c := Node3D.new()
	var s := _rng.randf_range(1.3, 2.8)
	var col: Color = th["cloud"]
	var n := _rng.randi_range(3, 5)
	for i in n:
		var x := (float(i) - float(n - 1) * 0.5) * s * 0.85
		var k := s * _rng.randf_range(0.7, 1.1) * (1.0 - absf(float(i) - float(n - 1) * 0.5) * 0.14)
		_part(_sphere, col, Vector3(x, _rng.randf_range(-0.15, 0.3) * s, _rng.randf_range(-0.3, 0.3)), Vector3(k, k * 0.72, k * 0.85), c, 0.25 if th["kind"] == 2 else 0.0)
	return c


func _make_stars() -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var q := SphereMesh.new()
	q.radius = 0.5
	q.height = 1.0
	q.radial_segments = 6
	q.rings = 3
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(1.0, 0.98, 0.85)
	m.disable_fog = true
	q.material = m
	mm.mesh = q
	mm.instance_count = 320
	for i in mm.instance_count:
		var dir := Vector3(_rng.randf_range(-1, 1), _rng.randf_range(-0.25, 1), _rng.randf_range(-1, 0.4)).normalized()
		var s := _rng.randf_range(0.5, 1.6)
		mm.set_instance_transform(i, Transform3D(Basis().scaled(Vector3.ONE * s), dir * _rng.randf_range(170.0, 230.0)))
	_stars = MultiMeshInstance3D.new()
	_stars.multimesh = mm
	add_child(_stars)


## The little island Khaled stands on while he meets a new letter or number.
func make_platform() -> Node3D:
	var p := Node3D.new()
	var land: Array = th["land"]
	_part(_cyl, land[0], Vector3(0, -0.3, 0), Vector3(5.6, 0.6, 5.0), p)
	_part(_cyl, land[2], Vector3(0, -0.52, 0), Vector3(5.8, 0.4, 5.2), p)
	_part(_cone, th["rock"], Vector3(0, -3.1, 0), Vector3(5.5, 5.0, 4.9), p).rotation.x = PI
	# trees stay at the far edges so nothing hides the letter, the picture or Khaled
	for spot: Vector3 in [Vector3(-5.0, 0, -0.7), Vector3(5.1, 0, 0.5)]:
		var tr := make_tree(1.2 if spot.x < 0.0 else 0.85)
		tr.position = spot
		p.add_child(tr)
	for i in 10:
		var a := _rng.randf_range(0.15, PI - 0.15)
		var d := _rng.randf_range(3.2, 4.6)
		var pos := Vector3(cos(a) * d * 1.1, 0.0, -sin(a) * d * 0.55 + 2.2 * (0.5 - _rng.randf()))
		_part(_sphere, _pick(th["leaf"]), pos + Vector3(0, 0.1, 0), Vector3(0.16, 0.12, 0.16), p, 0.2)
	return p
