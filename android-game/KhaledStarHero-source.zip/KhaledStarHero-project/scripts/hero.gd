extends Node3D
class_name Hero
## Khaled, the flying star hero: wraps the rigged model (assets/khaled/khaled.glb).
## The node's forward direction is -Z.

const LOOPS: Array[String] = ["idle", "walk", "fly", "hover", "point", "cheer", "encourage", "wave"]

var anim: AnimationPlayer
var skeleton: Skeleton3D
var model: Node3D
var shadow: MeshInstance3D
var ground_y := 0.0
var shadow_on := true
var current := ""


func _ready() -> void:
	model = (load("res://assets/khaled/khaled.glb") as PackedScene).instantiate()
	model.rotation.y = PI          # the glTF model faces +Z
	add_child(model)
	anim = model.find_child("AnimationPlayer", true, false)
	skeleton = model.find_child("Skeleton3D", true, false)
	for n in LOOPS:
		anim.get_animation(n).loop_mode = Animation.LOOP_LINEAR
	_add_emblem()
	_add_shadow()
	play("idle", 0.0)


func play(clip: String, blend := 0.25) -> void:
	if clip == current and anim.is_playing():
		return
	current = clip
	anim.play(clip, blend)


## One-shot clip followed by a looping one (e.g. land -> idle).
func play_then(clip: String, next: String, blend := 0.15) -> void:
	current = next
	anim.play(clip, blend)
	anim.queue(next)


func _add_emblem() -> void:
	# Khaled's own badge: the first letter of his name inside the round chest emblem
	var att := BoneAttachment3D.new()
	att.bone_name = "chest"
	skeleton.add_child(att)
	var g := Make.glyph("خ", 0.105, Color("0a7f9c"), 0.008, 0.085)
	g.position = Vector3(0.0, 0.0085, 0.116)
	g.rotation.x = deg_to_rad(-8.0)
	att.add_child(g)


func _add_shadow() -> void:
	shadow = MeshInstance3D.new()
	var q := PlaneMesh.new()
	q.size = Vector2(0.9, 0.9)
	shadow.mesh = q
	var grad := Gradient.new()
	grad.set_color(0, Color(0, 0, 0, 0.38))
	grad.set_color(1, Color(0, 0, 0, 0.0))
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = 64
	tex.height = 64
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	shadow.material_override = m
	shadow.top_level = true
	add_child(shadow)


func _process(_delta: float) -> void:
	# soft blob shadow while he is close to the ground
	var h := global_position.y - ground_y
	shadow.visible = visible and shadow_on and h < 2.5 and h > -0.5
	if shadow.visible:
		var s := scale.x * clampf(1.0 - h * 0.25, 0.4, 1.0)
		shadow.global_transform = Transform3D(Basis().scaled(Vector3(s, 1.0, s)), Vector3(global_position.x, ground_y + 0.03, global_position.z))
