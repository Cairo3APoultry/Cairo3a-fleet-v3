extends Node3D
## Khaled Star Hero - main game: screens, camera and the mission flow.
##
## A session is a handful of short missions.  Each mission:
##   1. LEARN  - Khaled stands on an island, the letter/number appears, the narrator names it
##               (numbers: the objects are counted one by one first);
##   2. FLY    - "Yalla ya Khaled!" he takes off and flies to a row of rings;
##   3. CHOOSE - one tap on a ring and Khaled flies to it.  Right ring: stars, cheering, praise.
##               Wrong ring: no penalty, a gentle hint and another go.

signal ring_picked(index: int)

const HERO_SCALE := 1.6
const FLY_Y := 3.4
const RING_GAP := 3.8
const RING_R := 1.5
const RING_DIST := 46.0
const HOVER_BACK := 5.5
const HERO_STAND := Vector3(2.6, 0.0, 0.0)
const RING_COLORS: Array[Color] = [Color("ff5c8a"), Color("ffab1f"), Color("36c96a"), Color("8f6bff"), Color("2ea6ff")]
const CARD_COLORS: Array[Color] = [Color("ff6f91"), Color("3aa0ff"), Color("ffa62b"), Color("37c978")]
const FOV := 50.0
const PARENT_TITLES := {"ar_letters": "الحروف العربية", "en_letters": "الحروف الإنجليزية", "ar_numbers": "الأرقام العربية", "en_numbers": "الأرقام الإنجليزية"}

enum Cam { STAND, FOLLOW, CHOICE, CELEBRATE }

var world: SkyWorld
var hero: Hero
var cam: Camera3D
var cam_mode := Cam.STAND
var cam_look := Vector3.ZERO
var cam_back := 5.0
var choice_look_drop := 1.2
var _delta := 0.016
var platform: Node3D
var platform_next: Node3D
var mission_root: Node3D

var state := "boot"            # boot / home / session / end / parent
var mode := ""
var lang := "ar"
var island_pos := Vector3.ZERO
var rings_center := Vector3.ZERO
var hover_point := Vector3.ZERO
var rings: Array = []          # Node3D or null once removed
var ring_items: Array[int] = []
var correct_ring := -1
var accepting := false
var idle_t := 0.0
var prompt_stage := 0
var plan: Array[int] = []
var done_count := 0
var session_stars := 0
var replay_ids: Array = []
var _run_id := 0
var _move_tw: Tween
var _fly_from := Vector3.ZERO
var _fly_to := Vector3.ZERO
var _fly_arc := 0.0
var _fly_sway := 0.0
var _time := 0.0
var _hint_ring: Node3D
var _parent_hold := 0.0
var _parent_holding := false
var _prev_state := "home"

# UI nodes
var ui_root: Control
var home_ui: Control
var hud: Control
var end_ui: Control
var parent_ui: Control
var fade: ColorRect
var star_badge: PanelContainer
var star_label: Label
var star_icon: TextureRect
var dots: HBoxContainer
var mute_btn: Button
var replay_btn: Button
var home_btn: Button
var parent_btn: Button
var parent_bar: ProgressBar
var mode_cards: Array[Button] = []
var card_progress: Array[Label] = []
var end_stars: HBoxContainer
var parent_progress: Label
var parent_confirm: Control
var parent_status: Label
var len_buttons: Array[Button] = []
var home_avatar: TextureRect
var home_avatar_caption: Label
var stage_avatar: TextureRect
var stage_bubble: PanelContainer
var stage_caption: Label
var end_avatar: TextureRect
var _stage_hide_timer := 0.0


func _ready() -> void:
	world = SkyWorld.new()
	add_child(world)
	mission_root = Node3D.new()
	add_child(mission_root)
	hero = Hero.new()
	add_child(hero)
	hero.scale = Vector3.ONE * HERO_SCALE
	cam = Camera3D.new()
	cam.fov = FOV
	cam.far = 420.0
	add_child(cam)
	cam.make_current()
	_build_ui()
	RenderingServer.frame_pre_draw.connect(_update_camera)
	Narrator.finished.connect(_on_narration_finished)
	GameData.progress_changed.connect(_refresh_progress)
	GameData.settings_changed.connect(_refresh_settings)
	_enter_world(0)
	_refresh_progress()
	_refresh_settings()
	_show_home(true)
	if "--autotest" in OS.get_cmdline_user_args() and ResourceLoader.exists("res://tests/autotest.gd"):
		var t: Node = (load("res://tests/autotest.gd") as GDScript).new()
		add_child(t)


# ====================================================================== world / camera
func _enter_world(theme: int) -> void:
	world.focus_z = island_pos.z
	world.build(theme)
	for p in [platform, platform_next]:
		if p != null:
			p.queue_free()
	platform = world.make_platform()
	platform_next = world.make_platform()
	add_child(platform)
	add_child(platform_next)
	platform.position = island_pos
	platform_next.visible = false
	_stand_on_island()
	cam_mode = Cam.STAND
	_snap_camera()


func _stand_on_island() -> void:
	hero.position = island_pos + HERO_STAND
	hero.rotation = Vector3(0.0, PI, 0.0)      # facing the camera
	hero.ground_y = island_pos.y


func _cam_targets() -> Array[Vector3]:
	var hp := hero.position
	match cam_mode:
		Cam.FOLLOW:
			# above and slightly to the side, so the flying pose and the cape read clearly
			return [hp + Vector3(1.2, 2.3, 3.3), hp + Vector3(0.0, 0.5, -3.5)]
		Cam.CHOICE:
			return [hover_point + Vector3(0.0, 2.6, cam_back), rings_center + Vector3(0.0, -choice_look_drop, 0.0)]
		Cam.CELEBRATE:
			return [hp + Vector3(0.0, 1.35, 5.0), hp + Vector3(0.0, 1.0, 0.0)]
	return [island_pos + Vector3(0.3, 1.75, 5.9), island_pos + Vector3(0.3, 1.32, 0.0)]


func _snap_camera() -> void:
	var t := _cam_targets()
	cam.position = t[0]
	cam_look = t[1]
	cam.look_at(cam_look)


## Runs right before each frame is drawn, after tweens have moved the hero, so the camera never trails a frame behind.
func _update_camera() -> void:
	var t := _cam_targets()
	var k := 1.0 - exp(-_delta * (10.0 if cam_mode == Cam.FOLLOW else 3.2))
	cam.position = cam.position.lerp(t[0], k)
	cam_look = cam_look.lerp(t[1], k)
	cam.look_at(cam_look)


func _process(delta: float) -> void:
	_time += delta
	_delta = delta
	if _stage_hide_timer > 0.0 and not Narrator.is_speaking():
		_stage_hide_timer -= delta
		if _stage_hide_timer <= 0.0:
			_hide_stage_avatar()
	world.focus_z = hero.position.z
	# the soft shadow only makes sense above an island
	hero.shadow_on = false
	for p: Node3D in [platform, platform_next]:
		if p != null and p.visible and Vector2(hero.position.x - p.position.x, hero.position.z - p.position.z).length() < 5.0:
			hero.shadow_on = true
			hero.ground_y = p.position.y
	# rings bob gently; the hinted ring pulses
	for i in rings.size():
		var r: Node3D = rings[i]
		if r != null and is_instance_valid(r) and r.has_meta("base_y"):
			r.position.y = float(r.get_meta("base_y")) + sin(_time * 1.6 + float(i) * 1.7) * 0.16
			if r == _hint_ring:
				r.scale = Vector3.ONE * (1.0 + 0.1 * (0.5 + 0.5 * sin(_time * 6.0)))
	if accepting:
		idle_t += delta
		if prompt_stage == 0 and idle_t > 9.0 and not Narrator.is_speaking():
			prompt_stage = 1
			Narrator.say([lang + "/tap"] + replay_ids)
		elif prompt_stage == 1 and idle_t > 22.0 and not Narrator.is_speaking():
			prompt_stage = 2
			_show_hint(true)
	# grown-up gate: the settings open only after a long press
	if _parent_holding and state == "home":
		_parent_hold += delta
		parent_bar.value = _parent_hold / 2.0
		if _parent_hold >= 2.0:
			_parent_holding = false
			_open_parent()
	elif parent_bar.value > 0.0:
		_parent_hold = 0.0
		parent_bar.value = 0.0


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:      # Android back button: never quits by accident
		if state == "parent":
			_close_parent()
		elif state == "session" or state == "end":
			_go_home()


func _unhandled_input(event: InputEvent) -> void:
	if not accepting or state != "session":
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var best := -1
		var best_d := 1e9
		for i in rings.size():
			var r: Node3D = rings[i]
			if r == null or not is_instance_valid(r):
				continue
			var d: float = event.position.distance_to(ring_screen_pos(i))
			if d < ring_screen_radius(i) * 1.3 and d < best_d:
				best_d = d
				best = i
		if best >= 0:
			get_viewport().set_input_as_handled()
			ring_picked.emit(best)


func ring_screen_pos(i: int) -> Vector2:
	return cam.unproject_position((rings[i] as Node3D).position)


func ring_screen_radius(i: int) -> float:
	var p: Vector3 = (rings[i] as Node3D).position
	return maxf(absf(cam.unproject_position(p + Vector3(RING_R + 0.2, 0, 0)).x - cam.unproject_position(p).x), 60.0)


# ====================================================================== helpers
func _wait(sec: float) -> void:
	await get_tree().create_timer(sec).timeout


func _fade_to(alpha: float, time: float) -> void:
	fade.mouse_filter = Control.MOUSE_FILTER_STOP
	var tw := create_tween()
	tw.tween_property(fade, "color:a", alpha, time)
	await tw.finished
	if alpha <= 0.01:
		fade.mouse_filter = Control.MOUSE_FILTER_IGNORE


func _clear_mission() -> void:
	for c in mission_root.get_children():
		c.queue_free()
	rings.clear()
	ring_items.clear()
	correct_ring = -1
	_hint_ring = null


func _abort() -> void:
	_run_id += 1
	accepting = false
	ring_picked.emit(-1)
	Narrator.stop()
	if _move_tw != null and _move_tw.is_valid():
		_move_tw.kill()
	_clear_mission()


func _turn_hero(yaw: float, time := 0.3) -> void:
	var tw := hero.create_tween().set_parallel(true)
	tw.tween_property(hero, "rotation:y", hero.rotation.y + angle_difference(hero.rotation.y, yaw), time)
	tw.tween_property(hero, "rotation:x", 0.0, time)
	tw.tween_property(hero.model, "rotation:z", 0.0, time)


func _fly(from: Vector3, to: Vector3, dur: float, arc: float, sway: float) -> void:
	_fly_from = from
	_fly_to = to
	_fly_arc = arc
	_fly_sway = sway
	_move_tw = create_tween()
	_move_tw.tween_method(_fly_step, 0.0, 1.0, dur).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	await _move_tw.finished


func _fly_step(t: float) -> void:
	var p := _fly_from.lerp(_fly_to, t)
	p.y += sin(PI * t) * _fly_arc
	p.x += sin(TAU * t) * _fly_sway
	var v := p - hero.position
	hero.position = p
	if v.length() > 0.0005:
		hero.rotation.y = lerp_angle(hero.rotation.y, atan2(-v.x, -v.z), 0.2)
		hero.rotation.x = lerpf(hero.rotation.x, clampf(v.y / v.length(), -0.6, 0.6) * 0.7, 0.15)
		hero.model.rotation.z = lerpf(hero.model.rotation.z, clampf(v.x * 4.0, -0.45, 0.45), 0.15)


func _clip(item: Dictionary, part: String) -> String:
	return "%s/%s_%s" % [lang, item["id"], part]


# ====================================================================== session flow
func start_session(m: String) -> void:
	_abort()
	var id := _run_id
	mode = m
	lang = GameData.lang(m)
	state = "session"
	_show_screen()
	replay_ids = ["%s/mode_%s" % [lang, m]]
	_show_stage_avatar("talking", "يلا يا خالد! نبدأ مغامرتنا!" if lang == "ar" else "Let’s start, Khaled!")
	Narrator.say(replay_ids)
	await _fade_to(1.0, 0.3)
	if id != _run_id: return
	var theme := (GameData.MODES.find(m) + int(GameData.data["modes"][m]["sessions"])) % SkyWorld.THEMES.size()
	_enter_world(theme)
	hero.play("idle", 0.0)
	plan = GameData.plan_session(m)
	done_count = 0
	session_stars = 0
	_update_dots()
	await _fade_to(0.0, 0.3)
	if id != _run_id: return
	if Narrator.is_speaking():
		await Narrator.finished
		if id != _run_id: return
	var requeued := {}
	var i := 0
	while i < plan.size():
		var idx: int = plan[i]
		await _learn(id, idx)
		if id != _run_id: return
		await _fly_to_rings(id, idx)
		if id != _run_id: return
		var first_try: bool = await _choose(id, idx)
		if id != _run_id: return
		GameData.record_result(mode, idx, first_try)
		# a missed item comes back once more before the session ends
		if not first_try and not requeued.has(idx) and requeued.size() < 2:
			requeued[idx] = true
			plan.append(idx)
		done_count += 1
		_update_dots()
		await _to_next_island(id)
		if id != _run_id: return
		i += 1
	GameData.finish_session(mode)
	_stage_hide_timer = 0.0
	_hide_stage_avatar()
	state = "end"
	_show_screen()
	hero.play("cheer")
	Narrator.sfx("fanfare")
	replay_ids = [lang + "/end"]
	Narrator.say(replay_ids)
	_fill_end_stars()


func _count_slot(k: int, n: int) -> Vector3:
	var per_row := 5
	var row := k / per_row
	var in_row := mini(n - row * per_row, per_row)
	var col := k % per_row
	return Vector3(-1.55 + (float(col) - float(in_row - 1) * 0.5) * 0.92, 3.05 - float(row) * 0.82, 0.2)


func _learn(id: int, idx: int) -> void:
	var item: Dictionary = GameData.items(mode)[idx]
	var color := RING_COLORS[idx % RING_COLORS.size()]
	_show_stage_avatar("reading" if GameData.is_number_mode(mode) else "point", "يلا يا خالد! نتعلم مع بعض!" if lang == "ar" else "Let’s learn together, Khaled!")
	cam_mode = Cam.STAND
	var root := Node3D.new()
	root.position = island_pos
	mission_root.add_child(root)
	if GameData.is_number_mode(mode):
		# count real objects one at a time, then show the numeral
		replay_ids = [lang + "/count_intro"]
		hero.play("wave")
		Narrator.say(replay_ids)
		await Narrator.finished
		if id != _run_id: return
		hero.play("point")
		var n := int(item["value"])
		var codes: Array = GameData.content["count_emoji"]
		var tex := Make.emoji(codes[(idx + done_count) % codes.size()])
		root.set_meta("count_tex", tex)
		for k in n:
			var sp := Make.sprite(tex, 0.78)
			sp.position = _count_slot(k, n)
			root.add_child(sp)
			Make.pop_in(sp)
			Narrator.sfx("count", 0.9 + 0.07 * float(k))
			Narrator.say(["%s/N%02d_count" % [lang, k + 1]])
			await Narrator.finished
			if id != _run_id: return
			await _wait(0.1)
			if id != _run_id: return
		var g := Make.glyph_outlined(item["glyph"], 1.4, color, Color.WHITE)
		g.position = Vector3(-1.55, 1.12, 0.3)
		root.add_child(g)
		Make.pop_in(g)
		Narrator.sfx("sparkle")
		replay_ids = [_clip(item, "intro")]
		Narrator.say(replay_ids)
		await Narrator.finished
		if id != _run_id: return
	else:
		hero.play("point")
		var text: String = item["glyph"] + String(item.get("glyph2", ""))
		var g := Make.glyph_outlined(text, 2.0, color, Color.WHITE, 2.6)
		g.position = Vector3(0.15, 1.8, 0.2)
		root.add_child(g)
		Make.pop_in(g)
		Narrator.sfx("sparkle")
		var pic := Make.sprite(Make.emoji(item["emoji"]), 1.4)
		pic.position = Vector3(-2.45, 2.05, 0.2)
		root.add_child(pic)
		Make.pop_in(pic, 0.5)
		var word := Make.word_label(item["word"], 0.52)
		word.position = Vector3(-2.45, 0.98, 0.2)
		root.add_child(word)
		Make.pop_in(word, 0.7)
		replay_ids = [_clip(item, "intro")]
		Narrator.say(replay_ids)
		await Narrator.finished
		if id != _run_id: return
	await _wait(0.4)
	if id != _run_id: return
	# the glyph zooms off into the sky: time to go and find it
	Narrator.sfx("whoosh")
	for c: Node3D in root.get_children():
		var tw := c.create_tween().set_parallel(true)
		tw.tween_property(c, "position", c.position + Vector3(0.0, 4.0, -34.0), 0.6).set_ease(Tween.EASE_IN)
		tw.tween_property(c, "scale", Vector3.ONE * 0.05, 0.6)
	await _wait(0.6)
	if id != _run_id: return
	root.queue_free()


func _spawn_rings(target: int) -> void:
	ring_items = GameData.choices_for(mode, target)
	rings.clear()
	_hint_ring = null
	var n := ring_items.size()
	var all := GameData.items(mode)
	var color_shift := randi() % RING_COLORS.size()
	for i in n:
		var it: Dictionary = all[ring_items[i]]
		var r := Make.ring(it["glyph"], RING_COLORS[(i + color_shift) % RING_COLORS.size()], RING_R)
		var y_off := 0.0 if n <= 2 else (0.45 if i % 2 == 0 else -0.25)
		r.position = rings_center + Vector3((float(i) - float(n - 1) * 0.5) * RING_GAP, y_off, 0.0)
		r.set_meta("base_y", r.position.y)
		mission_root.add_child(r)
		rings.append(r)
		if ring_items[i] == target:
			correct_ring = i
	# frame all the rings whatever the screen shape
	var vp := get_viewport().get_visible_rect().size
	var need_w := float(n - 1) * RING_GAP + 2.0 * (RING_R + 0.9)
	var dist := need_w / (2.0 * tan(deg_to_rad(FOV) * 0.5) * (vp.x / vp.y))
	cam_back = maxf(dist - HOVER_BACK, 4.8)


func _fly_to_rings(id: int, idx: int) -> void:
	var item: Dictionary = GameData.items(mode)[idx]
	rings_center = island_pos + Vector3(0.0, FLY_Y, -RING_DIST)
	hover_point = rings_center + Vector3(0.0, -2.9, HOVER_BACK)
	_spawn_rings(idx)
	choice_look_drop = 0.0 if GameData.is_number_mode(mode) else 1.2
	if GameData.is_number_mode(mode):
		# the counted objects wait above the rings as a reminder
		var n := int(item["value"])
		var codes: Array = GameData.content["count_emoji"]
		var tex := Make.emoji(codes[(idx + done_count) % codes.size()])
		var row := Node3D.new()
		row.name = "CountRow"
		row.position = rings_center + Vector3(0.0, RING_R + 0.85, 0.0)
		mission_root.add_child(row)
		for k in n:
			var sp := Make.sprite(tex, 0.7)
			sp.position = Vector3((float(k) - float(n - 1) * 0.5) * 0.8, 0.0, 0.0)
			row.add_child(sp)
	replay_ids = [_clip(item, "find")]
	_show_stage_avatar("fly", "يلا يا خالد! نطير!" if lang == "ar" else "Let’s fly, Khaled!")
	Narrator.say(replay_ids)
	_turn_hero(0.0, 0.35)
	hero.play("takeoff", 0.1)
	await _wait(0.5)
	if id != _run_id: return
	Narrator.sfx("whoosh")
	hero.play("fly", 0.2)
	cam_mode = Cam.FOLLOW
	await _fly(hero.position, hover_point, 4.8, 2.4, 1.6)
	if id != _run_id: return
	hero.play("hover", 0.35)
	_turn_hero(0.0)
	cam_mode = Cam.CHOICE
	prompt_stage = 0


func _choose(id: int, idx: int) -> bool:
	var wrong := 0
	while true:
		accepting = true
		idle_t = 0.0
		var pick: int = await ring_picked
		if id != _run_id: return false
		accepting = false
		if pick == correct_ring:
			await _correct(id, idx)
			return wrong == 0
		wrong += 1
		await _wrong(id, idx, pick, wrong)
		if id != _run_id: return false
	return false


func _show_hint(with_voice: bool) -> void:
	_show_stage_avatar("point", "بص يا خالد! الدايرة اللي بتنور." if lang == "ar" else "Look, Khaled! The glowing ring.")
	if correct_ring >= 0 and correct_ring < rings.size() and rings[correct_ring] != null:
		_hint_ring = rings[correct_ring]
		if with_voice:
			Narrator.say([lang + "/hint"] + replay_ids)


func _correct(id: int, idx: int) -> void:
	var item: Dictionary = GameData.items(mode)[idx]
	var ring: Node3D = rings[correct_ring]
	var target: Vector3 = ring.position
	_hint_ring = null
	Narrator.stop()
	Narrator.sfx("whoosh")
	hero.play("fly", 0.15)
	var d := target - hero.position
	_turn_hero(atan2(-d.x, -d.z), 0.15)
	_move_tw = create_tween()
	_move_tw.tween_property(hero, "position", target + Vector3(0.0, -0.75, 0.6), 0.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	_move_tw.tween_callback(_pop_ring.bind(ring))
	_move_tw.tween_property(hero, "position", target + Vector3(0.0, -1.4, -3.6), 0.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	await _move_tw.finished
	if id != _run_id: return
	_turn_hero(PI, 0.3)
	hero.play("cheer", 0.2)
	_show_stage_avatar("celebrate", "برافو يا خالد! شاطر يا بطل!" if lang == "ar" else "Bravo, Khaled! Great job!")
	cam_mode = Cam.CELEBRATE
	session_stars += 1
	GameData.add_star()
	var praise := "%s/praise%d" % [lang, 1 + randi() % int(GameData.content["praise"][lang])]
	Narrator.say([praise, _clip(item, "short")])
	await Narrator.finished
	if id != _run_id: return


func _pop_ring(ring: Node3D) -> void:
	Narrator.sfx("pop")
	Narrator.sfx("sparkle")
	var burst := Make.star_burst()
	burst.position = ring.position
	mission_root.add_child(burst)
	get_tree().create_timer(2.5).timeout.connect(burst.queue_free)
	_fly_star_to_badge(cam.unproject_position(ring.position))
	for i in rings.size():
		var r: Node3D = rings[i]
		if r == null or not is_instance_valid(r):
			continue
		r.remove_meta("base_y")
		if r == ring:
			var torus: Node3D = r.get_node("Torus")
			var tw := torus.create_tween()
			tw.tween_property(torus, "scale", Vector3.ONE * 1.7, 0.25)
			tw.tween_property(torus, "scale", Vector3.ONE * 0.001, 0.2)
			(r.get_node("Disc") as Node3D).visible = false
			# the collected glyph follows Khaled and floats beside him while he celebrates
			var gl: Node3D = r.get_node("Glyph")
			var tw2 := gl.create_tween()
			tw2.tween_property(gl, "scale", Vector3.ONE * 1.3, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
			tw2.tween_property(gl, "position", Vector3(-1.75, -0.25, -3.6), 0.45).set_trans(Tween.TRANS_SINE)
			tw2.parallel().tween_property(gl, "scale", Vector3.ONE * 0.62, 0.45)
		else:
			Make.shrink_away(r, 0.3)
			rings[i] = null
	var row := mission_root.get_node_or_null("CountRow")
	if row != null:
		Make.shrink_away(row, 0.3, 1.2)


func _wrong(id: int, idx: int, pick: int, wrong: int) -> void:
	var item: Dictionary = GameData.items(mode)[idx]
	var ring: Node3D = rings[pick]
	Narrator.stop()
	hero.play("fly", 0.15)
	var near: Vector3 = ring.position + Vector3(0.0, -1.9, 2.8)
	var d := near - hero.position
	_turn_hero(atan2(-d.x, -d.z), 0.15)
	_move_tw = create_tween()
	_move_tw.tween_property(hero, "position", near, 0.55).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	await _move_tw.finished
	if id != _run_id: return
	# the ring just wobbles and drifts away - no buzzer, no lost points
	Narrator.sfx("soft")
	ring.remove_meta("base_y")
	rings[pick] = null
	var tw := ring.create_tween()
	tw.tween_property(ring, "rotation:z", 0.25, 0.12)
	tw.tween_property(ring, "rotation:z", -0.25, 0.2)
	tw.tween_property(ring, "rotation:z", 0.0, 0.12)
	tw.tween_property(ring, "position", ring.position + Vector3(0.0, 7.0, -6.0), 0.9).set_ease(Tween.EASE_IN)
	tw.parallel().tween_property(ring, "scale", Vector3.ONE * 0.05, 0.9)
	tw.tween_callback(ring.queue_free)
	_turn_hero(PI, 0.3)
	hero.play("encourage", 0.2)
	_show_stage_avatar("talking", "ولا يهمك يا خالد! جرّب كمان مرة." if lang == "ar" else "No worries, Khaled! Try again.")
	var enc := "%s/enc%d" % [lang, 1 + (wrong - 1) % int(GameData.content["encourage"][lang])]
	Narrator.say([enc, _clip(item, "short")])
	await Narrator.finished
	if id != _run_id: return
	_turn_hero(0.0, 0.3)
	hero.play("hover", 0.3)
	_move_tw = create_tween()
	_move_tw.tween_property(hero, "position", hover_point, 0.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	await _move_tw.finished
	if id != _run_id: return
	if wrong >= 2:
		_show_hint(false)          # after two misses the right ring glows
	prompt_stage = maxi(prompt_stage, 1)


func _to_next_island(id: int) -> void:
	var next := Vector3(0.0, 0.0, rings_center.z - 26.0)
	platform_next.position = next
	platform_next.visible = true
	_turn_hero(0.0, 0.3)
	hero.play("fly", 0.25)
	cam_mode = Cam.FOLLOW
	Narrator.sfx("whoosh")
	await _fly(hero.position, next + HERO_STAND + Vector3(0.0, 0.2, 0.0), 2.8, 1.5, -1.0)
	if id != _run_id: return
	_clear_mission()
	island_pos = next
	var old := platform
	platform = platform_next
	platform_next = old
	platform_next.visible = false
	_stand_on_island()
	hero.rotation.y = 0.0
	_turn_hero(PI, 0.45)
	hero.play_then("land", "idle")
	cam_mode = Cam.STAND
	await _wait(0.9)


func _go_home() -> void:
	_abort()
	var id := _run_id
	await _fade_to(1.0, 0.2)
	if id != _run_id: return
	island_pos = Vector3(0.0, 0.0, snappedf(hero.position.z, 1.0))
	platform.position = island_pos
	platform.visible = true
	platform_next.visible = false
	_stand_on_island()
	cam_mode = Cam.STAND
	_snap_camera()
	_show_home(false)
	await _fade_to(0.0, 0.2)


func _show_home(first: bool) -> void:
	state = "home"
	_show_screen()
	if home_avatar != null:
		home_avatar.texture = load("res://assets/khaled/poses/%s.png" % ("idle" if first else "thumbs_up"))
		home_avatar_caption.text = "أهلاً يا خالد! يلا نلعب ونتعلّم!" if first else "اختار مغامرة يا بطل!"
	hero.play("wave")
	replay_ids = ["ar/welcome", "ar/choose"] if first else ["ar/choose"]
	Narrator.say(replay_ids)


# ====================================================================== UI
func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ui_root = Control.new()
	ui_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var theme := Theme.new()
	theme.default_font = Make.font_ui()
	theme.default_font_size = 26
	ui_root.theme = theme
	layer.add_child(ui_root)

	# ---- always visible: stars, replay voice, mute
	star_badge = UIKit.panel(Color("ffffff"), 40, 5)
	(star_badge.get_theme_stylebox("panel") as StyleBoxFlat).border_color = Color("ffc93c")
	(star_badge.get_theme_stylebox("panel") as StyleBoxFlat).content_margin_top = 6
	(star_badge.get_theme_stylebox("panel") as StyleBoxFlat).content_margin_bottom = 6
	var sb_box := HBoxContainer.new()
	sb_box.add_theme_constant_override("separation", 10)
	star_icon = TextureRect.new()
	star_icon.texture = Make.emoji("2b50")
	star_icon.custom_minimum_size = Vector2(56, 56)
	star_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	star_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	sb_box.add_child(star_icon)
	star_label = UIKit.label("0", 44, Color("e58a00"), 0, Color.WHITE, true)
	sb_box.add_child(star_label)
	star_badge.add_child(sb_box)
	star_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(star_badge)
	_anchor_top_center(star_badge, 18.0)

	mute_btn = UIKit.round_button(Make.emoji("1f50a"), 104, Color("ffffff"))
	ui_root.add_child(mute_btn)
	_anchor_top_right(mute_btn, 20.0, 18.0, 104.0)
	mute_btn.pressed.connect(func() -> void: GameData.set_setting("muted", not bool(GameData.setting("muted"))))
	replay_btn = UIKit.round_button(Make.emoji("1f442"), 104, Color("fff3c4"))
	ui_root.add_child(replay_btn)
	_anchor_top_right(replay_btn, 140.0, 18.0, 104.0)
	replay_btn.pressed.connect(_on_replay)

	_build_home()
	_build_hud()
	_build_end()
	_build_parent()

	fade = ColorRect.new()
	fade.color = Color(1, 1, 1, 0)
	fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(fade)


func _anchor_top_center(c: Control, top: float) -> void:
	c.anchor_left = 0.5
	c.anchor_right = 0.5
	c.anchor_top = 0.0
	c.anchor_bottom = 0.0
	c.offset_left = 0.0
	c.offset_right = 0.0
	c.offset_top = top
	c.offset_bottom = top
	c.grow_horizontal = Control.GROW_DIRECTION_BOTH


func _anchor_top_right(c: Control, right_margin: float, top: float, side: float) -> void:
	c.anchor_left = 1.0
	c.anchor_right = 1.0
	c.anchor_top = 0.0
	c.anchor_bottom = 0.0
	c.offset_left = -(right_margin + side)
	c.offset_right = -right_margin
	c.offset_top = top
	c.offset_bottom = top + side


func _on_replay() -> void:
	if not replay_ids.is_empty():
		idle_t = 0.0
		Narrator.say(replay_ids)


func _build_home() -> void:
	home_ui = Control.new()
	home_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	home_ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(home_ui)

	var title := UIKit.label("خالد النجم الطائر", 76, Color("ffd93b"), 18, Color("17346b"), true)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	home_ui.add_child(title)
	title.anchor_left = 0.04
	title.anchor_right = 0.62
	title.anchor_top = 0.0
	title.offset_top = 112
	title.offset_bottom = 222

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 26)
	grid.add_theme_constant_override("v_separation", 24)
	home_ui.add_child(grid)
	grid.anchor_left = 0.04
	grid.anchor_right = 0.62
	grid.anchor_top = 0.0
	grid.anchor_bottom = 1.0
	grid.offset_top = 240
	grid.offset_bottom = -30
	for i in GameData.MODES.size():
		var m: String = GameData.MODES[i]
		var info := GameData.mode_info(m)
		var card := Button.new()
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.size_flags_vertical = Control.SIZE_EXPAND_FILL
		UIKit._apply_styles(card, CARD_COLORS[i], 44)
		var vb := VBoxContainer.new()
		vb.set_anchors_preset(Control.PRESET_FULL_RECT)
		vb.alignment = BoxContainer.ALIGNMENT_CENTER
		vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
		vb.add_theme_constant_override("separation", -6)
		var sample := UIKit.label(info["sample"], 92, Color.WHITE, 14, CARD_COLORS[i].darkened(0.45), true)
		sample.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		vb.add_child(sample)
		var prow := HBoxContainer.new()
		prow.alignment = BoxContainer.ALIGNMENT_CENTER
		prow.mouse_filter = Control.MOUSE_FILTER_IGNORE
		prow.add_theme_constant_override("separation", 8)
		var pstar := TextureRect.new()
		pstar.texture = Make.emoji("2b50")
		pstar.custom_minimum_size = Vector2(34, 34)
		pstar.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		pstar.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		pstar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		prow.add_child(pstar)
		var prog := UIKit.label("", 30, Color.WHITE, 8, CARD_COLORS[i].darkened(0.45))
		prow.add_child(prog)
		vb.add_child(prow)
		card.add_child(vb)
		card.pressed.connect(start_session.bind(m))
		grid.add_child(card)
		mode_cards.append(card)
		card_progress.append(prog)

	# Khaled’s own pose sheet: a friendly welcome on the home screen.
	home_avatar = TextureRect.new()
	home_avatar.texture = load("res://assets/khaled/poses/idle.png")
	home_avatar.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	home_avatar.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	home_avatar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	home_avatar.anchor_left = 0.65; home_avatar.anchor_right = 0.98
	home_avatar.anchor_top = 0.30; home_avatar.anchor_bottom = 0.99
	home_avatar.offset_left = 0; home_avatar.offset_right = 0
	home_avatar.offset_top = 0; home_avatar.offset_bottom = 0
	home_ui.add_child(home_avatar)
	var welcome_panel := UIKit.panel(Color("ffffff"), 24, 4)
	(welcome_panel.get_theme_stylebox("panel") as StyleBoxFlat).border_color = Color("57b9ed")
	home_ui.add_child(welcome_panel)
	welcome_panel.anchor_left = 0.67; welcome_panel.anchor_right = 0.97
	welcome_panel.anchor_top = 0.24; welcome_panel.anchor_bottom = 0.36
	home_avatar_caption = UIKit.label("أهلاً يا خالد! يلا نلعب ونتعلّم!", 23, Color("17346b"), 0, Color.WHITE, true)
	home_avatar_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	home_avatar_caption.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	home_avatar_caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	welcome_panel.add_child(home_avatar_caption)

	# grown-ups: long press on the gear
	parent_btn = UIKit.round_button(Make.emoji("2699"), 84, Color("e8eef7"))
	home_ui.add_child(parent_btn)
	parent_btn.position = Vector2(20, 18)
	parent_btn.button_down.connect(func() -> void: _parent_holding = true)
	parent_btn.button_up.connect(func() -> void: _parent_holding = false)
	var hint := UIKit.label("ولي الأمر: اضغط مطولًا", 20, Color.WHITE, 6)
	home_ui.add_child(hint)
	hint.position = Vector2(114, 30)
	parent_bar = ProgressBar.new()
	parent_bar.min_value = 0.0
	parent_bar.max_value = 1.0
	parent_bar.show_percentage = false
	parent_bar.custom_minimum_size = Vector2(170, 12)
	parent_bar.add_theme_stylebox_override("background", UIKit.bar_style(Color(1, 1, 1, 0.5), 0.0))
	parent_bar.add_theme_stylebox_override("fill", UIKit.bar_style(Color("37c978"), 0.0))
	parent_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	home_ui.add_child(parent_bar)
	parent_bar.position = Vector2(114, 66)
	parent_bar.size = Vector2(170, 12)


func _build_hud() -> void:
	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(hud)
	home_btn = UIKit.round_button(Make.emoji("1f3e0"), 104, Color("ffffff"))
	hud.add_child(home_btn)
	home_btn.position = Vector2(20, 18)
	home_btn.pressed.connect(_go_home)
	dots = HBoxContainer.new()
	dots.add_theme_constant_override("separation", 10)
	dots.alignment = BoxContainer.ALIGNMENT_CENTER
	dots.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(dots)
	_anchor_top_center(dots, 106.0)
	stage_avatar = TextureRect.new()
	stage_avatar.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	stage_avatar.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	stage_avatar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stage_avatar.anchor_left = 1.0; stage_avatar.anchor_right = 1.0
	stage_avatar.anchor_top = 1.0; stage_avatar.anchor_bottom = 1.0
	stage_avatar.offset_left = -205; stage_avatar.offset_right = -12
	stage_avatar.offset_top = -255; stage_avatar.offset_bottom = -8
	stage_avatar.visible = false
	hud.add_child(stage_avatar)
	stage_bubble = UIKit.panel(Color("ffffff"), 22, 4)
	(stage_bubble.get_theme_stylebox("panel") as StyleBoxFlat).border_color = Color("57b9ed")
	stage_bubble.anchor_left = 0.60; stage_bubble.anchor_right = 0.84
	stage_bubble.anchor_top = 0.79; stage_bubble.anchor_bottom = 0.96
	stage_bubble.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stage_bubble.visible = false
	hud.add_child(stage_bubble)
	stage_caption = UIKit.label("", 21, Color("17346b"), 0, Color.WHITE, true)
	stage_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	stage_caption.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	stage_caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stage_bubble.add_child(stage_caption)


func _update_dots() -> void:
	for c in dots.get_children():
		c.queue_free()
	for i in plan.size():
		var p := Panel.new()
		p.custom_minimum_size = Vector2(22, 22)
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color("ffc93c") if i < done_count else Color(1, 1, 1, 0.6)
		sb.set_corner_radius_all(11)
		p.add_theme_stylebox_override("panel", sb)
		p.mouse_filter = Control.MOUSE_FILTER_IGNORE
		dots.add_child(p)


func _show_stage_avatar(pose: String, line: String) -> void:
	if stage_avatar == null:
		return
	var tex := load("res://assets/khaled/poses/%s.png" % pose) as Texture2D
	if tex != null:
		stage_avatar.texture = tex
	stage_caption.text = line
	stage_caption.layout_direction = Control.LAYOUT_DIRECTION_RTL if lang == "ar" else Control.LAYOUT_DIRECTION_LTR
	stage_avatar.visible = true
	stage_bubble.visible = true
	_stage_hide_timer = 2.5
	stage_avatar.pivot_offset = stage_avatar.size * 0.5
	stage_avatar.modulate.a = 0.0
	stage_avatar.scale = Vector2(0.88, 0.88)
	var tw := stage_avatar.create_tween().set_parallel(true)
	tw.tween_property(stage_avatar, "modulate:a", 1.0, 0.24)
	tw.tween_property(stage_avatar, "scale", Vector2.ONE, 0.30).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	stage_bubble.modulate.a = 0.0
	stage_bubble.create_tween().tween_property(stage_bubble, "modulate:a", 1.0, 0.22)


func _on_narration_finished() -> void:
	if stage_avatar != null and stage_avatar.visible:
		_stage_hide_timer = 1.35


func _hide_stage_avatar() -> void:
	if stage_avatar == null or not stage_avatar.visible:
		return
	var tw := create_tween().set_parallel(true)
	tw.tween_property(stage_avatar, "modulate:a", 0.0, 0.25)
	tw.tween_property(stage_bubble, "modulate:a", 0.0, 0.25)
	tw.chain().tween_callback(func() -> void:
		stage_avatar.visible = false
		stage_bubble.visible = false)


func _build_end() -> void:
	end_ui = Control.new()
	end_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	end_ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(end_ui)
	var panel := UIKit.panel(Color(1, 1, 1, 0.94), 48, 8)
	(panel.get_theme_stylebox("panel") as StyleBoxFlat).border_color = Color("ffc93c")
	end_ui.add_child(panel)
	panel.anchor_left = 0.05
	panel.anchor_right = 0.60
	panel.anchor_top = 0.24
	panel.anchor_bottom = 0.92
	var vb := VBoxContainer.new()
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 26)
	panel.add_child(vb)
	end_stars = HBoxContainer.new()
	end_stars.alignment = BoxContainer.ALIGNMENT_CENTER
	end_stars.add_theme_constant_override("separation", 4)
	end_stars.custom_minimum_size = Vector2(0, 96)
	vb.add_child(end_stars)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 60)
	vb.add_child(row)
	var again := UIKit.round_button(Make.emoji("25b6"), 170, Color("37c978"))
	again.pressed.connect(func() -> void: start_session(mode))
	row.add_child(again)
	var home := UIKit.round_button(Make.emoji("1f3e0"), 170, Color("3aa0ff"))
	home.pressed.connect(_go_home)
	row.add_child(home)
	end_avatar = TextureRect.new()
	end_avatar.texture = load("res://assets/khaled/poses/celebrate.png")
	end_avatar.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	end_avatar.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	end_avatar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	end_avatar.anchor_left = 0.64; end_avatar.anchor_right = 0.98
	end_avatar.anchor_top = 0.14; end_avatar.anchor_bottom = 0.98
	end_ui.add_child(end_avatar)
	var end_caption := UIKit.label("برافو يا خالد!", 38, Color("ffd93b"), 8, Color("17346b"), true)
	end_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	end_ui.add_child(end_caption)
	end_caption.anchor_left = 0.64; end_caption.anchor_right = 0.98
	end_caption.anchor_top = 0.04; end_caption.anchor_bottom = 0.16


func _fill_end_stars() -> void:
	for c in end_stars.get_children():
		c.queue_free()
	var n := mini(session_stars, 10)
	for i in n:
		var s := TextureRect.new()
		s.texture = Make.emoji("2b50")
		var side := 84.0 if n <= 6 else 60.0
		s.custom_minimum_size = Vector2(side, side)
		s.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		s.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		s.modulate.a = 0.0
		end_stars.add_child(s)
		var tw := s.create_tween()
		tw.tween_interval(0.25 + 0.22 * float(i))
		tw.tween_callback(Narrator.sfx.bind("star", 1.0 + 0.05 * float(i)))
		tw.tween_property(s, "modulate:a", 1.0, 0.2)


func _fly_star_to_badge(from: Vector2) -> void:
	var s := TextureRect.new()
	s.texture = Make.emoji("2b50")
	s.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	s.size = Vector2(90, 90)
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(s)
	s.position = from - s.size * 0.5
	var to := star_icon.global_position - Vector2(17, 17)
	var tw := s.create_tween()
	tw.tween_interval(0.25)
	tw.tween_property(s, "position", to, 0.7).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
	tw.tween_callback(Narrator.sfx.bind("star"))
	tw.tween_callback(s.queue_free)
	tw.tween_callback(_bump_badge)


func _bump_badge() -> void:
	star_badge.pivot_offset = star_badge.size * 0.5
	var tw := star_badge.create_tween()
	tw.tween_property(star_badge, "scale", Vector2(1.25, 1.25), 0.12)
	tw.tween_property(star_badge, "scale", Vector2.ONE, 0.18)


func _show_screen() -> void:
	home_ui.visible = state == "home" or (state == "parent" and _prev_state == "home")
	hud.visible = state == "session" or state == "end"
	dots.visible = state == "session"
	end_ui.visible = state == "end"
	parent_ui.visible = state == "parent"


func _refresh_progress() -> void:
	var s := GameData.stars()
	star_label.text = UIKit.arabic_digits(s)
	for i in GameData.MODES.size():
		var m: String = GameData.MODES[i]
		var total := GameData.items(m).size()
		var done := GameData.mastered_count(m)
		if GameData.lang(m) == "ar":
			card_progress[i].text = "%s من %s" % [UIKit.arabic_digits(done), UIKit.arabic_digits(total)]
		else:
			card_progress[i].text = "%d / %d" % [done, total]
	if parent_progress != null:
		parent_progress.text = _progress_text()


func _refresh_settings() -> void:
	var muted := bool(GameData.setting("muted"))
	(mute_btn.get_meta("icon") as TextureRect).texture = Make.emoji("1f507" if muted else "1f50a")
	for i in len_buttons.size():
		var on := GameData.SESSION_LENGTHS[i] == int(GameData.setting("session_len"))
		len_buttons[i].add_theme_stylebox_override("normal", UIKit.style(Color("37c978") if on else Color("9aa7b8"), 26))
		len_buttons[i].add_theme_stylebox_override("hover", UIKit.style(Color("37c978") if on else Color("9aa7b8"), 26))


# ---------------------------------------------------------------------- parent section
func _progress_text() -> String:
	var lines: Array[String] = []
	lines.append("النجوم: %d   •   الجلسات المكتملة: %d" % [GameData.stars(), int(GameData.data["sessions"])])
	for m: String in GameData.MODES:
		var review := ""
		for idx in GameData.needs_review(m):
			review += String(GameData.items(m)[idx]["glyph"]) + "  "
		var line := "%s: أتقن %d من %d، وتعرّف على %d" % [PARENT_TITLES[m], GameData.mastered_count(m), GameData.items(m).size(), GameData.introduced(m)]
		if review != "":
			line += "  —  يحتاج مراجعة: " + review
		lines.append(line)
	return "\n".join(lines)


func _slider_row(title: String, key: String, parent: Control) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	var l := UIKit.label(title, 26, Color("17346b"))
	l.custom_minimum_size = Vector2(220, 0)
	row.add_child(l)
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = float(GameData.setting(key))
	s.custom_minimum_size = Vector2(420, 48)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.focus_mode = Control.FOCUS_NONE
	s.add_theme_stylebox_override("slider", UIKit.bar_style(Color("cfd8e6")))
	s.add_theme_stylebox_override("grabber_area", UIKit.bar_style(Color("3aa0ff")))
	s.add_theme_stylebox_override("grabber_area_highlight", UIKit.bar_style(Color("3aa0ff")))
	s.add_theme_icon_override("grabber", UIKit.knob())
	s.add_theme_icon_override("grabber_highlight", UIKit.knob())
	s.value_changed.connect(func(v: float) -> void: GameData.set_setting(key, v))
	s.drag_ended.connect(func(_changed: bool) -> void:
		if key == "voice":
			Narrator.say(["ar/praise3"])
		elif key == "sfx":
			Narrator.sfx("sparkle"))
	row.add_child(s)
	parent.add_child(row)


func _build_parent() -> void:
	parent_ui = Control.new()
	parent_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(parent_ui)
	var dim := ColorRect.new()
	dim.color = Color(0.05, 0.1, 0.25, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent_ui.add_child(dim)
	var panel := UIKit.panel(Color("f7faff"), 40, 6)
	(panel.get_theme_stylebox("panel") as StyleBoxFlat).border_color = Color("3aa0ff")
	parent_ui.add_child(panel)
	panel.anchor_left = 0.07
	panel.anchor_right = 0.93
	panel.anchor_top = 0.05
	panel.anchor_bottom = 0.95
	panel.layout_direction = Control.LAYOUT_DIRECTION_RTL
	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 10)
	panel.add_child(outer)
	var head := HBoxContainer.new()
	var title := UIKit.label("قسم ولي الأمر", 40, Color("17346b"), 0, Color.WHITE, true)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	var close := UIKit.round_button(Make.emoji("274c"), 70, Color("ffffff"))
	close.pressed.connect(_close_parent)
	head.add_child(close)
	outer.add_child(head)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(scroll)
	var vb := VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 14)
	scroll.add_child(vb)

	vb.add_child(UIKit.label("تقدّم خالد", 30, Color("e58a00")))
	parent_progress = UIKit.label("", 23, Color("17346b"))
	parent_progress.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(parent_progress)

	vb.add_child(UIKit.label("الصوت", 30, Color("e58a00")))
	_slider_row("صوت الراوي", "voice", vb)
	_slider_row("الموسيقى", "music", vb)
	_slider_row("المؤثرات", "sfx", vb)

	vb.add_child(UIKit.label("عدد المهمات في الجلسة", 30, Color("e58a00")))
	var lens := HBoxContainer.new()
	lens.add_theme_constant_override("separation", 18)
	for n in GameData.SESSION_LENGTHS:
		var b := UIKit.text_button(UIKit.arabic_digits(n), Color("9aa7b8"), 34, Vector2(110, 68))
		b.pressed.connect(func() -> void: GameData.set_setting("session_len", n))
		lens.add_child(b)
		len_buttons.append(b)
	vb.add_child(lens)

	vb.add_child(UIKit.label("إعادة التقدم", 30, Color("e58a00")))
	var reset := UIKit.text_button("مسح التقدم والبدء من جديد", Color("ef5a5a"), 26, Vector2(380, 68))
	reset.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	vb.add_child(reset)
	var confirm := HBoxContainer.new()
	confirm.add_theme_constant_override("separation", 18)
	confirm.add_child(UIKit.label("سيُمسح كل تقدّم خالد ونجومه. هل أنت متأكد؟", 24, Color("b02a2a")))
	var yes := UIKit.text_button("نعم، امسح", Color("ef5a5a"), 24, Vector2(170, 60))
	var no := UIKit.text_button("لا", Color("9aa7b8"), 24, Vector2(110, 60))
	confirm.add_child(yes)
	confirm.add_child(no)
	confirm.visible = false
	vb.add_child(confirm)
	parent_confirm = confirm
	parent_status = UIKit.label("", 24, Color("1f8a4c"))
	vb.add_child(parent_status)
	reset.pressed.connect(func() -> void:
		confirm.visible = true
		parent_status.text = "")
	no.pressed.connect(func() -> void: confirm.visible = false)
	yes.pressed.connect(func() -> void:
		GameData.reset_progress()
		confirm.visible = false
		parent_status.text = "تم مسح التقدم.")

	vb.add_child(UIKit.label("عن اللعبة", 30, Color("e58a00")))
	var about := UIKit.label("تعمل اللعبة بدون إنترنت، وبدون حسابات أو إعلانات أو مشتريات، ولا تجمع أي بيانات. التقدم محفوظ على هذا الجهاز فقط.\n" +
		"صوت الراوي ملفات مسجّلة داخل اللعبة (أصوات Piper: kareem للعربية و lessac للإنجليزية).\n" +
		"الخطوط: Lalezar و Baloo Bhaijaan 2 (رخصة OFL). الصور: Twemoji (رخصة CC-BY 4.0). المحرك: Godot Engine (رخصة MIT).", 20, Color("4a5b78"))
	about.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(about)


func _open_parent() -> void:
	_prev_state = state
	state = "parent"
	Narrator.stop()
	parent_confirm.visible = false
	parent_status.text = ""
	parent_progress.text = _progress_text()
	_show_screen()


func _close_parent() -> void:
	state = _prev_state
	_show_screen()
