extends Node
## Narrator voice, sound effects and music (autoload "Narrator").
## Every line is a pre-rendered local audio file: nothing is fetched or synthesised at run time.

signal finished   ## the queued narration sequence has finished (or was stopped)

var _voice: AudioStreamPlayer
var _music: AudioStreamPlayer
var _sfx: Array[AudioStreamPlayer] = []
var _queue: Array = []
var _speaking := false
var _duck := 1.0
var played_log: Array[String] = []   ## last clips started (used by the automated test)


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for bus_name: String in ["Voice", "Music", "Sfx"]:
		AudioServer.add_bus()
		var idx := AudioServer.bus_count - 1
		AudioServer.set_bus_name(idx, bus_name)
		AudioServer.set_bus_send(idx, "Master")
	_voice = AudioStreamPlayer.new()
	_voice.bus = "Voice"
	add_child(_voice)
	_voice.finished.connect(_on_voice_finished)
	_music = AudioStreamPlayer.new()
	_music.bus = "Music"
	var m: AudioStreamOggVorbis = load("res://assets/audio/sfx/music.ogg")
	m.loop = true
	_music.stream = m
	add_child(_music)
	for i in 6:
		var p := AudioStreamPlayer.new()
		p.bus = "Sfx"
		add_child(p)
		_sfx.append(p)
	GameData.settings_changed.connect(apply_settings)
	apply_settings()
	_music.play()


func apply_settings() -> void:
	AudioServer.set_bus_mute(0, bool(GameData.setting("muted")))
	for pair: Array in [["Voice", "voice"], ["Music", "music"], ["Sfx", "sfx"]]:
		var idx := AudioServer.get_bus_index(pair[0])
		var v := float(GameData.setting(pair[1]))
		AudioServer.set_bus_mute(idx, v <= 0.001)
		AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(v, 0.001)))


func _process(delta: float) -> void:
	# keep the music quietly in the background while the narrator talks
	_duck = move_toward(_duck, 0.3 if _speaking else 1.0, delta * 1.5)
	_music.volume_db = linear_to_db(_duck)


## Plays clips one after another, e.g. say(["ar/praise1", "ar/L02_short"]).
func say(ids: Array) -> void:
	_queue = ids.duplicate()
	_voice.stop()
	_speaking = true
	_play_next()


func stop() -> void:
	_queue.clear()
	_voice.stop()
	if _speaking:
		_speaking = false
		finished.emit()


func is_speaking() -> bool:
	return _speaking


func _play_next() -> void:
	while not _queue.is_empty():
		var id: String = _queue.pop_front()
		var path := "res://assets/audio/%s.ogg" % id
		if ResourceLoader.exists(path):
			_voice.stream = load(path)
			_voice.play()
			played_log.append(id)
			if played_log.size() > 400:
				played_log = played_log.slice(200)
			return
		push_warning("missing narration clip: " + id)
	_speaking = false
	finished.emit()


func _on_voice_finished() -> void:
	if _speaking:
		_play_next()


func sfx(sound: String, pitch := 1.0) -> void:
	var path := "res://assets/audio/sfx/%s.ogg" % sound
	for p in _sfx:
		if not p.playing:
			p.stream = load(path)
			p.pitch_scale = pitch
			p.play()
			return
