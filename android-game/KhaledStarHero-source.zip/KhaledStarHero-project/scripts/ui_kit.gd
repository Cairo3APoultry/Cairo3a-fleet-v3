extends RefCounted
class_name UIKit
## Chunky, child-friendly 2D controls built in code.


static func style(bg: Color, radius: int, border := 5, border_color := Color.WHITE) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(radius)
	sb.set_border_width_all(border)
	sb.border_color = border_color
	sb.shadow_color = Color(0, 0, 0, 0.25)
	sb.shadow_size = 8
	sb.shadow_offset = Vector2(0, 5)
	sb.anti_aliasing_size = 1.5
	return sb


static func _apply_styles(b: Button, bg: Color, radius: int) -> void:
	b.add_theme_stylebox_override("normal", style(bg, radius))
	b.add_theme_stylebox_override("hover", style(bg, radius))
	b.add_theme_stylebox_override("pressed", style(bg.darkened(0.18), radius))
	b.add_theme_stylebox_override("disabled", style(bg.darkened(0.3), radius))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(func() -> void: Narrator.sfx("tap"))


## Big round button with a picture, no reading needed.
static func round_button(icon: Texture2D, size: float, bg: Color) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(size, size)
	b.size = Vector2(size, size)
	_apply_styles(b, bg, int(size / 2.0))
	var ic := TextureRect.new()
	ic.texture = icon
	ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ic.set_anchors_preset(Control.PRESET_FULL_RECT)
	var m := size * 0.2
	ic.offset_left = m
	ic.offset_top = m
	ic.offset_right = -m
	ic.offset_bottom = -m
	b.add_child(ic)
	b.set_meta("icon", ic)
	return b


static func text_button(text: String, bg: Color, font_size := 30, min_size := Vector2(200, 72)) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	_apply_styles(b, bg, 26)
	b.add_theme_font_override("font", Make.font_ui())
	b.add_theme_font_size_override("font_size", font_size)
	for c: String in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(c, Color.WHITE)
	return b


static func label(text: String, size: int, color := Color.WHITE, outline := 0, outline_color := Color("17346b"), big := false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", Make.font_glyph() if big else Make.font_ui())
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if outline > 0:
		l.add_theme_constant_override("outline_size", outline)
		l.add_theme_color_override("font_outline_color", outline_color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func panel(bg: Color, radius := 36, border := 6) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := style(bg, radius, border)
	sb.content_margin_left = 28
	sb.content_margin_right = 28
	sb.content_margin_top = 20
	sb.content_margin_bottom = 20
	p.add_theme_stylebox_override("panel", sb)
	return p


static func bar_style(bg: Color, margin := 8.0) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(8)
	sb.content_margin_top = margin
	sb.content_margin_bottom = margin
	return sb


static var _knob: Texture2D


## Large round slider handle (easy to grab on a phone).
static func knob() -> Texture2D:
	if _knob == null:
		var g := Gradient.new()
		g.offsets = PackedFloat32Array([0.0, 0.78, 0.8, 0.96, 1.0])
		g.colors = PackedColorArray([Color("3aa0ff"), Color("3aa0ff"), Color.WHITE, Color.WHITE, Color(1, 1, 1, 0)])
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		t.width = 44
		t.height = 44
		_knob = t
	return _knob


static func arabic_digits(n: int) -> String:
	var out := ""
	for ch in str(n):
		out += String.chr(0x0660 + int(ch))
	return out
