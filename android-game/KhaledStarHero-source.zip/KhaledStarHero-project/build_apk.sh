#!/usr/bin/env bash
# Builds an installable debug APK without a private release keystore.
set -euo pipefail
cd "$(dirname "$0")"
GODOT="${GODOT:-godot}"
mkdir -p build
"$GODOT" --headless --editor --path . --import --quit
"$GODOT" --headless --path . --export-debug "Android" build/KhaledStarHero.apk
ls -lh build/KhaledStarHero.apk
