extends SceneTree
# Renders the app icon / splash art from the hero model itself.
#   xvfb-run godot --path . --rendering-driver opengl3 --resolution 864x864 -s tools/make_icon.gd
func _init():
	await process_frame
	root.transparent_bg = true
	var world := Node3D.new()
	root.add_child(world)
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0, 0, 0, 0)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(1, 1, 1)
	e.ambient_light_energy = 0.7
	var we := WorldEnvironment.new()
	we.environment = e
	world.add_child(we)
	var l := DirectionalLight3D.new()
	l.rotation_degrees = Vector3(-35, -25, 0)
	world.add_child(l)
	var hero: Node3D = load("res://assets/khaled/khaled.glb").instantiate()
	world.add_child(hero)
	var sk: Skeleton3D = hero.find_child("Skeleton3D", true, false)
	var att := BoneAttachment3D.new()
	att.bone_name = "chest"
	sk.add_child(att)
	var g := Make.glyph("خ", 0.105, Color("0a7f9c"), 0.008, 0.085)
	g.position = Vector3(0.0, 0.0085, 0.116)
	g.rotation.x = deg_to_rad(-8.0)
	att.add_child(g)
	var ap: AnimationPlayer = hero.find_child("AnimationPlayer", true, false)
	ap.play("fly")
	ap.seek(0.35, true)
	ap.pause()
	hero.rotation_degrees = Vector3(-28, 0, 0)
	var cam := Camera3D.new()
	cam.fov = 28
	world.add_child(cam)
	cam.look_at_from_position(Vector3(1.9, 1.15, 2.3), Vector3(0.02, 0.5, 0.42))
	for i in 4:
		await process_frame
	var img := root.get_viewport().get_texture().get_image()
	img.save_png("/tmp/icon_hero.png")
	print("saved ", img.get_size(), " ", img.get_format())
	quit()
