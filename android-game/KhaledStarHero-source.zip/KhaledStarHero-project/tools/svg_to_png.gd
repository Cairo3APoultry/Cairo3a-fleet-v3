extends SceneTree
# Rasterises the Twemoji SVGs to 192px PNGs.  godot --headless -s tools/svg_to_png.gd -- <svg_dir>
func _init():
	var args := OS.get_cmdline_user_args()
	var src: String = args[0] if args.size() > 0 else "/tmp/emoji_svg"
	var n := 0
	for f in DirAccess.get_files_at(src):
		if not f.ends_with(".svg"):
			continue
		var img := Image.new()
		if img.load_svg_from_buffer(FileAccess.get_file_as_bytes(src.path_join(f)), 192.0 / 36.0) == OK:
			img.save_png("res://assets/emoji/" + f.get_basename() + ".png")
			n += 1
	print("converted ", n)
	quit()
