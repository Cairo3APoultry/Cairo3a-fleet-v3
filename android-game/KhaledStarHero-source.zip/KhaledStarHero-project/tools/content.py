#!/usr/bin/env python3
"""Single source of truth for the learning content.

Writes data/content.json (read by the game) and exposes the narration
script used by tools/gen_audio.py.   Run:  python3 tools/content.py
"""
import json, os

ROOT = os.path.join(os.path.dirname(__file__), '..')
CHILD_AR = 'خَالِدِ'           # light final vowel: the voice otherwise swallows the last consonant of the name
CHILD_EN = 'Kha-led'         # spelling that the English voice pronounces correctly

# glyph, name (plain), name with article (diacritised for speech), sound (diacritised), word, word for speech, emoji
AR_LETTERS = [
    ('أ', 'ألف', 'الأَلِفْ', '[[ʔˈa]]', 'أرنب', 'أَرْنَبْ', '1f430'),
    ('ب', 'باء', 'البَاءْ', '[[bˈa]]', 'بطة', 'بَطَّهْ', '1f986'),
    ('ت', 'تاء', 'التَاءْ', '[[tˈa]]', 'تفاحة', 'تُفَّاحَهْ', '1f34e'),
    ('ث', 'ثاء', 'الثَاءْ', '[[θˈa]]', 'ثعلب', 'ثَعْلَبْ', '1f98a'),
    ('ج', 'جيم', 'الجِيمْ', '[[dʒˈa]]', 'جمل', 'جَمَلْ', '1f42b'),
    ('ح', 'حاء', 'الحَاءْ', '[[ħˈa]]', 'حصان', 'حِصَانْ', '1f434'),
    ('خ', 'خاء', 'الخَاءْ', '[[χˈa]]', 'خروف', 'خَرُوفْ', '1f411'),
    ('د', 'دال', 'الدَالْ', '[[dˈa]]', 'ديك', 'دِيكْ', '1f413'),
    ('ذ', 'ذال', 'الذَالْ', '[[ðˈa]]', 'ذرة', 'ذُرَهْ', '1f33d'),
    ('ر', 'راء', 'الرَاءْ', '[[rˈa]]', 'ريشة', 'رِيشَهْ', '1fab6'),
    ('ز', 'زاي', 'الزَايْ', '[[zˈa]]', 'زرافة', 'زَرَافَهْ', '1f992'),
    ('س', 'سين', 'السِينْ', '[[sˈa]]', 'سمكة', 'سَمَكَهْ', '1f41f'),
    ('ش', 'شين', 'الشِينْ', '[[ʃˈa]]', 'شمس', 'شَمْسْ', '2600'),
    ('ص', 'صاد', 'الصَادْ', '[[s̪ˈa.]]', 'صاروخ', 'صَارُوخْ', '1f680'),
    ('ض', 'ضاد', 'الضَادْ', '[[dˤˈa.]]', 'ضفدع', 'ضُفْدَعْ', '1f438'),
    ('ط', 'طاء', 'الطَاءْ', '[[t̪ˈa.]]', 'طماطم', 'طَمَاطِمْ', '1f345'),
    ('ظ', 'ظاء', 'الظَاءْ', '[[ðˈa.]]', 'ظرف', 'ظَرْفْ', '2709'),
    ('ع', 'عين', 'العِينْ', '[[ʕˈa]]', 'عنب', 'عِنَبْ', '1f347'),
    ('غ', 'غين', 'الغِينْ', '[[ɣˈa]]', 'غزال', 'غَزَالْ', '1f98c'),
    ('ف', 'فاء', 'الفَاءْ', '[[fˈa]]', 'فيل', 'فِيلْ', '1f418'),
    ('ق', 'قاف', 'القَافْ', '[[qˈa]]', 'قمر', 'قَمَرْ', '1f319'),
    ('ك', 'كاف', 'الكَافْ', '[[kˈa]]', 'كورة', 'كُورَهْ', '26bd'),
    ('ل', 'لام', 'اللَامْ', '[[lˈa]]', 'لمون', 'لَمُونْ', '1f34b'),
    ('م', 'ميم', 'المِيمْ', '[[mˈa]]', 'موز', 'مُوزْ', '1f34c'),
    ('ن', 'نون', 'النُونْ', '[[nˈa]]', 'نجمة', 'نِجْمَهْ', '2b50'),
    ('ه', 'هاء', 'الهَاءْ', '[[hˈa]]', 'هدية', 'هِدِيَهْ', '1f381'),
    ('و', 'واو', 'الوَاوْ', '[[wˈa]]', 'وردة', 'وَرْدَهْ', '1f339'),
    ('ي', 'ياء', 'اليَاءْ', '[[jˈa]]', 'يد', 'يَدْ', '270b'),
]
AR_SIMILAR = [list('بتثني'), list('جحخ'), list('دذ'), list('رزو'), list('سش'), list('صض'), list('طظ'),
              list('عغ'), list('فق'), list('كل'), list('مه')]

# letter, raw IPA sound, word, emoji, "X is for"/"X is in"
EN_LETTERS = [
    ('A', 'ˈæ', 'apple', '1f34e'), ('B', 'bˈʌ', 'ball', '26bd'), ('C', 'kˈʌ', 'cat', '1f431'),
    ('D', 'dˈʌ', 'dog', '1f436'), ('E', 'ˈɛ', 'elephant', '1f418'), ('F', 'fˈʌ', 'fish', '1f41f'),
    ('G', 'ɡˈʌ', 'goat', '1f410'), ('H', 'hˈʌ', 'hat', '1f3a9'), ('I', 'ˈɪ', 'insect', '1f41b'),
    ('J', 'dʒˈʌ', 'juice', '1f9c3'), ('K', 'kˈʌ', 'kite', '1fa81'), ('L', 'lˈʌ', 'lion', '1f981'),
    ('M', 'mˈʌ', 'moon', '1f319'), ('N', 'nˈʌ', 'nose', '1f443'), ('O', 'ˈɑː', 'octopus', '1f419'),
    ('P', 'pˈʌ', 'pig', '1f437'), ('Q', 'kwˈʌ', 'queen', '1f478'), ('R', 'ɹˈʌ', 'rabbit', '1f430'),
    ('S', 'sˈʌ', 'sun', '2600'), ('T', 'tˈʌ', 'tree', '1f333'), ('U', 'ˈʌ', 'umbrella', '2602'),
    ('V', 'vˈʌ', 'van', '1f690'), ('W', 'wˈʌ', 'whale', '1f433'), ('X', 'ˈɛks', 'box', '1f4e6'),
    ('Y', 'jˈʌ', 'yo-yo', '1fa80'), ('Z', 'zˈʌ', 'zebra', '1f993'),
]
EN_SIMILAR = [list('BDPR'), list('CGOQ'), list('EF'), list('ILTJ'), list('MNW'), list('UVY'), list('KXZ'), list('AH'), list('SZ')]

AR_NUMBERS = [('١', 'واحد', 'وَاحِدْ'), ('٢', 'اتنين', 'اِتْنِينْ'), ('٣', 'تلاتة', 'تَلَاتَهْ'), ('٤', 'أربعة', 'أَرْبَعَهْ'),
              ('٥', 'خمسة', 'خَمْسَهْ'), ('٦', 'ستة', 'سِتَّهْ'), ('٧', 'سبعة', 'سَبْعَهْ'), ('٨', 'تمانية', 'تَمَانْيَهْ'),
              ('٩', 'تسعة', 'تِسْعَهْ'), ('١٠', 'عشرة', 'عَشَرَهْ')]
EN_NUMBERS = ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten']

COUNT_EMOJI = ['1f34e', '2b50', '1f388', '1f41f', '1f34c', '1f339', '1f986', '26bd', '1f353', '1f98b']
UI_EMOJI = ['2b50', '1f3e0', '1f50a', '1f507', '1f442', '2699', '25b6', '1f512', '1f389', '1f504', '2714', '274c']

N_PRAISE = {'ar': 5, 'en': 4}
N_ENCOURAGE = {'ar': 3, 'en': 3}


def build_content():
    modes = {
        'ar_letters': {'lang': 'ar', 'kind': 'letter', 'title': 'الحروف العربية', 'sample': 'أ ب ت', 'similar': AR_SIMILAR,
                       'items': [{'id': 'L%02d' % (i + 1), 'glyph': g, 'name': n, 'word': w, 'emoji': e}
                                 for i, (g, n, _, _, w, _, e) in enumerate(AR_LETTERS)]},
        'en_letters': {'lang': 'en', 'kind': 'letter', 'title': 'English Letters', 'sample': 'A B C', 'similar': EN_SIMILAR,
                       'items': [{'id': 'L%02d' % (i + 1), 'glyph': l, 'glyph2': l.lower(), 'name': l, 'word': w.capitalize(), 'emoji': e}
                                 for i, (l, _, w, e) in enumerate(EN_LETTERS)]},
        'ar_numbers': {'lang': 'ar', 'kind': 'number', 'title': 'الأرقام العربية', 'sample': '١ ٢ ٣', 'similar': [],
                       'items': [{'id': 'N%02d' % (i + 1), 'glyph': g, 'name': n, 'word': n, 'value': i + 1}
                                 for i, (g, n, _) in enumerate(AR_NUMBERS)]},
        'en_numbers': {'lang': 'en', 'kind': 'number', 'title': 'English Numbers', 'sample': '1 2 3', 'similar': [],
                       'items': [{'id': 'N%02d' % (i + 1), 'glyph': str(i + 1), 'name': n.capitalize(), 'word': n.capitalize(), 'value': i + 1}
                                 for i, n in enumerate(EN_NUMBERS)]},
    }
    return {'child': 'خالد', 'modes': modes, 'count_emoji': COUNT_EMOJI, 'praise': N_PRAISE, 'encourage': N_ENCOURAGE}


def all_emoji():
    s = set(COUNT_EMOJI) | set(UI_EMOJI)
    s |= {x[6] for x in AR_LETTERS} | {x[3] for x in EN_LETTERS}
    return sorted(s)


# ----------------------------------------------------------------- narration script
# Each clip is a list of chunks: (text, speed) where speed is the Piper length scale
# (bigger = slower); chunks are joined with short pauses.  '[[..]]' = raw IPA phonemes.
SLOW, NORMAL, SOUND = 1.25, 1.15, 1.5


def narration():
    ar, en = {}, {}
    K = CHILD_AR
    for i, (g, n, name, snd, w, wt, e) in enumerate(AR_LETTERS):
        k = 'L%02d' % (i + 1)
        ar[k + '_intro'] = [('دَهْ حَرْفِ ' + name + '.', SLOW), ('صُوتُهْ:', SLOW), (snd, SOUND), (snd, SOUND), (wt + '.', SLOW)]
        ar[k + '_find'] = [('يَلَّا يَا ' + K + '.', NORMAL), ('نِطِيرْ وِنْدَوْوَرْ عَلَى حَرْفِ ' + name + '!', SLOW)]
        ar[k + '_short'] = [('حَرْفِ ' + name + '.', SLOW), (snd, SOUND), (wt + '.', SLOW)]
    for i, (g, n, nt) in enumerate(AR_NUMBERS):
        k = 'N%02d' % (i + 1)
        ar[k + '_count'] = [(nt + '.', SLOW)]
        ar[k + '_intro'] = [(nt + '!', SLOW), ('دَهْ رَقَمْ ' + nt + '.', SLOW)]
        ar[k + '_find'] = [('يَلَّا يَا ' + K + '.', NORMAL), ('نِطِيرْ وِنْدَوْوَرْ عَلَى رَقَمْ ' + nt + '!', SLOW)]
        ar[k + '_short'] = [('رَقَمْ ' + nt + '.', SLOW)]
    ar['praise1'] = [('بْرَافُو يَا ' + K + '.', NORMAL), ('شَاطِرْ يَا بَطَلْ!', NORMAL)]
    ar['praise2'] = [('هَائِلْ يَا ' + K + '.', NORMAL), ('إِنْتَ نِجْمْ!', NORMAL)]
    ar['praise3'] = [('جَمِيلْ أَوِي يَا ' + K + '.', NORMAL)]
    ar['praise4'] = [('صَحْ يَا ' + K + '.', NORMAL), ('إِنْتَ بَطَلْ خَارِقْ!', NORMAL)]
    ar['praise5'] = [('شَاطِرْ أَوِي يَا ' + K + '.', NORMAL), ('كَمِّلْ يَا بَطَلْ!', NORMAL)]
    ar['enc1'] = [('أَرَّبْتْ يَا ' + K + '.', NORMAL), ('اِسْمَعِ الصُوتْ تَانِي وِجَرَّبْ.', SLOW)]
    ar['enc2'] = [('وَلَا يِهِمَّكْ يَا ' + K + '.', NORMAL), ('جَرَّبْ كَمَانْ مَرَّهْ.', SLOW)]
    ar['enc3'] = [('حَاوِلْ تَانِي يَا بَطَلْ!', NORMAL), ('إِنْتَ تِئْدَرْ.', SLOW)]
    ar['hint'] = [('بُصْ يَا ' + K + '.', NORMAL), ('الدَايْرَهْ اللِي بِتْنَوْوَرْ.', SLOW)]
    ar['tap'] = [('دُوسْ عَلَى الدَايْرَهْ الصَحْ يَا ' + K + '.', SLOW)]
    ar['count_intro'] = [('تَعَالَى نِعِدْ مَعَ بَعْضْ يَا ' + K + '.', SLOW)]
    ar['end'] = [('خَلَّصْنَا المُهِمَّهْ يَا ' + K + '.', NORMAL), ('إِنْتَ بَطَلْ!', NORMAL), ('جَمَّعْتْ نُجُومْ كِتِيرْ!', SLOW)]
    ar['welcome'] = [('أَهْلًا يَا ' + K + '.', NORMAL), ('يَلَّا نِلْعَبْ وِنِتْعَلِّمْ!', SLOW)]
    ar['choose'] = [('اِخْتَارْ مُغَامْرَهْ يَا بَطَلْ!', SLOW)]
    ar['mode_ar_letters'] = [('حُرُوفْ عَرَبِي!', SLOW)]
    ar['mode_ar_numbers'] = [('أَرْقَامْ عَرَبِي!', SLOW)]

    C = CHILD_EN
    for i, (l, snd, w, e) in enumerate(EN_LETTERS):
        k = 'L%02d' % (i + 1)
        tail = '%s is in %s.' % (l, w) if l == 'X' else '%s is for %s.' % (l, w)
        en[k + '_intro'] = [('This is the letter %s.' % l, SLOW), ('%s says:' % l, SLOW), ('[[%s]]' % snd, SOUND), ('[[%s]]' % snd, SOUND), (tail, SLOW)]
        en[k + '_find'] = [("Let's fly, %s!" % C, NORMAL), ('Find the letter %s!' % l, SLOW)]
        en[k + '_short'] = [('The letter %s.' % l, SLOW), ('[[%s]]' % snd, SOUND), (w.capitalize() + '.', SLOW)]
    for i, n in enumerate(EN_NUMBERS):
        k = 'N%02d' % (i + 1)
        en[k + '_count'] = [(n.capitalize() + '.', SLOW)]
        en[k + '_intro'] = [(n.capitalize() + '!', SLOW), ('This is the number %s.' % n, SLOW)]
        en[k + '_find'] = [("Let's fly, %s!" % C, NORMAL), ('Find the number %s!' % n, SLOW)]
        en[k + '_short'] = [('Number %s.' % n, SLOW)]
    en['praise1'] = [('Bravo, %s!' % C, NORMAL), ('Great job, hero!', NORMAL)]
    en['praise2'] = [('Amazing, %s!' % C, NORMAL), ('You are a star!', NORMAL)]
    en['praise3'] = [('Yes! Well done, %s!' % C, NORMAL)]
    en['praise4'] = [('Super, %s!' % C, NORMAL), ('Keep going, hero!', NORMAL)]
    en['enc1'] = [('So close, %s!' % C, NORMAL), ('Listen again, and try.', SLOW)]
    en['enc2'] = [('No worries, %s!' % C, NORMAL), ('Try one more time.', SLOW)]
    en['enc3'] = [('Try again, hero!', NORMAL), ('You can do it.', SLOW)]
    en['hint'] = [('Look, %s!' % C, NORMAL), ('The glowing ring.', SLOW)]
    en['tap'] = [('Tap the right ring, %s!' % C, SLOW)]
    en['count_intro'] = [("Let's count together, %s!" % C, SLOW)]
    en['end'] = [('Mission complete, %s!' % C, NORMAL), ('You are a hero!', NORMAL), ('You collected so many stars!', SLOW)]
    en['mode_en_letters'] = [('English letters!', SLOW), ('A, B, C!', SLOW)]
    en['mode_en_numbers'] = [('English numbers!', SLOW), ('One, two, three!', SLOW)]
    return {'ar': ar, 'en': en}


if __name__ == '__main__':
    os.makedirs(os.path.join(ROOT, 'data'), exist_ok=True)
    with open(os.path.join(ROOT, 'data', 'content.json'), 'w', encoding='utf-8') as f:
        json.dump(build_content(), f, ensure_ascii=False, indent=1)
    n = narration()
    print('content.json written; narration clips: ar=%d en=%d; emoji=%d' % (len(n['ar']), len(n['en']), len(all_emoji())))
