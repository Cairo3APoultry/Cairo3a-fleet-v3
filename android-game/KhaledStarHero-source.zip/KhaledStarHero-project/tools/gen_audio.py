#!/usr/bin/env python3
"""Renders every narrator line, the sound effects and the music loop to
assets/audio/**.ogg so the game needs no network and no device TTS at run time.

Needs:  pip install piper-tts soundfile numpy   and ffmpeg (libvorbis)
Voices: ar_JO-kareem-medium, en_US-lessac-medium (Piper .onnx + .onnx.json)
        set KHALED_VOICES=/path/to/folder containing both voice folders.
Run:    python3 tools/gen_audio.py [--only-sfx]
"""
import os, re, subprocess, sys, tempfile
import numpy as np
import soundfile as sf

sys.path.insert(0, os.path.dirname(__file__))
import content

ROOT = os.path.join(os.path.dirname(__file__), '..')
OUT = os.path.join(ROOT, 'assets', 'audio')
VOICES = os.environ.get('KHALED_VOICES', '/home/claude/tools/tts')
SR = 22050


def save(path, x, sr=SR, q=4):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    x = np.clip(np.asarray(x, dtype=np.float32), -1, 1)
    with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
        sf.write(tmp.name, x, sr, subtype='PCM_16')
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', tmp.name, '-c:a', 'libvorbis', '-q:a', str(q), path], check=True)
    os.unlink(tmp.name)


# ----------------------------------------------------------------- narration
def trim(x, thr=0.012, pad=0.03):
    idx = np.where(np.abs(x) > thr)[0]
    if len(idx) == 0:
        return x
    a = max(0, idx[0] - int(pad * SR))
    b = min(len(x), idx[-1] + int(pad * SR))
    y = x[a:b].copy()
    f = min(len(y) // 2, int(0.01 * SR))
    if f > 0:
        y[:f] *= np.linspace(0, 1, f)
        y[-f:] *= np.linspace(1, 0, f)
    return y


def norm_ar(t):
    # the phonemizer expects shadda before the vowel mark
    return re.sub('([ً-ِْ])ّ', 'ّ\\1', t)


def render_narration():
    from piper import PiperVoice, SynthesisConfig
    v_ar = PiperVoice.load(os.path.join(VOICES, 'vits-piper-ar_JO-kareem-medium', 'ar_JO-kareem-medium.onnx'))
    v_ar.use_tashkeel = False          # every Arabic line is already fully diacritised by hand
    v_en = PiperVoice.load(os.path.join(VOICES, 'vits-piper-en_US-lessac-medium', 'en_US-lessac-medium.onnx'))
    cache = {}
    report = []

    def chunk(voice, lang, text, length):
        key = (lang, text, length)
        if key not in cache:
            t = norm_ar(text) if lang == 'ar' else text
            cfg = SynthesisConfig(length_scale=length, noise_scale=0.3 if lang == 'ar' else 0.45, noise_w_scale=0.6, normalize_audio=True)
            parts = [c.audio_float_array for c in voice.synthesize(t, syn_config=cfg)]
            x = trim(np.concatenate(parts).astype(np.float32))
            if x.size == 0 or np.abs(x).max() < 0.05:
                raise RuntimeError('silent synthesis for %r' % text)
            ph = ' | '.join(''.join(p) for p in voice.phonemize(t))
            cache[key] = (x * (0.9 / np.abs(x).max()), ph)
        return cache[key]

    for lang, voice in (('ar', v_ar), ('en', v_en)):
        clips = content.narration()[lang]
        for name, chunks in clips.items():
            out, phs = [], []
            for i, (text, length) in enumerate(chunks):
                x, ph = chunk(voice, lang, text, length)
                out.append(x)
                phs.append(ph)
                if i < len(chunks) - 1:
                    is_sound = '[[' in text or '[[' in chunks[i + 1][0]
                    out.append(np.zeros(int((0.42 if is_sound else 0.30) * SR), dtype=np.float32))
            y = np.concatenate([np.zeros(int(0.05 * SR), dtype=np.float32)] + out + [np.zeros(int(0.12 * SR), dtype=np.float32)])
            save(os.path.join(OUT, lang, name + '.ogg'), y)
            report.append('%s/%s\t%.2fs\t%s\t[%s]' % (lang, name, len(y) / SR, ' / '.join(c[0] for c in chunks), ' / '.join(phs)))
        print(lang, len(clips), 'clips')
    with open(os.path.join(ROOT, 'tools', 'audio_report.tsv'), 'w', encoding='utf-8') as f:
        f.write('clip\tduration\ttext\tphonemes\n' + '\n'.join(report) + '\n')


# ----------------------------------------------------------------- sfx + music
def env(n, a=0.005, d=0.3, curve=4.0):
    t = np.arange(n) / SR
    e = np.exp(-t * curve / max(d, 1e-3))
    na = max(1, int(a * SR))
    e[:na] *= np.linspace(0, 1, na)
    return e


def bell(freq, dur, amp=0.5, harm=((1, 1.0), (2, 0.35), (3, 0.12), (4.2, 0.06))):
    n = int(dur * SR)
    t = np.arange(n) / SR
    x = sum(a * np.sin(2 * np.pi * freq * h * t) * np.exp(-t * (3 + h * 2) / dur) for h, a in harm)
    return (x * amp * env(n, 0.004, dur, 1.0)).astype(np.float32)


def place(buf, x, at):
    i = int(at * SR)
    j = min(len(buf), i + len(x))
    buf[i:j] += x[:j - i]


def note(n):  # midi -> Hz
    return 440.0 * 2 ** ((n - 69) / 12)


def render_sfx():
    rng = np.random.RandomState(7)
    d = os.path.join(OUT, 'sfx')
    # tap
    save(os.path.join(d, 'tap.ogg'), bell(note(84), 0.12, 0.5))
    # count tick
    save(os.path.join(d, 'count.ogg'), bell(note(79), 0.25, 0.55))
    # pop: fast downward chirp + a puff of noise
    n = int(0.22 * SR)
    t = np.arange(n) / SR
    f = 900 * np.exp(-t * 14) + 180
    pop = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 16) * 0.8
    pop[:int(0.03 * SR)] += rng.uniform(-1, 1, int(0.03 * SR)) * np.linspace(0.5, 0, int(0.03 * SR))
    save(os.path.join(d, 'pop.ogg'), pop)
    # sparkle: bright rising arpeggio
    buf = np.zeros(int(1.3 * SR), dtype=np.float32)
    for i, m in enumerate((84, 88, 91, 96, 100)):
        place(buf, bell(note(m), 0.7, 0.32), i * 0.085)
    save(os.path.join(d, 'sparkle.ogg'), buf)
    # star collected
    buf = np.zeros(int(0.8 * SR), dtype=np.float32)
    place(buf, bell(note(91), 0.5, 0.4), 0.0)
    place(buf, bell(note(96), 0.6, 0.4), 0.09)
    save(os.path.join(d, 'star.ogg'), buf)
    # gentle "try again": two soft, low marimba notes (never harsh)
    buf = np.zeros(int(0.7 * SR), dtype=np.float32)
    soft = ((1, 1.0), (2, 0.15))
    place(buf, bell(note(67), 0.35, 0.4, soft), 0.0)
    place(buf, bell(note(64), 0.45, 0.4, soft), 0.16)
    save(os.path.join(d, 'soft.ogg'), buf)
    # whoosh: band-passed noise swell
    n = int(0.9 * SR)
    t = np.arange(n) / SR
    noise = rng.uniform(-1, 1, n)
    y = np.zeros(n)
    lp = 0.0
    for i in range(n):
        k = 0.02 + 0.22 * np.sin(np.pi * t[i] / 0.9) ** 2
        lp += k * (noise[i] - lp)
        y[i] = lp
    y = (y - np.convolve(y, np.ones(200) / 200, 'same')) * np.sin(np.pi * t / 0.9) ** 2 * 1.6
    save(os.path.join(d, 'whoosh.ogg'), y)
    # fanfare
    buf = np.zeros(int(2.6 * SR), dtype=np.float32)
    for at, ms, dur in ((0.0, (72, 76), 0.4), (0.22, (76, 79), 0.4), (0.44, (79, 84), 0.4), (0.72, (84, 88, 91), 1.7)):
        for m in ms:
            place(buf, bell(note(m), dur, 0.26), at)
    save(os.path.join(d, 'fanfare.ogg'), buf)

    # music: calm 16-bar loop in C major pentatonic, 88 bpm, seamless
    bpm = 88.0
    beat = 60.0 / bpm
    bars = 16
    total = int(bars * 4 * beat * SR)
    mus = np.zeros(total + SR * 3, dtype=np.float32)
    chords = [(48, 55, 64), (43, 55, 62), (45, 57, 64), (41, 53, 60)] * 4      # C G Am F
    mel = [76, None, 79, 81, 79, None, 76, 74, 72, None, 74, 76, 74, None, 72, None,
           76, None, 79, 84, 81, None, 79, 76, 74, None, 76, 79, 76, None, None, None]
    pad_h = ((1, 1.0), (2, 0.2), (3, 0.05))
    for b in range(bars):
        at = b * 4 * beat
        for m in chords[b]:
            n = int(4.4 * beat * SR)
            t = np.arange(n) / SR
            e = np.minimum(1, t / 0.5) * np.minimum(1, (4.4 * beat - t) / 0.8)
            x = sum(a * np.sin(2 * np.pi * note(m) * h * t) for h, a in pad_h) * e * 0.055
            place(mus, x.astype(np.float32), at)
        for k in range(4):   # soft plucked arpeggio
            place(mus, bell(note(chords[b][k % 3] + 12), 0.9, 0.07, ((1, 1.0), (2, 0.2))), at + k * beat)
        for k in range(8):
            m = mel[(b % 4) * 8 + k]
            if m is not None and (b % 8) >= 2:
                place(mus, bell(note(m), 1.1, 0.10), at + k * beat / 2)
    mus[:len(mus) - total] += mus[total:]        # wrap the tails so the loop is seamless
    mus = mus[:total]
    mus *= 0.5 / np.abs(mus).max()
    save(os.path.join(d, 'music.ogg'), mus, q=3)
    print('sfx + music done (music loop %.1fs)' % (total / SR))


if __name__ == '__main__':
    render_sfx()
    if '--only-sfx' not in sys.argv:
        render_narration()
