#!/usr/bin/env python3
"""Generates the rigged 3D hero model for Khaled (assets/khaled/khaled.glb).

Pure-python glTF 2.0 writer: one skinned mesh (several material primitives),
a 34-bone skeleton and a set of keyframed animation clips.
Run:  python3 tools/gen_character.py
"""
import json, math, struct, sys, os
import numpy as np

OUT = os.path.join(os.path.dirname(__file__), '..', 'assets', 'khaled', 'khaled.glb')

# ----------------------------------------------------------------- skeleton
# name: (parent, world rest position). All rest rotations are identity.
BONES = [
    ('root', None, (0, 0, 0)),
    ('hips', 'root', (0, 0.36, 0)),
    ('spine', 'hips', (0, 0.43, 0)),
    ('chest', 'spine', (0, 0.51, 0)),
    ('neck', 'chest', (0, 0.615, 0)),
    ('head', 'neck', (0, 0.66, 0)),
    ('brow_l', 'head', (0.075, 0.862, 0.12)),
    ('brow_r', 'head', (-0.075, 0.862, 0.12)),
    ('lid_l', 'head', (0.072, 0.846, 0.135)),
    ('lid_r', 'head', (-0.072, 0.846, 0.135)),
    ('mouth', 'head', (0, 0.722, 0.15)),
    ('mouth_open', 'head', (0, 0.72, 0.145)),
    ('upperarm_l', 'chest', (0.168, 0.575, 0)),
    ('forearm_l', 'upperarm_l', (0.168, 0.455, 0)),
    ('hand_l', 'forearm_l', (0.168, 0.345, 0)),
    ('thumb_l', 'hand_l', (0.168, 0.33, 0.035)),
    ('upperarm_r', 'chest', (-0.168, 0.575, 0)),
    ('forearm_r', 'upperarm_r', (-0.168, 0.455, 0)),
    ('hand_r', 'forearm_r', (-0.168, 0.345, 0)),
    ('thumb_r', 'hand_r', (-0.168, 0.33, 0.035)),
    ('finger_r', 'hand_r', (-0.168, 0.30, 0.01)),
    ('cape1', 'chest', (0, 0.61, -0.095)),
    ('cape2', 'cape1', (0, 0.45, -0.115)),
    ('cape3', 'cape2', (0, 0.29, -0.135)),
    ('thigh_l', 'hips', (0.064, 0.34, 0)),
    ('shin_l', 'thigh_l', (0.064, 0.205, 0)),
    ('foot_l', 'shin_l', (0.064, 0.075, 0)),
    ('thigh_r', 'hips', (-0.064, 0.34, 0)),
    ('shin_r', 'thigh_r', (-0.064, 0.205, 0)),
    ('foot_r', 'shin_r', (-0.064, 0.075, 0)),
]
BIDX = {b[0]: i for i, b in enumerate(BONES)}
BPOS = {b[0]: np.array(b[2], dtype=np.float64) for b in BONES}
BPAR = {b[0]: b[1] for b in BONES}

# ----------------------------------------------------------------- materials
def lin(c):
    return [((x / 12.92) if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4) for x in c]

MATS = {  # name: (sRGB colour, roughness, metallic, double sided)
    'skin': ((0.97, 0.77, 0.63), 0.75, 0.0, False),
    'skin2': ((0.93, 0.66, 0.54), 0.75, 0.0, False),
    'hair': ((0.15, 0.09, 0.07), 0.45, 0.0, False),
    'suit': ((0.04, 0.62, 0.74), 0.55, 0.0, False),
    'orange': ((1.0, 0.47, 0.07), 0.45, 0.0, False),
    'cape': ((1.0, 0.42, 0.06), 0.6, 0.0, True),
    'yellow': ((1.0, 0.82, 0.10), 0.35, 0.1, False),
    'white': ((1.0, 1.0, 1.0), 0.3, 0.0, False),
    'iris': ((0.33, 0.17, 0.08), 0.25, 0.0, False),
    'black': ((0.03, 0.02, 0.02), 0.15, 0.0, False),
    'mouth': ((0.50, 0.10, 0.10), 0.6, 0.0, False),
    'pink': ((1.0, 0.60, 0.60), 0.8, 0.0, False),
    'tongue': ((0.96, 0.45, 0.50), 0.6, 0.0, False),
}

# ----------------------------------------------------------------- geometry
PARTS = {m: {'v': [], 'n': [], 'j': [], 'w': [], 'i': [], 'count': 0} for m in MATS}


def add_part(mat, verts, norms, tris, weights):
    """weights: either a bone name, or a function(vertex)->{bone: w}."""
    p = PARTS[mat]
    base = p['count']
    verts = np.asarray(verts, dtype=np.float64)
    norms = np.asarray(norms, dtype=np.float64)
    nl = np.linalg.norm(norms, axis=1, keepdims=True)
    nl[nl == 0] = 1
    norms = norms / nl
    for v in verts:
        wd = {weights: 1.0} if isinstance(weights, str) else weights(v)
        items = sorted(wd.items(), key=lambda kv: -kv[1])[:4]
        s = sum(w for _, w in items)
        js = [BIDX[b] for b, _ in items] + [0] * (4 - len(items))
        ws = [w / s for _, w in items] + [0.0] * (4 - len(items))
        p['j'].append(js)
        p['w'].append(ws)
    p['v'].extend(verts.tolist())
    p['n'].extend(norms.tolist())
    p['i'].extend((np.asarray(tris) + base).tolist())
    p['count'] += len(verts)


def rot_y(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def rot_x(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def rot_z(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def unit_sphere(nu=20, nv=14):
    verts, tris = [], []
    for j in range(nv + 1):
        th = math.pi * j / nv
        for i in range(nu + 1):
            ph = 2 * math.pi * i / nu
            verts.append((math.sin(th) * math.sin(ph), math.cos(th), math.sin(th) * math.cos(ph)))
    for j in range(nv):
        for i in range(nu):
            a = j * (nu + 1) + i
            b = a + nu + 1
            if j > 0:
                tris.append((a, b, a + 1))
            if j < nv - 1:
                tris.append((a + 1, b, b + 1))
    return np.array(verts), np.array(tris)


def ellipsoid(mat, center, radii, weights, R=None, nu=20, nv=14):
    v, t = unit_sphere(nu, nv)
    radii = np.array(radii, dtype=np.float64)
    pos = v * radii
    nrm = v / radii
    if R is not None:
        pos = pos @ R.T
        nrm = nrm @ R.T
    add_part(mat, pos + np.array(center), nrm, t, weights)


def capsule(mat, p0, p1, r0, r1, weights, nu=16, nseg=10, ncap=5, zscale=1.0, xscale=1.0):
    """Vertical-ish capsule from p0 (top) to p1 (bottom) along -Y, radius r0->r1."""
    p0 = np.array(p0, dtype=np.float64)
    p1 = np.array(p1, dtype=np.float64)
    rings = []  # (center, radius, normal_y)
    for k in range(ncap, 0, -1):  # top cap
        a = (math.pi / 2) * k / ncap
        rings.append((p0 + np.array([0, r0 * math.sin(a), 0]), r0 * math.cos(a), math.sin(a)))
    for k in range(nseg + 1):
        t = k / nseg
        rings.append((p0 + (p1 - p0) * t, r0 + (r1 - r0) * t, 0.0))
    for k in range(1, ncap + 1):
        a = (math.pi / 2) * k / ncap
        rings.append((p1 - np.array([0, r1 * math.sin(a), 0]), r1 * math.cos(a), -math.sin(a)))
    verts, norms, tris = [], [], []
    for c, r, ny in rings:
        for i in range(nu + 1):
            ph = 2 * math.pi * i / nu
            dx, dz = math.sin(ph), math.cos(ph)
            verts.append((c[0] + dx * r * xscale, c[1], c[2] + dz * r * zscale))
            h = math.sqrt(max(0.0, 1 - ny * ny))
            norms.append((dx * h / xscale, ny, dz * h / zscale))
    for j in range(len(rings) - 1):
        for i in range(nu):
            a = j * (nu + 1) + i
            b = a + nu + 1
            tris.append((a, b, a + 1))
            tris.append((a + 1, b, b + 1))
    add_part(mat, verts, norms, tris, weights)


def torus(mat, center, rx, rz, tube, weights, nu=28, nv=10, tube_y=None):
    tube_y = tube_y or tube
    verts, norms, tris = [], [], []
    for i in range(nu + 1):
        ph = 2 * math.pi * i / nu
        dx, dz = math.sin(ph), math.cos(ph)
        for j in range(nv + 1):
            th = 2 * math.pi * j / nv
            cr, sr = math.cos(th), math.sin(th)
            verts.append((center[0] + dx * (rx + tube * cr), center[1] + tube_y * sr, center[2] + dz * (rz + tube * cr)))
            norms.append((dx * cr, sr, dz * cr))
    for i in range(nu):
        for j in range(nv):
            a = i * (nv + 1) + j
            b = a + nv + 1
            tris.append((a, a + 1, b))
            tris.append((a + 1, b + 1, b))
    add_part(mat, verts, norms, tris, weights)


def tube_path(mat, pts, radius, weights, nu=8):
    pts = [np.array(p, dtype=np.float64) for p in pts]
    verts, norms, tris = [], [], []
    for k, p in enumerate(pts):
        d = pts[min(k + 1, len(pts) - 1)] - pts[max(k - 1, 0)]
        d /= np.linalg.norm(d)
        up = np.array([0, 0, 1.0])
        s = np.cross(d, up)
        s /= np.linalg.norm(s)
        u = np.cross(s, d)
        rr = radius * (0.55 + 0.45 * math.sin(math.pi * k / (len(pts) - 1)))
        for i in range(nu + 1):
            a = 2 * math.pi * i / nu
            n = s * math.cos(a) + u * math.sin(a)
            verts.append(p + n * rr)
            norms.append(n)
    for k in range(len(pts) - 1):
        for i in range(nu):
            a = k * (nu + 1) + i
            b = a + nu + 1
            tris.append((a, a + 1, b))
            tris.append((a + 1, b + 1, b))
    add_part(mat, verts, norms, tris, weights)


def flat_poly_prism(mat, center, outline, depth, weights, R=None):
    """Flat-shaded prism: outline is a list of (x,y) in the XY plane, extruded along +Z."""
    c = np.array(center, dtype=np.float64)
    R = np.eye(3) if R is None else R
    verts, norms, tris = [], [], []

    def emit(a, b, cc):
        n = np.cross(np.array(b) - np.array(a), np.array(cc) - np.array(a))
        base = len(verts)
        for p in (a, b, cc):
            verts.append(c + R @ np.array(p))
            norms.append(R @ n)
        tris.append((base, base + 1, base + 2))

    n = len(outline)
    zf, zb = depth, 0.0
    for i in range(n):
        x0, y0 = outline[i]
        x1, y1 = outline[(i + 1) % n]
        emit((0, 0, zf), (x0, y0, zf), (x1, y1, zf))          # front fan
        emit((x0, y0, zb), (x1, y1, zb), (x1, y1, zf))        # side
        emit((x0, y0, zb), (x1, y1, zf), (x0, y0, zf))
    add_part(mat, verts, norms, tris, weights)


def star_outline(R, r, n=5, rot=0.0):
    pts = []
    for i in range(n * 2):
        a = rot + math.pi / 2 + math.pi * i / n
        rad = R if i % 2 == 0 else r
        pts.append((rad * math.cos(a), rad * math.sin(a)))
    return pts


def circle_outline(R, n=28):
    return [(R * math.cos(2 * math.pi * i / n), R * math.sin(2 * math.pi * i / n)) for i in range(n)]


def smooth(a, b, x):
    t = min(1.0, max(0.0, (x - a) / (b - a)))
    return t * t * (3 - 2 * t)


def blend2(b0, b1, y, y_mid, band):
    """b0 above y_mid, b1 below."""
    w1 = smooth(y_mid + band, y_mid - band, y)
    return {b0: 1 - w1 + 1e-6, b1: w1 + 1e-6}


HEAD_C = np.array([0, 0.80, 0.0])
HEAD_R = np.array([0.19, 0.185, 0.18])


def head_z(x, y):
    """front surface z of the head ellipsoid for a given x, y (world)."""
    dx = (x - HEAD_C[0]) / HEAD_R[0]
    dy = (y - HEAD_C[1]) / HEAD_R[1]
    return HEAD_C[2] + HEAD_R[2] * math.sqrt(max(0.0, 1 - dx * dx - dy * dy))


def build_mesh():
    # ---- torso (suit)
    def torso_w(v):
        y = v[1]
        if y > 0.47:
            return blend2('chest', 'spine', y, 0.49, 0.03)
        return blend2('spine', 'hips', y, 0.415, 0.03)
    capsule('suit', (0, 0.575, 0), (0, 0.37, 0), 0.122, 0.112, torso_w, nu=24, nseg=10, ncap=6, zscale=0.80)
    # shoulders bridge
    ellipsoid('suit', (0, 0.585, 0), (0.175, 0.05, 0.085), 'chest', nu=20, nv=10)
    # neck + collar
    capsule('skin', (0, 0.67, 0), (0, 0.61, 0), 0.047, 0.05, lambda v: blend2('neck', 'chest', v[1], 0.625, 0.02), nu=14, nseg=3, ncap=2)
    torus('orange', (0, 0.622, -0.005), 0.062, 0.058, 0.02, 'chest', nu=24, nv=8, tube_y=0.016)
    # belt + star buckle
    torus('yellow', (0, 0.392, 0), 0.118, 0.094, 0.014, 'hips', nu=32, nv=8, tube_y=0.022)
    flat_poly_prism('white', (0, 0.392, 0.103), circle_outline(0.036), 0.012, 'hips')
    flat_poly_prism('orange', (0, 0.392, 0.115), star_outline(0.03, 0.013), 0.008, 'hips')
    # chest emblem: round badge with rim (the letter is attached in-engine)
    tilt = rot_x(math.radians(-8))
    flat_poly_prism('yellow', (0, 0.515, 0.094), circle_outline(0.066, 32), 0.014, 'chest', R=tilt)
    flat_poly_prism('white', (0, 0.515, 0.1085), circle_outline(0.052, 32), 0.004, 'chest', R=tilt)

    for side, sx in (('l', 1), ('r', -1)):
        ua, fa, ha = 'upperarm_' + side, 'forearm_' + side, 'hand_' + side
        x = 0.168 * sx
        # arm
        capsule('suit', (x, 0.575, 0), (x, 0.35, 0), 0.047, 0.04,
                lambda v, ua=ua, fa=fa: blend2(ua, fa, v[1], 0.455, 0.035), nu=14, nseg=12, ncap=4)
        # wrist cuff
        capsule('orange', (x, 0.405, 0), (x, 0.355, 0), 0.05, 0.047, fa, nu=14, nseg=2, ncap=2)
        torus('yellow', (x, 0.41, 0), 0.047, 0.047, 0.009, fa, nu=18, nv=6)
        # hand
        ellipsoid('skin', (x, 0.322, 0.004), (0.045, 0.05, 0.047), ha, nu=14, nv=10)
        ellipsoid('skin', (x - 0.012 * sx, 0.325, 0.045), (0.017, 0.028, 0.017), 'thumb_' + side,
                  R=rot_x(math.radians(-25)), nu=10, nv=8)
        if side == 'r':
            capsule('skin', (x, 0.292, 0.012), (x, 0.245, 0.012), 0.0165, 0.0145, 'finger_r', nu=10, nseg=2, ncap=3)
        # leg
        lx = 0.064 * sx
        th, sh, ft = 'thigh_' + side, 'shin_' + side, 'foot_' + side
        capsule('suit', (lx, 0.35, 0), (lx, 0.10, 0), 0.06, 0.05,
                lambda v, th=th, sh=sh: (blend2(th, sh, v[1], 0.205, 0.035) if v[1] < 0.33 else {th: 0.75, 'hips': 0.25}),
                nu=14, nseg=12, ncap=4)
        # boot
        capsule('orange', (lx, 0.165, 0), (lx, 0.07, 0), 0.06, 0.058, sh, nu=14, nseg=3, ncap=3)
        torus('yellow', (lx, 0.172, 0), 0.056, 0.056, 0.012, sh, nu=18, nv=6)
        ellipsoid('orange', (lx, 0.045, 0.036), (0.062, 0.046, 0.098), ft, nu=16, nv=10)
        ellipsoid('yellow', (lx, 0.012, 0.036), (0.06, 0.012, 0.096), ft, nu=16, nv=6)

    # ---- head
    ellipsoid('skin', HEAD_C, HEAD_R, 'head', nu=28, nv=20)
    for sx in (1, -1):
        s = 'l' if sx > 0 else 'r'
        ellipsoid('skin', (0.186 * sx, 0.79, -0.005), (0.03, 0.042, 0.022), 'head', nu=12, nv=8)
        ellipsoid('skin2', (0.193 * sx, 0.79, 0.004), (0.016, 0.026, 0.012), 'head', nu=10, nv=6)
        # eye stack (local frame rotated to follow the face curvature)
        ex, ey = 0.072 * sx, 0.795
        ez = head_z(ex, ey) - 0.012
        R = rot_y(math.radians(13 * sx))
        ec = np.array([ex, ey, ez])
        ellipsoid('white', ec, (0.040, 0.046, 0.022), 'head', R=R, nu=18, nv=12)
        ellipsoid('iris', ec + R @ np.array([-0.004 * sx, -0.002, 0.014]), (0.027, 0.031, 0.012), 'head', R=R, nu=16, nv=10)
        ellipsoid('black', ec + R @ np.array([-0.004 * sx, -0.002, 0.021]), (0.015, 0.018, 0.008), 'head', R=R, nu=12, nv=8)
        ellipsoid('white', ec + R @ np.array([0.008, 0.012, 0.027]), (0.008, 0.008, 0.004), 'head', R=R, nu=8, nv=6)
        # eyelid (collapsed by its bone scale except when blinking)
        ellipsoid('skin', ec + R @ np.array([0, 0, 0.004]), (0.044, 0.050, 0.03), 'lid_' + s, R=R, nu=16, nv=10)
        # eyebrow
        by = 0.859
        bz = head_z(0.075 * sx, by) + 0.002
        ellipsoid('hair', (0.075 * sx, by, bz), (0.04, 0.0125, 0.012), 'brow_' + s,
                  R=rot_y(math.radians(16 * sx)) @ rot_z(math.radians(-7 * sx)), nu=12, nv=6)
        # cheek
        cx, cy = 0.118 * sx, 0.742
        ellipsoid('pink', (cx, cy, head_z(cx, cy) - 0.004), (0.03, 0.02, 0.008), 'head',
                  R=rot_y(math.radians(38 * sx)), nu=12, nv=6)
        # sideburn
        ellipsoid('hair', (0.168 * sx, 0.835, 0.045), (0.03, 0.05, 0.04), 'head', nu=10, nv=8)
    # nose
    ellipsoid('skin2', (0, 0.762, head_z(0, 0.762) + 0.004), (0.021, 0.017, 0.018), 'head', nu=12, nv=8)
    # smile
    pts = []
    for k in range(13):
        x = -0.048 + 0.096 * k / 12
        y = 0.722 + 0.02 * (x / 0.048) ** 2 - 0.01
        pts.append((x, y, head_z(x, y) + 0.002))
    tube_path('mouth', pts, 0.0075, 'mouth')
    # open mouth (collapsed by bone scale unless cheering)
    mz = head_z(0, 0.714)
    ellipsoid('mouth', (0, 0.714, mz - 0.004), (0.038, 0.028, 0.012), 'mouth_open', nu=16, nv=10)
    ellipsoid('white', (0, 0.729, mz + 0.002), (0.026, 0.008, 0.008), 'mouth_open', nu=12, nv=6)
    ellipsoid('tongue', (0, 0.701, mz + 0.002), (0.02, 0.011, 0.008), 'mouth_open', nu=12, nv=6)

    # ---- hair cap with a hairline
    hc = np.array([0, 0.815, -0.012])
    hr = np.array([0.203, 0.206, 0.203])
    v, t = unit_sphere(36, 24)
    pos = v * hr + hc
    nrm = v / hr

    def hairline(x, z):
        az = abs(math.degrees(math.atan2(x, z)))  # 0 front .. 180 back
        if az < 95:
            return 0.915 - (0.915 - 0.83) * smooth(40, 95, az)
        return 0.83 - (0.83 - 0.70) * smooth(95, 165, az)
    keep = np.zeros(len(pos), dtype=bool)
    for i, p in enumerate(pos):
        h = hairline(p[0], p[2])
        if p[1] >= h:
            keep[i] = True
        elif p[1] > h - 0.03:   # tuck the rim inside the head
            keep[i] = True
            q = np.array([p[0], h - 0.012, p[2]])
            d = (q - HEAD_C) / HEAD_R
            q = HEAD_C + d / np.linalg.norm(d) * HEAD_R * 0.97
            pos[i] = q
    tris = [tr for tr in t if keep[tr[0]] and keep[tr[1]] and keep[tr[2]]]
    add_part('hair', pos, nrm, tris, 'head')
    # fringe clumps
    rng = np.random.RandomState(4)
    for k, az in enumerate((-62, -44, -27, -9, 9, 27, 44, 62)):
        a = math.radians(az)
        y = 0.924 - 0.018 * (abs(az) / 62.0) + rng.uniform(-0.003, 0.003)
        rad_xz = 0.176 * math.sqrt(max(0.05, 1 - ((y - 0.80) / 0.185) ** 2))
        c = (math.sin(a) * rad_xz * 1.03, y, math.cos(a) * rad_xz * 0.99)
        ellipsoid('hair', c, (0.05, 0.035 + rng.uniform(0, 0.004), 0.028), 'head',
                  R=rot_y(a) @ rot_z(math.radians(rng.uniform(-8, 8))), nu=12, nv=8)
    # tousled volume on top
    for az, el, r in ((0, 62, 0.085), (60, 55, 0.08), (-60, 55, 0.08), (120, 50, 0.085), (-120, 50, 0.085),
                      (180, 55, 0.09), (35, 48, 0.07), (-35, 48, 0.07), (0, 88, 0.09), (150, 15, 0.08), (-150, 15, 0.08),
                      (90, 20, 0.07), (-90, 20, 0.07), (180, 5, 0.085)):
        a, e = math.radians(az), math.radians(el)
        d = np.array([math.sin(a) * math.cos(e), math.sin(e), math.cos(a) * math.cos(e)])
        c = hc + d * hr * 0.70
        ellipsoid('hair', c, (r, r * 0.8, r), 'head', nu=12, nv=8)

    # ---- cape
    nx, ny = 14, 14
    verts, norms, tris = [], [], []
    top_y, bot_y = 0.622, 0.13
    for j in range(ny + 1):
        tt = j / ny
        y = top_y + (bot_y - top_y) * tt
        half_w = 0.135 + 0.10 * tt
        for i in range(nx + 1):
            u = i / nx * 2 - 1
            x = u * half_w
            wrap = 0.05 * (1 - tt) ** 2 * (u * u)            # hugs the shoulders at the top
            z = -0.092 - 0.05 * tt + wrap + 0.012 * math.sin(u * 7.5) * tt
            verts.append((x, y, z))
            norms.append((0.0, 0.1, -1.0))
    for j in range(ny):
        for i in range(nx):
            a = j * (nx + 1) + i
            b = a + nx + 1
            tris.append((a, a + 1, b))
            tris.append((a + 1, b + 1, b))

    def cape_w(v):
        y = v[1]
        if y > 0.58:
            return {'chest': 1.0}
        if y > 0.45:
            w = smooth(0.58, 0.45, y)
            return {'chest': (1 - w) * 0.6 + 1e-6, 'cape1': (1 - w) * 0.4 + w * 0.6 + 1e-6, 'cape2': w * 0.4 + 1e-6}
        if y > 0.29:
            w = smooth(0.45, 0.29, y)
            return {'cape1': (1 - w) * 0.5 + 1e-6, 'cape2': 0.5 + 1e-6, 'cape3': w * 0.5 + 1e-6}
        return {'cape2': 0.25, 'cape3': 0.75}
    add_part('cape', verts, norms, tris, cape_w)
    # star clasps on the shoulders
    for sx in (1, -1):
        flat_poly_prism('yellow', (0.105 * sx, 0.607, 0.06), star_outline(0.026, 0.012), 0.012, 'chest',
                        R=rot_y(math.radians(25 * sx)) @ rot_x(math.radians(-35)))


# ----------------------------------------------------------------- animation
def q_axis(axis, deg):
    a = math.radians(deg) / 2
    s = math.sin(a)
    return np.array([axis[0] * s, axis[1] * s, axis[2] * s, math.cos(a)])


def q_mul(a, b):
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return np.array([aw * bx + ax * bw + ay * bz - az * by,
                     aw * by - ax * bz + ay * bw + az * bx,
                     aw * bz + ax * by - ay * bx + az * bw,
                     aw * bw - ax * bx - ay * by - az * bz])


def q_euler(x, y, z):
    """Apply X, then Y, then Z (parent axes)."""
    return q_mul(q_axis((0, 0, 1), z), q_mul(q_axis((0, 1, 0), y), q_axis((1, 0, 0), x)))


S = lambda t, f=1.0, ph=0.0: math.sin(2 * math.pi * (t * f + ph))
HID = (0.02, 0.02, 0.02)
LID_OPEN = (1.0, 0.03, 0.4)


def base_pose():
    return {
        'rot': {b[0]: (0.0, 0.0, 0.0) for b in BONES},
        'pos': {'root': (0.0, 0.0, 0.0), 'brow_l': (0, 0, 0), 'brow_r': (0, 0, 0)},
        'scl': {'lid_l': LID_OPEN, 'lid_r': LID_OPEN, 'mouth': (1, 1, 1), 'mouth_open': HID,
                'finger_r': HID, 'thumb_l': (1, 1, 1), 'thumb_r': (1, 1, 1), 'chest': (1, 1, 1)},
    }


def blink(p, t, at, dur=0.07):
    d = abs(t - at)
    if d < dur:
        k = 1 - d / dur
        s = (1.0, 0.03 + 0.97 * k, 0.4 + 0.6 * k)
        p['scl']['lid_l'] = s
        p['scl']['lid_r'] = s


def arms_relaxed(p, out=11, bend=14):
    p['rot']['upperarm_l'] = (2, 0, out)
    p['rot']['upperarm_r'] = (2, 0, -out)
    p['rot']['forearm_l'] = (-bend, 0, -4)
    p['rot']['forearm_r'] = (-bend, 0, 4)


def cape_wave(p, t, base, amp, f=1.0):
    p['rot']['cape1'] = (base + amp * 0.6 * S(t, f), 0, 2 * S(t, f, 0.3))
    p['rot']['cape2'] = (amp * 0.9 * S(t, f, -0.18), 0, 3 * S(t, f, 0.1))
    p['rot']['cape3'] = (amp * 1.2 * S(t, f, -0.36), 0, 4 * S(t, f, -0.1))


def c_idle(t):
    p = base_pose()
    arms_relaxed(p)
    br = S(t)
    p['scl']['chest'] = (1 + 0.012 * br, 1 + 0.015 * br, 1 + 0.02 * br)
    p['rot']['spine'] = (1.0 * br, 0, 0)
    p['rot']['head'] = (1.5 * S(t, 1, 0.2), 4 * S(t, 0.5), 2 * S(t, 0.5, 0.25))
    p['rot']['upperarm_l'] = (2, 0, 11 + 1.5 * br)
    p['rot']['upperarm_r'] = (2, 0, -11 - 1.5 * br)
    cape_wave(p, t, 5, 3)
    blink(p, t, 0.55, 0.035)
    return p


def c_walk(t):
    p = base_pose()
    sw = S(t)
    p['pos']['root'] = (0, 0.012 * abs(S(t, 1, 0.25)) - 0.004, 0)
    p['rot']['hips'] = (4, 5 * sw, 2 * sw)
    p['rot']['spine'] = (2, -5 * sw, 0)
    p['rot']['head'] = (-2, -2 * sw, 0)
    for side, sg in (('l', 1), ('r', -1)):
        a = sw * sg
        p['rot']['thigh_' + side] = (-32 * a, 0, 0)
        p['rot']['shin_' + side] = (max(0.0, 48 * S(t, 1, 0.25 if sg > 0 else 0.75)) + 6, 0, 0)
        p['rot']['foot_' + side] = (-10 * a, 0, 0)
        p['rot']['upperarm_' + side] = (34 * a, 0, 9 * sg)
        p['rot']['forearm_' + side] = (-28 - 12 * a, 0, 0)
    cape_wave(p, t, 12, 6, 2)
    return p


def c_fly(t):
    p = base_pose()
    w = S(t)
    p['pos']['root'] = (0, 0.02 * S(t, 1, 0.1), 0)
    p['rot']['hips'] = (68 + 3 * w, 0, 3 * S(t, 1, 0.25))
    p['rot']['spine'] = (4, 0, 0)
    p['rot']['chest'] = (4, 0, 0)
    p['rot']['neck'] = (-22, 0, 0)
    p['rot']['head'] = (-38, 0, 0)
    p['rot']['upperarm_r'] = (-172 + 2 * w, 0, 6)       # leading arm stretched forward
    p['rot']['forearm_r'] = (-4, 0, 0)
    p['rot']['upperarm_l'] = (24, 0, 16)                 # other arm tucked by the side
    p['rot']['forearm_l'] = (-64, 0, -10)
    for side, sg in (('l', 1), ('r', -1)):
        k = S(t, 2, 0.0 if sg > 0 else 0.5)
        p['rot']['thigh_' + side] = (6 + 5 * k, 0, 2 * sg)
        p['rot']['shin_' + side] = (8 + 5 * k, 0, 0)
        p['rot']['foot_' + side] = (55, 0, 0)
    cape_wave(p, t, 6, 10, 2)
    p['scl']['mouth_open'] = (0.5, 0.45, 0.6)
    blink(p, t, 0.8, 0.03)
    return p


def c_hover(t):
    p = base_pose()
    w = S(t)
    p['pos']['root'] = (0, 0.035 * w, 0)
    p['rot']['hips'] = (7 + 2 * w, 0, 0)
    p['rot']['head'] = (-4, 5 * S(t, 0.5), 0)
    p['rot']['upperarm_l'] = (4, 0, 26 + 5 * w)
    p['rot']['upperarm_r'] = (4, 0, -26 - 5 * w)
    p['rot']['forearm_l'] = (-26, 0, -8)
    p['rot']['forearm_r'] = (-26, 0, 8)
    p['rot']['thigh_l'] = (-30 - 4 * w, 0, 3)
    p['rot']['shin_l'] = (58 + 6 * w, 0, 0)
    p['rot']['thigh_r'] = (4 + 3 * w, 0, -3)
    p['rot']['shin_r'] = (10, 0, 0)
    p['rot']['foot_l'] = (30, 0, 0)
    p['rot']['foot_r'] = (38, 0, 0)
    cape_wave(p, t, 16, 9, 2)
    blink(p, t, 0.4, 0.035)
    return p


def c_point(t):
    p = base_pose()
    b = S(t, 2)
    p['pos']['root'] = (0, 0.008 * abs(b), 0)
    p['rot']['spine'] = (0, -8, -3)
    p['rot']['head'] = (-6, -22 + 3 * S(t), 4)
    p['rot']['upperarm_r'] = (-18, 0, -120 + 4 * b)
    p['rot']['forearm_r'] = (-6, 0, -6)
    p['rot']['hand_r'] = (0, 0, 0)
    p['scl']['finger_r'] = (1, 1, 1)
    p['rot']['upperarm_l'] = (10, 0, 42)
    p['rot']['forearm_l'] = (-30, 0, -82)
    p['pos']['brow_l'] = (0, 0.008, 0)
    p['pos']['brow_r'] = (0, 0.008, 0)
    p['scl']['mouth_open'] = (0.6, 0.5 + 0.2 * abs(S(t)), 0.7)
    cape_wave(p, t, 6, 3)
    blink(p, t, 0.7, 0.03)
    return p


def c_cheer(t):
    p = base_pose()
    j = max(0.0, S(t, 1, -0.02))           # one jump per cycle
    cr = max(0.0, -S(t, 1, -0.02))         # crouch between jumps
    p['pos']['root'] = (0, 0.20 * j - 0.035 * cr, 0)
    p['rot']['hips'] = (4 * cr - 4 * j, 0, 0)
    for side, sg in (('l', 1), ('r', -1)):
        p['rot']['thigh_' + side] = (-34 * cr - 26 * j, 0, 7 * sg * j)
        p['rot']['shin_' + side] = (64 * cr + 58 * j, 0, 0)
        p['rot']['foot_' + side] = (-28 * cr + 30 * j, 0, 0)
        wave = 12 * S(t, 2, 0.25 * sg)
        p['rot']['upperarm_' + side] = (-8, 0, sg * (148 + wave - 60 * cr))
        p['rot']['forearm_' + side] = (-12, 0, sg * (16 + wave * 0.5))
    p['rot']['head'] = (-10 * j + 4 * cr, 0, 5 * S(t))
    p['pos']['brow_l'] = (0, 0.012, 0)
    p['pos']['brow_r'] = (0, 0.012, 0)
    p['scl']['mouth_open'] = (1.0, 0.85 + 0.25 * j, 1.0)
    cape_wave(p, t, 14 + 22 * j, 8, 2)
    return p


def c_encourage(t):
    """Thumbs-up with a friendly nod and a wink."""
    p = base_pose()
    n = S(t, 2)
    p['pos']['root'] = (0, 0.006 * abs(n), 0)
    p['rot']['head'] = (7 * max(0.0, n), 8, 4)
    p['rot']['spine'] = (2, 6, 0)
    p['rot']['upperarm_r'] = (-58 + 3 * n, 0, -16)
    p['rot']['forearm_r'] = (-66, 0, 12)
    p['rot']['hand_r'] = (0, -70, 0)
    p['rot']['thumb_r'] = (-60, 0, 0)
    p['scl']['thumb_r'] = (1.25, 2.3, 1.25)
    p['rot']['upperarm_l'] = (10, 0, 42)
    p['rot']['forearm_l'] = (-30, 0, -82)
    p['scl']['mouth_open'] = (0.7, 0.5, 0.8)
    p['scl']['lid_l'] = (1.0, 1.0, 1.0) if 0.28 < t < 0.62 else LID_OPEN   # wink
    cape_wave(p, t, 6, 3)
    return p


def c_wave(t):
    p = c_idle(t)
    p['rot']['upperarm_r'] = (-6, 0, -128)
    p['rot']['forearm_r'] = (-6, 0, -38 + 26 * S(t, 2))
    p['rot']['hand_r'] = (0, 0, 10 * S(t, 2, 0.1))
    p['rot']['head'] = (-3, 0, -5 + 3 * S(t, 2))
    p['scl']['mouth_open'] = (0.8, 0.7, 0.9)
    p['pos']['brow_l'] = (0, 0.008, 0)
    p['pos']['brow_r'] = (0, 0.008, 0)
    return p


def mix(a, b, k):
    out = {'rot': {}, 'pos': {}, 'scl': {}}
    for ch in ('rot', 'pos', 'scl'):
        for key in a[ch]:
            va, vb = a[ch][key], b[ch].get(key, a[ch][key])
            out[ch][key] = tuple(va[i] + (vb[i] - va[i]) * k for i in range(3))
    return out


def c_takeoff(t):
    crouch = base_pose()
    arms_relaxed(crouch, 24, 40)
    crouch['pos']['root'] = (0, -0.06, 0)
    crouch['rot']['hips'] = (14, 0, 0)
    for s in ('l', 'r'):
        crouch['rot']['thigh_' + s] = (-48, 0, 0)
        crouch['rot']['shin_' + s] = (86, 0, 0)
        crouch['rot']['foot_' + s] = (-30, 0, 0)
    crouch['rot']['head'] = (-12, 0, 0)
    up = base_pose()
    up['pos']['root'] = (0, 0.10, 0)
    up['rot']['upperarm_r'] = (-176, 0, 4)
    up['rot']['upperarm_l'] = (14, 0, 16)
    up['rot']['forearm_l'] = (-60, 0, -8)
    up['rot']['head'] = (-22, 0, 0)
    for s in ('l', 'r'):
        up['rot']['foot_' + s] = (50, 0, 0)
    up['rot']['cape1'] = (22, 0, 0)
    up['rot']['cape2'] = (10, 0, 0)
    up['scl']['mouth_open'] = (0.7, 0.7, 0.8)
    if t < 0.45:
        return mix(c_idle(0), crouch, smooth(0, 0.45, t))
    return mix(crouch, up, smooth(0.45, 1.0, t))


def c_land(t):
    crouch = base_pose()
    arms_relaxed(crouch, 46, 30)
    crouch['pos']['root'] = (0, -0.055, 0)
    crouch['rot']['hips'] = (12, 0, 0)
    for s in ('l', 'r'):
        crouch['rot']['thigh_' + s] = (-44, 0, 0)
        crouch['rot']['shin_' + s] = (80, 0, 0)
        crouch['rot']['foot_' + s] = (-28, 0, 0)
    crouch['rot']['cape1'] = (30, 0, 0)
    crouch['rot']['cape2'] = (14, 0, 0)
    if t < 0.35:
        return mix(c_hover(0), crouch, smooth(0, 0.35, t))
    return mix(crouch, c_idle(0), smooth(0.35, 1.0, t))


CLIPS = [  # name, duration (s), function, loop
    ('idle_loop', 3.0, c_idle, True),
    ('walk_loop', 0.8, c_walk, True),
    ('fly_loop', 1.6, c_fly, True),
    ('hover_loop', 2.0, c_hover, True),
    ('point_loop', 2.0, c_point, True),
    ('cheer_loop', 0.9, c_cheer, True),
    ('encourage_loop', 2.0, c_encourage, True),
    ('wave_loop', 3.0, c_wave, True),
    ('takeoff', 0.6, c_takeoff, False),
    ('land', 0.8, c_land, False),
]
FPS = 24

# ----------------------------------------------------------------- glTF output
class Buf:
    def __init__(self):
        self.data = bytearray()
        self.views = []
        self.accessors = []

    def add(self, arr, ctype, atype, target=None, minmax=False):
        arr = np.ascontiguousarray(arr)
        while len(self.data) % 4:
            self.data.append(0)
        off = len(self.data)
        self.data.extend(arr.tobytes())
        view = {'buffer': 0, 'byteOffset': off, 'byteLength': arr.nbytes}
        if target:
            view['target'] = target
        self.views.append(view)
        acc = {'bufferView': len(self.views) - 1, 'componentType': ctype, 'count': int(arr.shape[0]), 'type': atype}
        if minmax:
            a2 = arr.reshape(arr.shape[0], -1)
            acc['min'] = [float(x) for x in a2.min(axis=0)]
            acc['max'] = [float(x) for x in a2.max(axis=0)]
        self.accessors.append(acc)
        return len(self.accessors) - 1


def main():
    build_mesh()
    buf = Buf()
    materials, prims = [], []
    total_v = total_t = 0
    for name, (col, rough, metal, dbl) in MATS.items():
        p = PARTS[name]
        if p['count'] == 0:
            continue
        materials.append({'name': name, 'doubleSided': dbl,
                          'pbrMetallicRoughness': {'baseColorFactor': lin(col) + [1.0], 'roughnessFactor': rough, 'metallicFactor': metal}})
        v = np.array(p['v'], dtype=np.float32)
        n = np.array(p['n'], dtype=np.float32)
        j = np.array(p['j'], dtype=np.uint8)
        w = np.array(p['w'], dtype=np.float32)
        idx = np.array(p['i'], dtype=np.uint32).reshape(-1)
        total_v += len(v)
        total_t += len(idx) // 3
        prims.append({'attributes': {'POSITION': buf.add(v, 5126, 'VEC3', 34962, True), 'NORMAL': buf.add(n, 5126, 'VEC3', 34962),
                                     'JOINTS_0': buf.add(j, 5121, 'VEC4', 34962), 'WEIGHTS_0': buf.add(w, 5126, 'VEC4', 34962)},
                      'indices': buf.add(idx, 5125, 'SCALAR', 34963), 'material': len(materials) - 1})

    nodes = []
    for name, parent, pos in BONES:
        local = BPOS[name] - (BPOS[parent] if parent else 0)
        nodes.append({'name': name, 'translation': [float(x) for x in local], 'children': []})
    for name, parent, _ in BONES:
        if parent:
            nodes[BIDX[parent]]['children'].append(BIDX[name])
    for nd in nodes:
        if not nd['children']:
            del nd['children']
    ibm = np.zeros((len(BONES), 16), dtype=np.float32)
    for name, _, _ in BONES:
        m = np.eye(4, dtype=np.float32)
        m[3, :3] = -BPOS[name]          # column-major: translation lives in the last column
        ibm[BIDX[name]] = m.reshape(-1)
    skin = {'joints': list(range(len(BONES))), 'skeleton': 0, 'inverseBindMatrices': buf.add(ibm, 5126, 'MAT4')}
    nodes.append({'name': 'KhaledMesh', 'mesh': 0, 'skin': 0})
    mesh_node = len(nodes) - 1

    animations = []
    for cname, dur, fn, loop in CLIPS:
        nfr = max(2, int(round(dur * FPS)) + 1)
        times = np.linspace(0, dur, nfr, dtype=np.float32)
        poses = [fn((i / (nfr - 1)) if not loop else ((i % (nfr - 1)) / (nfr - 1))) for i in range(nfr)]
        t_acc = buf.add(times, 5126, 'SCALAR', None, True)
        samplers, channels = [], []

        def track(bone, path, values, vtype):
            samplers.append({'input': t_acc, 'output': buf.add(np.array(values, dtype=np.float32), 5126, vtype), 'interpolation': 'LINEAR'})
            channels.append({'sampler': len(samplers) - 1, 'target': {'node': BIDX[bone], 'path': path}})
        for name, parent, _ in BONES:
            quats = []
            prev = None
            for p in poses:
                q = q_euler(*p['rot'][name])
                if prev is not None and np.dot(q, prev) < 0:
                    q = -q
                prev = q
                quats.append(q)
            track(name, 'rotation', quats, 'VEC4')
        for name in poses[0]['pos']:
            rest_local = BPOS[name] - (BPOS[BPAR[name]] if BPAR[name] else 0)
            track(name, 'translation', [rest_local + np.array(p['pos'][name]) for p in poses], 'VEC3')
        for name in poses[0]['scl']:
            track(name, 'scale', [p['scl'][name] for p in poses], 'VEC3')
        animations.append({'name': cname, 'samplers': samplers, 'channels': channels})

    gltf = {
        'asset': {'version': '2.0', 'generator': 'khaled-star-hero gen_character.py'},
        'scene': 0, 'scenes': [{'name': 'Khaled', 'nodes': [0, mesh_node]}],
        'nodes': nodes, 'meshes': [{'name': 'Khaled', 'primitives': prims}], 'materials': materials,
        'skins': [skin], 'animations': animations,
        'buffers': [{'byteLength': len(buf.data)}], 'bufferViews': buf.views, 'accessors': buf.accessors,
    }
    js = json.dumps(gltf, separators=(',', ':')).encode()
    js += b' ' * ((4 - len(js) % 4) % 4)
    bin_ = bytes(buf.data) + b'\0' * ((4 - len(buf.data) % 4) % 4)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, 'wb') as f:
        f.write(struct.pack('<III', 0x46546C67, 2, 12 + 8 + len(js) + 8 + len(bin_)))
        f.write(struct.pack('<II', len(js), 0x4E4F534A) + js)
        f.write(struct.pack('<II', len(bin_), 0x004E4942) + bin_)
    print('wrote %s: %d verts, %d tris, %d bones, %d clips, %.0f KB' % (
        os.path.normpath(OUT), total_v, total_t, len(BONES), len(CLIPS), os.path.getsize(OUT) / 1024))


if __name__ == '__main__':
    main()
