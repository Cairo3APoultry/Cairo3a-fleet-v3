#!/usr/bin/env python3
"""Composes the launcher icons and splash from /tmp/icon_hero.png (rendered by tools/make_icon.gd)."""
import math, os
from PIL import Image, ImageDraw, ImageFilter

OUT = os.path.join(os.path.dirname(__file__), '..', 'assets', 'ui')
hero = Image.open('/tmp/icon_hero.png').convert('RGBA')
hero = hero.crop(hero.getbbox())


def background(size):
    bg = Image.new('RGBA', (size, size))
    px = bg.load()
    for y in range(size):
        for x in range(size):
            d = math.hypot(x - size / 2, y - size * 0.45) / (size * 0.75)
            t = min(1.0, d)
            px[x, y] = (int(96 - 60 * t), int(190 - 80 * t), int(255 - 35 * t), 255)
    star = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(star)
    pts = []
    for i in range(10):
        a = -math.pi / 2 + math.pi * i / 5
        r = size * (0.40 if i % 2 == 0 else 0.19)
        pts.append((size / 2 + r * math.cos(a), size * 0.5 + r * math.sin(a)))
    d.polygon(pts, fill=(255, 214, 64, 255))
    bg.alpha_composite(star.filter(ImageFilter.GaussianBlur(size * 0.004)))
    return bg


def fit(img, box):
    s = min(box / img.width, box / img.height)
    return img.resize((max(1, int(img.width * s)), max(1, int(img.height * s))), Image.LANCZOS)


def place(canvas, img):
    canvas.alpha_composite(img, ((canvas.width - img.width) // 2, (canvas.height - img.height) // 2))
    return canvas


# adaptive icon layers (432px, artwork inside the central safe zone)
background(432).save(os.path.join(OUT, 'icon_bg_432.png'))
place(Image.new('RGBA', (432, 432), (0, 0, 0, 0)), fit(hero, 250)).save(os.path.join(OUT, 'icon_fg_432.png'))
# legacy icon: rounded square
icon = place(background(384), fit(hero, 300))
mask = Image.new('L', (384, 384), 0)
ImageDraw.Draw(mask).rounded_rectangle((0, 0, 383, 383), radius=84, fill=255)
icon.putalpha(mask)
icon.resize((192, 192), Image.LANCZOS).save(os.path.join(OUT, 'icon_192.png'))
# boot splash
place(Image.new('RGBA', (512, 512), (0, 0, 0, 0)), fit(hero, 440)).save(os.path.join(OUT, 'splash.png'))
print('icons written')
